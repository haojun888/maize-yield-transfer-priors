"""Rebuild manuscript figures from saved tables; no model fitting or inference."""
from pathlib import Path
import json,struct
import numpy as np
import pandas as pd
import PIL
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon,Rectangle,FancyArrowPatch
from matplotlib.lines import Line2D
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'reproduced'
DATA=ROOT/'source_data'
FIG=OUT/'figures'
FIG.mkdir(parents=True,exist_ok=True)
def require_matplotlib_panel_alignment(fig,json_out=None,overlay_svg=None,strict=True):
    fig.canvas.draw()
    boxes=[a.get_position().bounds for a in fig.axes]
    result={'plot_rectangles_figure_fraction':boxes,'status':'single_panel' if len(boxes)<=1 else 'pass'}
    if len(boxes)>1:
        widths=[b[2]*fig.get_figwidth()*72 for b in boxes]
        heights=[b[3]*fig.get_figheight()*72 for b in boxes]
        assert max(widths)-min(widths)<=1.5
        assert max(heights)-min(heights)<=1.5
    if json_out:Path(json_out).write_text(json.dumps(result,indent=2))
plt.rcParams.update({'font.family': 'sans-serif', 'font.sans-serif': ['Arial', 'DejaVu Sans'], 'font.size': 7.5, 'axes.titlesize': 8, 'axes.labelsize': 8, 'xtick.labelsize': 7, 'ytick.labelsize': 7, 'axes.spines.top': False, 'axes.spines.right': False, 'axes.linewidth': 0.6, 'pdf.fonttype': 42, 'svg.fonttype': 'none', 'legend.frameon': False})
colors = {'uniform': '#858585', 'sobol_fixed': '#2564A5', 'learned': '#D17B17', 'guided_sobol': '#178B79', 'source_permutation_fixed': '#7B3793', 'sobol_square': '#B63D4C'}
names = {'uniform': 'Equal', 'sobol_fixed': 'Sobol', 'learned': 'Learned', 'guided_sobol': 'Sobol-KL', 'source_permutation_fixed': 'PFI', 'sobol_square': 'Sobol²'}
contracts = {}

def save(fig, num, claim, panels):
    fig.canvas.draw()
    require_matplotlib_panel_alignment(fig, json_out=FIG / f'fig{num}.alignment.json', overlay_svg=FIG / f'fig{num}.alignment.svg', strict=True)
    fig.savefig(FIG / f'fig{num}.pdf', bbox_inches='tight', pad_inches=0.06)
    fig.savefig(FIG / f'fig{num}.svg', bbox_inches='tight', pad_inches=0.06)
    fig.savefig(FIG / f'fig{num}.tiff', dpi=600, bbox_inches='tight', pad_inches=0.06, pil_kwargs={'compression': 'tiff_lzw'})
    fig.savefig(FIG / f'fig{num}.png', dpi=350, bbox_inches='tight', pad_inches=0.06)
    contracts[str(num)] = {'claim': claim, 'panels': panels, 'backend': 'python', 'source_data': 'existing frozen predictions and verified tables', 'physical_width_mm': 183, 'uncertainty': 'seed points or county intervals as explicitly indicated; no new tests'}
    plt.close(fig)

def polygons():
    f = ROOT / 'work/evi_geometry/US.dbf'
    with f.open('rb') as z:
        h = z.read(32)
        count = struct.unpack('<I', h[4:8])[0]
        hl, rl = struct.unpack('<HH', h[8:12])
        z.seek(hl)
        ids = []
        for _ in range(count):
            ids.append(z.read(rl)[1:81].decode().strip())
    with f.with_suffix('.shp').open('rb') as z:
        z.seek(100)
        i = 0
        while True:
            h = z.read(8)
            if len(h) < 8:
                break
            _, length = struct.unpack('>ii', h)
            b = z.read(length * 2)
            adm = ids[i]
            i += 1
            if struct.unpack('<i', b[:4])[0] not in [5, 15, 25]:
                continue
            parts, n = struct.unpack('<ii', b[36:44])
            ix = list(struct.unpack('<' + 'i' * parts, b[44:44 + parts * 4])) + [n]
            off = 44 + parts * 4
            pts = np.frombuffer(b, dtype='<f8', count=n * 2, offset=off).reshape(-1, 2)
            for a, c in zip(ix[:-1], ix[1:]):
                yield (adm, pts[a:c])
fig, ax = plt.subplots(figsize=(7.2, 3.5))
states = [{'17', '18', '26', '39', '55'}, {'19', '20', '27', '29', '31', '38', '46'}, {'21', '47'}, {'48', '13'}, {'45', '40', '28'}]
palette = ['#2564A5', '#ADB8C3', '#178B79', '#D17B17', '#7B3793']
for adm, pts in polygons():
    if pts[:, 0].mean() < -126 or pts[:, 0].mean() > -66 or pts[:, 1].mean() > 51:
        continue
    state = adm.split('-')[1]
    col = next((palette[i] for i, s in enumerate(states) if state in s), '#F2F2F2')
    ax.add_patch(Polygon(pts, facecolor=col, edgecolor='none', linewidth=0))
ax.set_xlim(-107, -77)
ax.set_ylim(24, 50)
ax.set_aspect(1 / np.cos(np.deg2rad(38)))
ax.set_xlabel('Longitude (°)')
ax.set_ylabel('Latitude (°)')
handles = [Rectangle((0, 0), 1, 1, facecolor=c) for c in palette]
ax.legend(handles, ['East source', 'Original West', 'KY / TN', 'TX / GA', 'SC / OK / MS'], loc='upper center', bbox_to_anchor=(0.5, 1.17), ncol=3, fontsize=7)
save(fig, 1, 'Geographic source and target cohorts', 'single geographic panel; state extent, not claim of all counties sampled')
fig, ax = plt.subplots(figsize=(7.2, 3.4))
ax.set_xlim(0, 10)
ax.set_ylim(0, 5)
ax.axis('off')
boxes = [(0.1, 3.3, 1.65, 1.05, 'Multisource inputs\nSOS−90 to\nEOS−60'), (2.05, 3.3, 1.65, 1.05, 'Source transforms\nGroup encoding\nLSTM / MLP'), (4, 3.3, 1.65, 1.05, 'Frozen teacher\nSource priors'), (5.95, 3.3, 1.65, 1.05, 'Four fusion rules\nSource fitting'), (7.9, 3.3, 1.95, 1.05, 'Frozen models\nSpatial and\njoint transfer'), (0.4, 0.8, 2.35, 1.15, 'Cohorts and weather strata\nNo target refitting'), (3.8, 0.8, 2.35, 1.15, 'Regional confirmation\nStates, years, and baselines'), (7.2, 0.8, 2.35, 1.15, 'Information and allocation\nPermutation and budgets')]
for x, y, w, h, txt in boxes:
    ax.add_patch(Rectangle((x, y), w, h, facecolor='#F4F6F8', edgecolor='#6C7B8B', linewidth=0.7))
    ax.text(x + w / 2, y + h / 2, txt, ha='center', va='center', fontsize=7.2, linespacing=1.5)
for x1, x2 in [(1.75, 2.05), (3.7, 4), (5.65, 5.95), (7.6, 7.9)]:
    ax.add_patch(FancyArrowPatch((x1, 3.82), (x2, 3.82), arrowstyle='->', mutation_scale=9, color='#45586B'))
for x1, x2 in [(2.75, 3.8), (6.15, 7.2)]:
    ax.add_patch(FancyArrowPatch((x1, 1.375), (x2, 1.375), arrowstyle='->', mutation_scale=9, color='#45586B'))
ax.plot([8.87, 8.87, 1.575], [3.3, 2.17, 2.17], color='#45586B', lw=1)
ax.add_patch(FancyArrowPatch((1.575, 2.17), (1.575, 1.95), arrowstyle='->', mutation_scale=9, color='#45586B'))
ax.text(5, 2.48, 'Source data define models and priors; target labels are used for scoring', ha='center', fontsize=8)
save(fig, 2, 'Source fitting and frozen transfer', 'single schematic panel; arrows denote analysis order, not physical mechanism')
d = pd.read_csv(DATA / 'extension_metrics.csv')
d = d[(d.definition == 'weather_only') & (d.state_fips == 'pooled')]
c = pd.read_csv(DATA / 'confirmation_metrics.csv')
c = c[(c.definition == 'weather_only') & (c.state_fips == 'pooled')].copy()
c['cohort'] = 'SCOKMS'
d = pd.concat([d, c], ignore_index=True)
methods = ['uniform', 'sobol_fixed', 'learned', 'guided_sobol']
fig, axs = plt.subplots(1, 3, figsize=(7.2, 3.1))
fig.subplots_adjust(left=0.065, right=0.985, bottom=0.24, top=0.8, wspace=0.34)
panels = [('W_joint', ['low', 'middle', 'high'], 'Joint transfer'), ('W_space', ['low', 'middle', 'high'], 'Spatial transfer'), (None, ['KYTN', 'TXGA', 'SCOKMS'], 'External regions')]
for pi, (ax, (co, groups, title)) in enumerate(zip(axs, panels)):
    for gi, g in enumerate(groups):
        h = d[(d.cohort == co) & (d.distance_bin == g)] if co else d[(d.cohort == g) & (d.distance_bin == ('overall' if g == 'KYTN' else 'high'))]
        for mi, m in enumerate(methods):
            values = h[h.method == m].sort_values('seed').rmse_t_ha.to_numpy()
            assert len(values) == 3
            x = gi + (mi - 1.5) * 0.15
            ax.scatter(x + np.array([-0.025, 0, 0.025]), values, s=7, alpha=0.35, color=colors[m], linewidth=0)
            ax.scatter(x, values.mean(), s=22, color=colors[m], zorder=4, edgecolor='white', linewidth=0.4)
    ax.set_ylim(1.0, 3.6)
    ax.set_xlim(-0.4, 2.4)
    ax.set_xticks(range(3))
    ax.grid(axis='y', alpha=0.17)
    ax.set_ylabel('RMSE (t/ha)')
    labels = ['Low\nn=638', 'Middle\nn=639', 'High\nn=640'] if co == 'W_joint' else ['Low\nn=2539', 'Middle\nn=2463', 'High\nn=2898'] if co else ['KY/TN\nAll n=538', 'TX/GA\nHigh n=370', 'SC/OK/MS\nHigh n=241']
    ax.set_xticklabels(labels, fontsize=6.7)
    ax.set_title(title, pad=7)
    ax.text(0, 1.13, chr(97 + pi), transform=ax.transAxes, fontweight='bold', fontsize=9)
fig.legend([Line2D([], [], marker='o', linestyle='', color=colors[m], markersize=4) for m in methods], [names[m] for m in methods], loc='upper center', bbox_to_anchor=(0.52, 1.02), ncol=4, fontsize=7.5)
save(fig, 3, 'Fusion performance varies by task and weather stratum', 'three comparable panels, equal plot widths/heights; faint points are three training seeds')
paired = pd.read_csv(DATA / 'confirmation_pairs.csv')
paired = paired[(paired.definition == 'weather_only') & (paired.distance_bin == 'high') & (paired.reference == 'learned')]
met = pd.read_csv(DATA / 'confirmation_metrics.csv')
met = met[(met.definition == 'weather_only') & (met.distance_bin == 'high')]
fig, ax = plt.subplots(figsize=(7.2, 4.2))
fig.subplots_adjust(left=0.29, right=0.96, bottom=0.14, top=0.92)
labels = []
pos = []
state_names = {'pooled': 'Pooled', '45': 'South Carolina', '40': 'Oklahoma', '28': 'Mississippi'}
for si, state in enumerate(['pooled', '45', '40', '28']):
    for mi, m in enumerate(['sobol_fixed', 'source_permutation_fixed', 'sobol_square']):
        y = 11 - si * 3 - mi
        p = paired[(paired.state_fips == state) & (paired.method == m)].iloc[0]
        est = p.mse_method_minus_reference
        ax.errorbar(est, y, xerr=[[est - p.county_ci_low], [p.county_ci_high - est]], fmt='o', color=colors[m], markersize=5, capsize=3, lw=1.2)
        mm = met[(met.state_fips == state) & (met.method == m)].sort_values('seed')
        ll = met[(met.state_fips == state) & (met.method == 'learned')].sort_values('seed')
        delta = mm.mse.to_numpy() - ll.mse.to_numpy()
        assert len(delta) == 3
        ax.scatter(delta, np.full(3, y), s=19, facecolor='white', edgecolor=colors[m], linewidth=0.8, zorder=3)
        labels.append(state_names[state] + ' · ' + names[m])
        pos.append(y)
ax.axvline(0, color='#777777', ls='--', lw=0.8)
ax.set_yticks(pos)
ax.set_yticklabels(labels, fontsize=7.5)
ax.set_xlim(-8.5, 1.5)
ax.set_ylim(-0.8, 11.8)
ax.grid(axis='x', alpha=0.14)
ax.set_xlabel('Paired MSE difference: fixed − learned [(t/ha)²]')
ax.text(0.01, 1.03, 'Negative differences favor fixed fusion', transform=ax.transAxes, color='#2564A5', fontsize=8)
save(fig, 4, 'Regional confirmation and state heterogeneity', 'single forest panel; county percentile intervals, mean estimate and three seed differences')
summary = pd.read_csv(DATA / 'extension_summary.csv')
h = summary[(summary.cohort == 'W_joint') & (summary.definition == 'weather_only') & (summary.state_fips == 'pooled') & (summary.distance_bin == 'high')]
inter = pd.read_csv(DATA / 'interventions_random.csv')
inter = inter[(inter.stage == 'refit') & (inter.distance_bin == 'high')]
budget = pd.read_csv(DATA / 'confirmation_budget_intervals.csv')
budget = budget[(budget.definition == 'weather_only') & (budget.state_fips == 'pooled') & (budget.distance_bin == 'high') & (budget.seed == 'seed_mean')]
fig, axs = plt.subplots(1, 3, figsize=(7.2, 3.15))
fig.subplots_adjust(left=0.065, right=0.985, bottom=0.28, top=0.8, wspace=0.46)
ax = axs[0]
for x, prefix, col in [(0, 'random_', '#858585'), (1, 'within_', '#936CB0')]:
    values = h[h.method.str.startswith(prefix)].rmse_mean.to_numpy()
    assert len(values) == (20 if x == 0 else 47)
    jitter = 0.18 * np.sin(np.arange(len(values)) * 2.4)
    ax.scatter(x + jitter, values, s=9, color=col, alpha=0.8, edgecolor='none')
    ax.plot([x - 0.25, x + 0.25], [np.median(values)] * 2, color='#333333', lw=1.4)
sob = float(h[h.method == 'sobol_fixed'].iloc[0].rmse_mean)
ax.axhline(sob, color=colors['sobol_fixed'], ls='--', lw=1)
ax.set_xticks([0, 1])
ax.set_xticklabels(['Across groups\n20 allocations', 'Within blocks\n47 allocations'], fontsize=6.7)
ax.set_ylabel('RMSE (t/ha)')
ax.set_xlim(-0.5, 1.5)
ax.set_ylim(2.0, 3.2)
ax.set_title('Allocation controls', pad=7)
ax = axs[1]
for i, arm in enumerate(['original', 'optical', 'weather']):
    r = inter[inter.arm == arm].iloc[0]
    ax.bar(i - 0.17, r.sobol_rmse, width=0.32, color=colors['sobol_fixed'])
    ax.bar(i + 0.17, r.random_median, width=0.32, color='#858585')
ax.set_xticks([0, 1, 2])
ax.set_xticklabels(['Original', 'Optical', 'Weather'], fontsize=6.7)
ax.set_ylim(0, 4.2)
ax.set_ylabel('RMSE (t/ha)')
ax.set_title('Information permutation', pad=7)
fig.legend([Rectangle((0, 0), 1, 1, color=colors['sobol_fixed']), Rectangle((0, 0), 1, 1, color='#858585')], ['Sobol(b)', 'Random median (b)'], loc='upper center', bbox_to_anchor=(0.5, 1.025), ncol=2, fontsize=7)
ax = axs[2]
for y, (ref, arm) in enumerate([('source_permutation_fixed', 'optical_swap'), ('source_permutation_fixed', 'weather_reverse'), ('sobol_square', 'optical_swap'), ('sobol_square', 'weather_reverse')]):
    r = budget[(budget.reference == ref) & (budget.method == ref + '__' + arm)].iloc[0]
    e = r.mse_method_minus_reference
    ax.errorbar(e, 3 - y, xerr=[[e - r.county_ci_low], [r.county_ci_high - e]], fmt='o', color=colors[ref], markersize=4, capsize=2, lw=1)
ax.set_yticks([3, 2, 1, 0])
ax.set_yticklabels(['PFI-O', 'PFI-W', 'S²-O', 'S²-W'], fontsize=6.7)
ax.set_xlim(-0.2, 1.5)
ax.set_ylim(-0.5, 3.5)
ax.axvline(0, color='#777777', ls='--', lw=0.8)
ax.set_xlabel('ΔMSE [(t/ha)²]')
ax.set_title('Matched-budget controls', pad=7)
for pi, ax in enumerate(axs):
    ax.text(0, 1.13, chr(97 + pi), transform=ax.transAxes, fontweight='bold', fontsize=9)
    ax.grid(axis='y', alpha=0.12)
save(fig, 5, 'Allocation, information retention, and matched budgets', 'three equal plot panels; distances differ as marked; c uses separately matched reference budgets')
(FIG / 'figure_contracts.json').write_text(json.dumps(contracts, ensure_ascii=False, indent=2), encoding='utf-8')
print('Created five scientific figures from existing results.')