"""Recalculate published descriptive metrics from saved predictions; no inference."""
from pathlib import Path
import argparse,json
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parents[1]
METHODS=['uniform','sobol_fixed','learned','guided_sobol','source_permutation_fixed','sobol_sqrt','sobol_square','sobol_uniform_half']

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,default=ROOT/'reproduced')
    args=parser.parse_args();args.output.mkdir(parents=True,exist_ok=True)
    cfg=json.loads((ROOT/'config/mainline.json').read_text());rows=[]
    for cohort in ['W_space','W_joint','KYTN','TXGA','SCOKMS']:
        source=ROOT/'outputs'/('maize_independent_confirmation/model_predictions.npz' if cohort=='SCOKMS' else f'maize_fixed_prior_extension/predictions_{cohort}.npz')
        with np.load(source,allow_pickle=False) as primary, np.load(ROOT/f'outputs/maize_main_strong_baselines/predictions_{cohort}.npz',allow_pickle=False) as base:
            np.testing.assert_array_equal(primary['y'],base['y']);np.testing.assert_array_equal(primary['counties'],base['counties'])
            y=primary['y'].astype(float);background=primary['background'].astype(float)
            states=primary['states'] if 'states' in primary.files else np.array([c.split('-')[1] for c in primary['counties']])
            dist=primary['weather_only'];bins=np.where(dist<=cfg['weather_low_max'],'low',np.where(dist>=cfg['weather_high_min'],'high','middle'))
            for state in ['pooled']+sorted(set(states.tolist())):
                keep=np.ones(len(y),dtype=bool) if state=='pooled' else states==state
                for group in ['overall','low','middle','high']:
                    mask=keep if group=='overall' else keep&(bins==group)
                    if not mask.any():continue
                    observed=y[mask];bg_mse=np.mean((background[mask]-observed)**2);den=np.sum((observed-observed.mean())**2)
                    for bank in [primary,base]:
                        for mi,method in enumerate(bank['methods'].tolist()):
                            if bank is primary and method not in METHODS:continue
                            values=[]
                            for si,seed in enumerate(bank['seeds']):
                                predicted=bank['predictions'][si,mi,mask].astype(float);error=predicted-observed;mse=np.mean(error**2)
                                values.append([np.sqrt(mse),np.mean(np.abs(error)),np.mean(error),1-np.sum(error**2)/den if den>0 else np.nan,1-mse/bg_mse if bg_mse>0 else np.nan])
                            a=np.array(values);rows.append({'cohort':cohort,'state_fips':state,'distance_bin':group,'method':method,'n':int(mask.sum()),'counties':len(set(primary['counties'][mask])),'rmse_mean':a[:,0].mean(),'rmse_seed_sd':a[:,0].std(ddof=1),'mae_mean':a[:,1].mean(),'bias_mean':a[:,2].mean(),'r2_mean':a[:,3].mean(),'background_skill':a[:,4].mean(),'nrmse_percent':100*a[:,0].mean()/observed.mean(),'background_rmse':np.sqrt(bg_mse)})
    result=pd.DataFrame(rows);result.to_csv(args.output/'absolute_metrics_reproduced.csv',index=False)
    expected=pd.read_csv(ROOT/'source_data/absolute_metrics_summary.csv',dtype={'state_fips':str})
    keys=['cohort','state_fips','distance_bin','method'];joined=result.merge(expected,on=keys,suffixes=('_actual','_expected'),validate='one_to_one')
    assert len(result)==len(expected)==len(joined), 'Not all published rows were matched'
    errors={}
    for metric in ['rmse_mean','rmse_seed_sd','mae_mean','bias_mean','r2_mean','background_skill','nrmse_percent','background_rmse']:
        a=joined[metric+'_actual'].to_numpy();b=joined[metric+'_expected'].to_numpy();np.testing.assert_allclose(a,b,atol=1e-6,rtol=1e-6,equal_nan=True);errors[metric]=float(np.nanmax(np.abs(a-b)))
    report={'matched_rows':len(joined),'maximum_absolute_differences':errors,'training_runs':0,'inference_runs':0}
    main_predictions=pd.read_csv(ROOT/'outputs/maize_fusion_transfer/predictions.csv',dtype={'adm_id':str})
    groups=['input','protocol','scenario','variant'];seed_rows=[]
    for key,frame in main_predictions.groupby(groups+['seed']):
        y=frame.observed_yield_t_ha.to_numpy(float);e=frame.predicted_yield_t_ha.to_numpy(float)-y;bg=frame.background_t_ha.to_numpy(float)-y
        seed_rows.append(dict(zip(groups+['seed'],key))|{'rmse':np.sqrt(np.mean(e**2)),'mae':np.mean(np.abs(e)),'bias':np.mean(e),'r2':1-np.sum(e**2)/np.sum((y-y.mean())**2),'skill':1-np.sum(e**2)/np.sum(bg**2)})
    seed_frame=pd.DataFrame(seed_rows);main_summary=seed_frame.groupby(groups).agg(rmse_mean=('rmse','mean'),rmse_seed_sd=('rmse','std'),mae_mean=('mae','mean'),bias_mean=('bias','mean'),r2_mean=('r2','mean'),skill_mean=('skill','mean')).reset_index()
    expected_main=pd.read_csv(ROOT/'source_data/transfer_summary.csv');matched=main_summary.merge(expected_main,on=groups,suffixes=('_actual','_expected'),validate='one_to_one')
    assert len(matched)==len(main_summary)==len(expected_main)==40
    main_errors={}
    for metric in ['rmse_mean','rmse_seed_sd','mae_mean','bias_mean','r2_mean','skill_mean']:
        a=matched[metric+'_actual'];b=matched[metric+'_expected'];np.testing.assert_allclose(a,b,rtol=1e-6,atol=1e-6);main_errors[metric]=float(np.max(np.abs(a-b)))
    main_summary.to_csv(args.output/'transfer_summary_reproduced.csv',index=False)
    report['main_transfer_rows']=len(matched);report['main_transfer_maximum_differences']=main_errors
    (args.output/'metrics_verification.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))

if __name__=='__main__':main()
