"""Optional training entry point. Training is never started without --execute."""
from pathlib import Path
import argparse,sys
ROOT=Path(__file__).resolve().parents[1]

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--execute',action='store_true')
    p.add_argument('--output',type=Path,default=ROOT/'runs/mainline')
    args=p.parse_args()
    if not args.execute:
        print('No training started. Input: work/maize_fusion_screen/gdd_evi.npz. Use --execute to start a new training run.');return
    sys.path.insert(0,str(ROOT/'outputs/maize_fusion_transfer'))
    import transfer
    transfer.OUT=args.output.resolve();transfer.OUT.mkdir(parents=True,exist_ok=True)
    transfer.s.INPUTS=['gdd_evi']
    transfer.run()

if __name__=='__main__':main()
