import sys as _sys
from pathlib import Path as _Path
_release_root = _Path(__file__).resolve().parents[2]
_sys.path.insert(0, str(_release_root))
from release_support import configured_path as _configured_path, prepare_transfer as _prepare_transfer
import unittest
import numpy as np
import torch
from torch import nn
import guided as p

class GuidedTests(unittest.TestCase):

    def test_zero_strength_matches_dynamic(self):
        head = nn.Sequential(nn.Linear(16, 32), nn.ReLU(), nn.Dropout(0.1), nn.Linear(32, 1))
        torch.manual_seed(123)
        a = p.l.Fusion(head, 'learned_dynamic').eval()
        torch.manual_seed(123)
        b = p.Guided(head, np.array([0.1, 0.2, 0.3, 0.3, 0.1]), False).eval()
        bank = torch.randn(7, 5, 16)
        torch.testing.assert_close(a(bank), b(bank))
        pred, weights = b(bank, True)
        loss, mse, kl = p.objective(pred, torch.randn(7), weights, b.prior, 0.0)
        torch.testing.assert_close(loss, mse)

    def test_kl_value_and_learning_direction(self):
        prior = torch.tensor([0.1, 0.2, 0.3, 0.3, 0.1])
        self.assertAlmostEqual(float(p.kl_prior(prior.expand(4, -1), prior)), 0.0, places=6)
        logits = torch.zeros(2, 5, requires_grad=True)
        loss = p.kl_prior(logits.softmax(1), prior)
        loss.backward()
        self.assertGreater(float(logits.grad[0, 0]), 0.0)
        self.assertLess(float(logits.grad[0, 2]), 0.0)

    def test_prior_initialization_and_frozen_encoder(self):
        teacher = p.g.Teacher()
        for value in teacher.parameters():
            value.requires_grad_(False)
        prior = np.array([0.1, 0.2, 0.3, 0.3, 0.1], dtype=np.float32)
        model = p.Guided(teacher.head, prior, True)
        bank = torch.randn(4, 5, 16)
        pred, weights = model(bank, True)
        torch.testing.assert_close(weights, torch.tensor(prior).expand(4, -1))
        loss, _, _ = p.objective(pred, torch.randn(4), weights, model.prior, 0.5)
        loss.backward()
        self.assertTrue(any((v.grad is not None for v in model.gate.parameters())))
        self.assertTrue(any((v.grad is not None for v in model.head.parameters())))
        self.assertTrue(all((v.grad is None for v in teacher.parameters())))

    def test_selection_uses_mean_source_validation(self):
        rows = [{'family': 'a', 'strength': s, 'seed': seed, 'rmse_t_ha': v, 'best_epoch': 3} for s, values in [(0.25, [1.0, 3.0, 2.0]), (0.5, [2.0, 1.0, 1.0]), (1.0, [2.0, 1.0, 1.0])] for seed, v in zip([42, 2026, 3407], values)]
        self.assertEqual(p.choose_strength(rows)['a'], 0.5)

    def test_zero_strength_training_matches_reused_control(self):
        teacher = p.g.Teacher()
        rng = np.random.default_rng(91)
        bank = rng.normal(size=(18, 5, 16)).astype(np.float32)
        residual = rng.normal(size=18).astype(np.float32)
        fit = np.arange(18) < 12
        val = ~fit
        a, am, ast, ae, _ = p.l.train(teacher.head, 'learned_dynamic', bank, residual, fit, val, 42, epochs=2)
        b, bm, bst, be, _ = p.train(teacher.head, np.array([0.1, 0.2, 0.3, 0.3, 0.1]), False, 0.0, bank, residual, fit, val, 42, epochs=2)
        self.assertEqual((am, ast, ae), (bm, bst, be))
        for key, value in a.state_dict().items():
            torch.testing.assert_close(value, b.state_dict()[key], rtol=0.0, atol=0.0)
if __name__ == '__main__':
    raise SystemExit('Use scripts/train_mainline.py for mainline fitting or the saved-result analysis scripts. This historical entry is retained for method provenance, not default execution.')
