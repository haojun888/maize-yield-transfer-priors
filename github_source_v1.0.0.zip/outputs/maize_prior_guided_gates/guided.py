import sys as _sys
from pathlib import Path as _Path
_release_root = _Path(__file__).resolve().parents[2]
_sys.path.insert(0, str(_release_root))
from release_support import configured_path as _configured_path, prepare_transfer as _prepare_transfer
'Source-selected constant KL guidance and prior-initialization controls.'
import copy
import hashlib
import json
import sys
import time
from pathlib import Path
import numpy as np
import pandas as pd
import torch
from torch import nn
from torch.utils.data import DataLoader, TensorDataset
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(OUT.parent / 'maize_learned_gates'))
import learned as l
g = l.g
FAMILIES = ['sobol_fixed', 'sobol_shuffled', 'conditional_fixed', 'conditional_shuffled', 'uniform']
STRENGTHS = [0.25, 0.5, 1.0]

class Guided(l.Fusion):

    def __init__(self, template, prior, initialize=False):
        super().__init__(template, 'learned_dynamic')
        prior = torch.as_tensor(prior, dtype=torch.float32)
        assert prior.shape == (5,) and (prior > 0).all()
        torch.testing.assert_close(prior.sum(), torch.tensor(1.0))
        self.register_buffer('prior', prior)
        self.initialize = initialize

    def forward(self, bank, return_weights=False):
        logits = self.gate(bank.flatten(1))
        if self.initialize:
            logits = logits + self.prior.log()
        weights = logits.softmax(1)
        pred = self.head((bank * weights[:, :, None]).sum(1)).squeeze(1)
        return (pred, weights) if return_weights else pred

def kl_prior(weights, prior):
    return (prior * (prior.log() - weights.clamp_min(torch.finfo(weights.dtype).tiny).log())).sum(1).mean()

def objective(pred, target, weights, prior, strength):
    mse = nn.functional.mse_loss(pred, target)
    kl = kl_prior(weights, prior)
    return (mse + strength * kl, mse, kl)

def choose_strength(rows):
    frame = pd.DataFrame(rows)
    scores = frame.groupby(['family', 'strength']).rmse_t_ha.mean().reset_index()
    return {family: float(sub.sort_values(['rmse_t_ha', 'strength']).iloc[0].strength) for family, sub in scores.groupby('family')}

def train(template, prior, initialize, strength, bank, residual, fit, val, seed, epochs=60):
    g.seed_all(seed + 992)
    model = Guided(template, prior, initialize).to(g.DEVICE)
    g.seed_all(seed + 991)
    mean = float(residual[fit].mean())
    std = float(residual[fit].std())
    ds = TensorDataset(torch.from_numpy(bank[fit]), torch.from_numpy(((residual[fit] - mean) / std).astype(np.float32)))
    loader = DataLoader(ds, batch_size=512, shuffle=True, generator=torch.Generator().manual_seed(seed + 991), num_workers=0)
    optimizer = torch.optim.Adam(model.parameters(), lr=0.001, weight_decay=0.0001)
    best = float('inf')
    bestepoch = epochs
    stale = 0
    state = None
    history = []
    for epoch in range(1, epochs + 1):
        model.train()
        total = np.zeros(3)
        for xb, yb in loader:
            optimizer.zero_grad(set_to_none=True)
            pred, w = model(xb.to(g.DEVICE), True)
            loss, mse, kl = objective(pred, yb.to(g.DEVICE), w, model.prior, strength)
            loss.backward()
            optimizer.step()
            total += np.array([float(loss.detach()), float(mse.detach()), float(kl.detach())]) * len(xb)
        row = {'epoch': epoch, **dict(zip(['train_loss', 'train_standardized_mse', 'train_kl'], total / len(ds)))}
        if val is not None:
            p, _ = l.predict(model, bank[val], mean, std)
            score = g.e.metrics(residual[val], p)['rmse_t_ha']
            row['source_val_rmse'] = score
            if score < best - 1e-05:
                best = score
                bestepoch = epoch
                stale = 0
                state = copy.deepcopy(model.state_dict())
            else:
                stale += 1
        history.append(row)
        if val is not None and stale >= 8:
            break
    if state is not None:
        model.load_state_dict(state)
    return (model, mean, std, bestepoch, history)

def source_context(protocol, seed, d):
    x, soil, lengths, y, years, counties = [d[k] for k in ['x', 'static', 'lengths', 'y', 'years', 'counties']]
    source = g.OUT / f'{protocol}_{seed}'
    teacher, bank = l.load_bank(source, x, soil, lengths)
    backgrounds = json.loads((source / 'background.json').read_text())
    bg = {phase: g.e.background_predict(backgrounds[phase], years, counties) for phase in ['selection', 'final_fit']}
    residual = {phase: (y - v).astype(np.float32) for phase, v in bg.items()}
    priors = json.loads((source / 'priors.json').read_text())['weights']
    return (teacher, bank, bg, residual, priors, g.e.make_split(years, counties, protocol))

def save_checkpoint(path, model, mean, std, epoch, seed, family, strength, initialize):
    torch.save({'state_dict': model.cpu().state_dict(), 'target_mean': mean, 'target_std': std, 'epochs': epoch, 'seed': seed, 'family': family, 'strength': strength, 'initialize': initialize, 'parameters': sum((p.numel() for p in model.parameters()))}, path)

def fingerprint():
    paths = [Path(__file__), Path(l.__file__), Path(g.__file__), Path(g.e.__file__), g.e.BASE / 'train.py', g.e.BASE / 'pipeline.py', OUT / 'design.md', g.e.CACHE / 'dataset.npz', l.OUT / 'all_comparison_predictions.csv', l.OUT / 'verification.json']
    for protocol in ['T', 'E_to_W', 'W_to_E']:
        for seed in g.e.SEEDS:
            paths.extend((g.OUT / f'{protocol}_{seed}' / name for name in ['teacher.pt', 'background.json', 'preprocessing.json', 'priors.json']))
    return hashlib.sha256(''.join((hashlib.sha256(p.read_bytes()).hexdigest() for p in paths)).encode()).hexdigest()

def run():
    started = time.time()
    fp = fingerprint()
    d = np.load(g.e.CACHE / 'dataset.npz')
    y, years, counties = [d[k] for k in ['y', 'years', 'counties']]
    manifest = OUT / 'manifest.json'
    if manifest.exists():
        assert json.loads(manifest.read_text())['fingerprint'] == fp, 'Changed experiment inputs; preserve previous outputs'
    else:
        g.e.save_json(manifest, {'fingerprint': fp, 'families': FAMILIES, 'strengths': STRENGTHS, 'seeds': g.e.SEEDS})
    candidates = []
    for protocol in ['T', 'E_to_W', 'W_to_E']:
        for seed in g.e.SEEDS:
            folder = OUT / f'{protocol}_{seed}'
            folder.mkdir(exist_ok=True)
            teacher, bank, bg, residual, priors, split = source_context(protocol, seed, d)
            rows = []
            for family in FAMILIES:
                for strength in STRENGTHS:
                    key = f'{family}_{strength:g}'
                    record = folder / f'selection_{key}.json'
                    if record.exists():
                        row = json.loads(record.read_text())
                    else:
                        model, mean, std, epoch, h = train(teacher.head, priors[family], False, strength, bank, residual['selection'], split['train'], split['val'], seed)
                        p, _ = l.predict(model, bank[split['val']], mean, std)
                        row = {'protocol': protocol, 'seed': seed, 'family': family, 'strength': strength, 'best_epoch': epoch, **g.e.metrics(y[split['val']], p + bg['selection'][split['val']])}
                        pd.DataFrame(h).to_csv(folder / f'history_selection_{key}.csv', index=False)
                        g.e.save_json(record, row)
                        del model
                    rows.append(row)
            candidates.extend(rows)
            print('SOURCE CANDIDATES', protocol, seed, len(rows), flush=True)
            del teacher, bank
    frame = pd.DataFrame(candidates)
    frame.to_csv(OUT / 'source_candidates.csv', index=False)
    selected = {protocol: choose_strength([r for r in candidates if r['protocol'] == protocol]) for protocol in ['T', 'E_to_W', 'W_to_E']}
    g.e.save_json(OUT / 'strength_selection.json', {'source_only': True, 'selected': selected, 'rule': 'three-seed mean source validation RMSE; exact ties smaller strength'})
    print('ALL SOURCE STRENGTHS LOCKED', selected, flush=True)
    for protocol in ['T', 'E_to_W', 'W_to_E']:
        for seed in g.e.SEEDS:
            folder = OUT / f'{protocol}_{seed}'
            teacher, bank, bg, residual, priors, split = source_context(protocol, seed, d)
            for family in FAMILIES[:-1]:
                record = folder / f'selection_init_{family}.json'
                if record.exists():
                    continue
                model, mean, std, epoch, h = train(teacher.head, priors[family], True, 0.0, bank, residual['selection'], split['train'], split['val'], seed)
                p, _ = l.predict(model, bank[split['val']], mean, std)
                g.e.save_json(record, {'protocol': protocol, 'seed': seed, 'family': family, 'best_epoch': epoch, **g.e.metrics(y[split['val']], p + bg['selection'][split['val']])})
                pd.DataFrame(h).to_csv(folder / f'history_selection_init_{family}.csv', index=False)
                del model
            del teacher, bank
    g.e.save_json(OUT / 'selection_complete.json', {'fingerprint': fp, 'target_predictions_generated': False})
    for protocol in ['T', 'E_to_W', 'W_to_E']:
        for seed in g.e.SEEDS:
            folder = OUT / f'{protocol}_{seed}'
            if (folder / 'complete.json').exists():
                continue
            teacher, bank, bg, residual, priors, split = source_context(protocol, seed, d)
            predictions = []
            weightrows = []
            tasks = [(f'kl_{family}', family, selected[protocol][family], False) for family in FAMILIES]
            tasks += [(f'init_{family}', family, 0.0, True) for family in FAMILIES[:-1]]
            for variant, family, strength, initialize in tasks:
                if initialize:
                    epoch = json.loads((folder / f'selection_init_{family}.json').read_text())['best_epoch']
                else:
                    epoch = next((r['best_epoch'] for r in candidates if r['protocol'] == protocol and r['seed'] == seed and (r['family'] == family) and (r['strength'] == strength)))
                model, mean, std, _, h = train(teacher.head, priors[family], initialize, strength, bank, residual['final_fit'], split['fit'], None, seed, epochs=epoch)
                pd.DataFrame(h).to_csv(folder / f'history_final_{variant}.csv', index=False)
                for scenario, mask in split.items():
                    if scenario not in ['time', 'space', 'joint']:
                        continue
                    p, w = l.predict(model, bank[mask], mean, std)
                    base = {'protocol': protocol, 'scenario': scenario, 'variant': variant, 'seed': seed, 'adm_id': counties[mask], 'year': years[mask]}
                    predictions.append(pd.DataFrame({**base, 'observed_yield_t_ha': y[mask], 'predicted_yield_t_ha': p + bg['final_fit'][mask]}))
                    weightrows.append(pd.DataFrame({**base, **{name: w[:, j] for j, name in enumerate(g.GROUP_NAMES)}}))
                save_checkpoint(folder / f'{variant}.pt', model, mean, std, epoch, seed, family, strength, initialize)
                del model
                print('FINAL SAVED', protocol, seed, variant, 'lambda', strength, 'epochs', epoch, flush=True)
            pd.concat(predictions, ignore_index=True).to_csv(folder / 'predictions.csv', index=False)
            pd.concat(weightrows, ignore_index=True).to_csv(folder / 'weights.csv', index=False)
            g.e.save_json(folder / 'complete.json', {'fingerprint': fp, 'source_teacher_sha256': hashlib.sha256((g.OUT / f'{protocol}_{seed}' / 'teacher.pt').read_bytes()).hexdigest(), 'encoder_frozen': True})
            del teacher, bank
    frames = [pd.read_csv(OUT / f'{protocol}_{seed}' / 'predictions.csv', dtype={'adm_id': str}) for protocol in ['T', 'E_to_W', 'W_to_E'] for seed in g.e.SEEDS]
    pd.concat(frames, ignore_index=True).to_csv(OUT / 'new_predictions.csv', index=False)
    g.e.save_json(OUT / 'run_complete.json', {'fingerprint': fp, 'runtime_seconds': time.time() - started, 'source_candidates': 135, 'initialization_selections': 36, 'new_final_models': 81})
    print('TRAINING COMPLETE', time.time() - started, flush=True)
if __name__ == '__main__':
    raise SystemExit('Use scripts/train_mainline.py for mainline fitting or the saved-result analysis scripts. This historical entry is retained for method provenance, not default execution.')
