import sys as _sys
from pathlib import Path as _Path
_release_root = _Path(__file__).resolve().parents[2]
_sys.path.insert(0, str(_release_root))
from release_support import configured_path as _configured_path, prepare_transfer as _prepare_transfer
'Frozen extension evaluation; reuse all available old predictions and banks.'
import sys
import time
from pathlib import Path
import numpy as np
import pandas as pd
import torch
import extension as x
OUT, ROOT = (x.OUT, x.ROOT)
SEEDS, NEW = (x.SEEDS, x.NEW)
h, s, t = (x.h, x.s, x.t)
sha, read, save = (x.sha, x.read, x.save)
PRIMARY = ['sobol_fixed', 'uniform', 'learned', 'guided_sobol'] + NEW
METHODS = PRIMARY + ['guided_uniform', 'global_sobol_init', 'dynamic_sobol_init', 'capacity_sobol_fixed'] + [f'random_{j:02d}' for j in range(20)] + [f'within_{j:02d}' for j in range(1, 48)] + ['block_equal']
assert len(METHODS) == 80

def aligned_prediction(frame, counties, years, y):
    assert len(frame) == len(y) and (not frame.duplicated(['adm_id', 'year']).any())
    index = pd.MultiIndex.from_arrays([counties, years], names=['adm_id', 'year'])
    aligned = frame.set_index(['adm_id', 'year']).reindex(index)
    assert aligned.predicted_yield_t_ha.notna().all()
    np.testing.assert_allclose(aligned.observed_yield_t_ha, y, rtol=0, atol=2e-06)
    return aligned.predicted_yield_t_ha.to_numpy(dtype=np.float32)

def frozen_bins(distance, low, high):
    return np.where(~np.isfinite(distance), -1, np.where(distance <= low, 0, np.where(distance >= high, 2, 1)))

def model_specs(seed):
    prior = np.array(read(t.OUT / f'gdd_evi__E_to_W_{seed}/priors.json')['prior'])
    specs = h.previous.methods(seed, prior)
    for name in ['guided_sobol', 'guided_uniform']:
        path = t.OUT / f'gdd_evi__E_to_W_{seed}/final_{name}.pt'
        ck = torch.load(path, map_location='cpu', weights_only=True)
        assert ck['strength'] == 0.25
        specs[name] = (path, ck['mode'], np.array(ck['prior']), name)
    for name in NEW:
        path = OUT / str(seed) / f'final_{name}.pt'
        ck = torch.load(path, map_location='cpu', weights_only=True)
        specs[name] = (path, 'fixed', np.array(ck['prior']), name)
    assert set(specs) == set(METHODS)
    return specs

def lock_evaluation():
    x.lock()
    training = read(OUT / 'training_verification.json')
    assert training['verified']
    historic = x.historic_hashes()
    coverage_dir = ROOT / 'outputs/maize_environment_coverage'
    coverage_marker = read(coverage_dir / 'run_complete.json')
    assert sha(coverage_dir / 'run_complete.json') == read(coverage_dir / 'verification.json')['analysis_marker_sha256']
    for key, digest in coverage_marker['outputs_sha256'].items():
        historic[str(coverage_dir / key)] = digest
    recorded_distances = pd.read_csv(coverage_dir / 'distances.csv')
    assert sha(coverage_dir / 'distances.csv') == historic[str(coverage_dir / 'distances.csv')]
    files = [Path(__file__), OUT / 'test_evaluate_extension.py', OUT / 'training_verification.json', ROOT / 'outputs/maize_gain_sources/all_predictions.csv', x.b.OUT / 'new_predictions.csv']
    for name in ['maize_external_region', 'maize_high_weather_transfer']:
        files += [ROOT / 'outputs' / name / 'model_predictions.npz', ROOT / 'work' / name / 'dataset.npz', ROOT / 'outputs' / name / 'evaluation_verification.json']
        distance_name = 'environment_distances.csv' if name == 'maize_external_region' else 'evaluation_distances.csv'
        files.append(ROOT / 'outputs' / name / distance_name)
        v = read(ROOT / 'outputs' / name / 'evaluation_verification.json')
        for record in v['source_bank_checks']:
            key = 'new_bank_sha256' if name == 'maize_external_region' else 'target_bank_sha256'
            file = ROOT / 'work' / name / f"bank_E_{record['seed']}.npy"
            assert sha(file) == record[key]
            files.append(file)
    for definition in h.cov.DEFS:
        for scenario in ['space', 'joint']:
            file = ROOT / f'work/maize_environment_coverage/{definition}__fusion_2019__E_to_W__{scenario}.npz'
            cached = np.load(file)
            recorded = recorded_distances[(recorded_distances.definition == definition) & (recorded_distances.phase == 'fusion_2019') & (recorded_distances.protocol == 'E_to_W') & (recorded_distances.scenario == scenario)].sort_values('row')
            np.testing.assert_array_equal(recorded.row, cached['target_rows'])
            np.testing.assert_allclose(recorded.distance, cached['distance'], rtol=1e-07, atol=1e-07, equal_nan=True)
            np.testing.assert_allclose(recorded.source_q95, cached['source_q95'], atol=1e-12)
            historic[str(file)] = sha(file)
            files.append(file)
    for seed in SEEDS:
        for path, mode, prior, family in model_specs(seed).values():
            files.append(path)
    hashes = {str(p): sha(p) for p in files}
    for path, digest in training['artifacts_sha256'].items():
        assert sha(path) == digest
    for path, digest in hashes.items():
        if Path(path).is_relative_to(OUT):
            continue
        if path in historic:
            assert historic[path] == digest, path
        elif Path(path).name == 'evaluation_verification.json':
            assert read(path)['verified'] is True
        elif 'bank_E_' not in Path(path).name:
            raise AssertionError(f'Missing historic provenance: {path}')
    record = {'methods': METHODS, 'primary_methods': PRIMARY, 'seeds': SEEDS, 'sha256': hashes, 'source_training_locked': sha(OUT / 'training_verification.json'), 'no_target_fitting': True, 'all_methods_retained': True, 'cohorts': ['W_space', 'W_joint', 'KYTN', 'TXGA'], 'extension_not_new_blind_confirmation': True, 'target_predictions_started': False}
    file = OUT / 'evaluation_manifest.json'
    if file.exists():
        assert read(file) == record
    else:
        save(file, record)
    return record

def cohorts():
    original = np.load(s.CACHE / 'gdd_evi.npz')
    split = np.load(t.OUT / 'split_E_to_W.npz')
    saved = pd.read_csv(ROOT / 'outputs/maize_gain_sources/all_predictions.csv', dtype={'adm_id': str})
    saved = saved[saved.protocol == 'E_to_W'].rename(columns={'variant': 'method'})
    budget = pd.read_csv(x.b.OUT / 'new_predictions.csv', dtype={'adm_id': str})
    results = {}
    background = s.e.background_predict(read(t.OUT / 'background_E_to_W.json')['final_fit'], original['years'], original['counties'])
    for scenario in ['space', 'joint']:
        mask = split[scenario]
        rows = np.flatnonzero(mask)
        data = {k: original[k][mask] for k in ['y', 'years', 'counties']}
        data['background'] = background[mask]
        data['states'] = np.array([x.state_code(c) for c in data['counties']])
        data['rows'] = rows
        data['old_frame'] = pd.concat([saved[saved.scenario == scenario], budget[budget.scenario == scenario]], ignore_index=True)
        data['old_npz'] = None
        data['bank_dir'] = None
        for definition in h.cov.DEFS:
            env = np.load(ROOT / f'work/maize_environment_coverage/{definition}__fusion_2019__E_to_W__{scenario}.npz')
            np.testing.assert_array_equal(env['target_rows'], rows)
            data[definition] = env['distance']
        results['W_' + scenario] = data
    for label, name in [('KYTN', 'maize_external_region'), ('TXGA', 'maize_high_weather_transfer')]:
        raw = np.load(ROOT / 'work' / name / 'dataset.npz')
        old = np.load(ROOT / 'outputs' / name / 'model_predictions.npz')
        data = {k: raw[k] for k in ['y', 'years', 'counties']}
        for key in ['y', 'years', 'counties']:
            np.testing.assert_array_equal(data[key], old[key])
        data['background'] = old['background']
        data['states'] = np.array([x.state_code(c) for c in data['counties']])
        data['rows'] = None
        data['old_frame'] = None
        data['old_npz'] = old
        data['bank_dir'] = ROOT / 'work' / name
        distance_name = 'environment_distances.csv' if label == 'KYTN' else 'evaluation_distances.csv'
        distances = pd.read_csv(ROOT / 'outputs' / name / distance_name, dtype={'adm_id': str})
        for definition in h.cov.DEFS:
            frame = distances[distances.definition == definition].sort_values('row')
            np.testing.assert_array_equal(frame.adm_id, data['counties'])
            np.testing.assert_array_equal(frame.year, data['years'])
            data[definition] = frame.distance.to_numpy()
        results[label] = data
    return results

def predict_all(manifest):
    sys.path.insert(0, str(x.i.GAIN))
    import controls as c
    model_rows = []
    total_reused = 0
    total_inferred = 0
    for label, data in cohorts().items():
        file = OUT / f'predictions_{label}.npz'
        if file.exists():
            saved = np.load(file)
            assert str(saved['evaluation_manifest_sha256']) == sha(OUT / 'evaluation_manifest.json')
            print('RESUME_SAVED_COHORT', label, flush=True)
            continue
        predictions = np.empty((3, len(METHODS), len(data['y'])), dtype=np.float32)
        for si, seed in enumerate(SEEDS):
            source, split, teacher, source_bank, residual, teacher_ck = x.source_context(seed)
            bank = source_bank[data['rows']] if data['rows'] is not None else np.load(data['bank_dir'] / f'bank_E_{seed}.npy')
            assert bank.shape == (len(data['y']), 7, 16) and np.isfinite(bank).all()
            specs = model_specs(seed)
            for mi, method in enumerate(METHODS):
                reused = False
                if data['old_npz'] is not None:
                    old = data['old_npz']
                    old_methods = old['methods'].tolist()
                    if method in old_methods:
                        old_seed = old['seeds'].tolist().index(seed)
                        value = old['predictions'][old_seed, old_methods.index(method)]
                        reused = True
                else:
                    frame = data['old_frame']
                    frame = frame[(frame.seed == seed) & (frame.method == method)]
                    if len(frame):
                        value = aligned_prediction(frame, data['counties'], data['years'], data['y'])
                        reused = True
                path, mode, prior, family = specs[method]
                ck = torch.load(path, map_location='cpu', weights_only=True)
                if not reused:
                    model = c.factory(teacher.head, mode, prior).to(s.DEVICE)
                    model.load_state_dict(ck['state_dict'])
                    assert sum((p.numel() for p in model.parameters())) == ck['parameters']
                    value, w = s.predict(model, bank, ck['target_mean'], ck['target_std'])
                    value = value + data['background']
                    reloaded = c.factory(teacher.head, mode, prior).to(s.DEVICE)
                    reloaded.load_state_dict(torch.load(path, map_location='cpu', weights_only=True)['state_dict'])
                    repeat, rw = s.predict(reloaded, bank, ck['target_mean'], ck['target_std'])
                    np.testing.assert_allclose(value, repeat + data['background'], rtol=2e-06, atol=2e-06)
                    np.testing.assert_allclose(w, rw, atol=2e-06)
                    if mode in ['fixed', 'uniform']:
                        np.testing.assert_allclose(w, np.broadcast_to(prior, w.shape), atol=1e-07, rtol=1e-06)
                    total_inferred += 1
                else:
                    total_reused += 1
                assert np.isfinite(value).all()
                predictions[si, mi] = value
                model_rows.append({'cohort': label, 'seed': seed, 'method': method, 'reused_prediction': reused, 'parameters': ck['parameters'], 'epoch': ck['epoch'], 'checkpoint': str(path)})
            print('EVALUATED', label, seed, 'methods', len(METHODS), 'n', len(data['y']), flush=True)
        np.savez_compressed(file, predictions=predictions, methods=np.array(METHODS), seeds=np.array(SEEDS), **{k: data[k] for k in ['y', 'years', 'counties', 'states', 'background', 'weather_only', 'weather_calendar']}, evaluation_manifest_sha256=np.array(sha(OUT / 'evaluation_manifest.json')))
    if model_rows:
        pd.DataFrame(model_rows).to_csv(OUT / 'evaluated_models.csv', index=False)
        save(OUT / 'inference_complete.json', {'reused_model_cohort_cases': total_reused, 'inferred_model_cohort_cases': total_inferred, 'new_training_in_evaluation': 0, 'complete': True})

def summarize():
    metrics = []
    paired = []
    yearly = []
    distributions = []
    rules = {}
    for definition in h.cov.DEFS:
        env = np.load(ROOT / f'work/maize_environment_coverage/{definition}__fusion_2019__E_to_W__joint.npz')
        low = float(env['distance'][env['binid'] == 0].max())
        high = max(float(env['source_q95']), float(env['distance'][env['binid'] == 2].min()))
        rules[definition] = {'low_max': low, 'high_min': high, 'source_q95': float(env['source_q95'])}
    for label in ['W_space', 'W_joint', 'KYTN', 'TXGA']:
        z = np.load(OUT / f'predictions_{label}.npz')
        prediction = z['predictions'].astype(np.float64)
        y = z['y'].astype(np.float64)
        all_error = (prediction - y) ** 2
        for definition, rule in rules.items():
            bins = frozen_bins(z[definition], rule['low_max'], rule['high_min'])
            for state in ['pooled'] + sorted(set(z['states'])):
                state_mask = np.ones(len(y), bool) if state == 'pooled' else z['states'] == state
                for group, mask in [('overall', state_mask)] + [(name, state_mask & (bins == j)) for j, name in enumerate(['low', 'middle', 'high'])]:
                    if not mask.any():
                        continue
                    squared = all_error[:, :, mask]
                    counts = int(mask.sum())
                    for si, seed in enumerate(SEEDS):
                        for mi, method in enumerate(METHODS):
                            score = s.e.metrics(y[mask], prediction[si, mi, mask])
                            metrics.append({'cohort': label, 'definition': definition, 'state_fips': state, 'distance_bin': group, 'seed': seed, 'method': method, **score, 'mse': squared[si, mi].mean(), 'mse_minus_sobol': (squared[si, mi] - squared[si, 0]).mean(), 'background_skill': 1 - squared[si, mi].mean() / np.mean((z['background'][mask] - y[mask]) ** 2)})
                    mean_rmse = np.sqrt(squared.mean(2)).mean(0)
                    for family, prefix in [('cross_random', 'random_'), ('within_block', 'within_')]:
                        indices = [j for j, m in enumerate(METHODS) if m.startswith(prefix)]
                        family_rmse = mean_rmse[indices]
                        for reference in PRIMARY:
                            ri = METHODS.index(reference)
                            distributions.append({'cohort': label, 'definition': definition, 'state_fips': state, 'distance_bin': group, 'family': family, 'reference': reference, 'n': counts, 'alternatives': len(indices), 'family_rmse_min': family_rmse.min(), 'family_rmse_median': np.median(family_rmse), 'family_rmse_max': family_rmse.max(), 'reference_rmse': mean_rmse[ri], 'reference_beats_count': int((mean_rmse[ri] < family_rmse).sum())})
                    if group in ['overall', 'high']:
                        counties = z['counties'][mask]
                        unique, inverse = np.unique(counties, return_inverse=True)
                        county_count = np.bincount(inverse)
                        draws = np.random.default_rng(20261012).integers(0, len(unique), (2000, len(unique)))
                        denominator = county_count[draws].sum(1)
                        comparisons = [(method, [METHODS.index(method)], ref) for method in NEW for ref in ['learned', 'sobol_fixed']]
                        comparisons += [('cross_random_mean', [j for j, m in enumerate(METHODS) if m.startswith('random_')], ref) for ref in ['sobol_fixed', 'source_permutation_fixed']]
                        comparisons += [('within_block_mean', [j for j, m in enumerate(METHODS) if m.startswith('within_')], ref) for ref in ['sobol_fixed', 'source_permutation_fixed']]
                        for method, indices, reference in comparisons:
                            delta = (squared[:, indices].mean(1) - squared[:, METHODS.index(reference)]).mean(0)
                            sums = np.bincount(inverse, weights=delta)
                            bootstrap = sums[draws].sum(1) / denominator
                            ci = np.quantile(bootstrap, [0.025, 0.975])
                            paired.append({'cohort': label, 'definition': definition, 'state_fips': state, 'distance_bin': group, 'method': method, 'reference': reference, 'n': counts, 'counties': len(unique), 'mse_method_minus_reference': delta.mean(), 'county_ci_low': ci[0], 'county_ci_high': ci[1]})
                for year in sorted(set(z['years'])):
                    for group, mask in [('overall', state_mask & (z['years'] == year)), ('high', state_mask & (z['years'] == year) & (bins == 2))]:
                        if not mask.any():
                            continue
                        mse = all_error[:, :, mask].mean(2)
                        for method in PRIMARY:
                            mi = METHODS.index(method)
                            yearly.append({'cohort': label, 'definition': definition, 'state_fips': state, 'distance_bin': group, 'year': int(year), 'method': method, 'n': int(mask.sum()), 'rmse_mean': np.sqrt(mse[:, mi]).mean(), 'mse_minus_learned': (mse[:, mi] - mse[:, METHODS.index('learned')]).mean(), 'mse_minus_sobol': (mse[:, mi] - mse[:, 0]).mean()})
    metrics = pd.DataFrame(metrics)
    metrics.to_csv(OUT / 'metrics.csv', index=False)
    keys = ['cohort', 'definition', 'state_fips', 'distance_bin', 'method']
    summary = metrics.groupby(keys, sort=False).agg(n=('n', 'first'), rmse_mean=('rmse_t_ha', 'mean'), rmse_seed_sd=('rmse_t_ha', 'std'), mse_mean=('mse', 'mean'), r2_mean=('r2', 'mean'), background_skill=('background_skill', 'mean'), mse_minus_sobol=('mse_minus_sobol', 'mean')).reset_index()
    summary.to_csv(OUT / 'summary.csv', index=False)
    pd.DataFrame(paired).to_csv(OUT / 'paired_county_intervals.csv', index=False)
    pd.DataFrame(yearly).to_csv(OUT / 'year_sensitivity.csv', index=False)
    pd.DataFrame(distributions).to_csv(OUT / 'fixed_family_distributions.csv', index=False)
    save(OUT / 'distance_rules.json', rules)
    return summary

def run():
    start = time.time()
    manifest = lock_evaluation()
    predict_all(manifest)
    summary = summarize()
    for path, digest in manifest['sha256'].items():
        assert sha(path) == digest, path
    x.lock()
    files = [p for p in OUT.iterdir() if p.is_file() and p.suffix in {'.csv', '.npz'}]
    files += [OUT / 'inference_complete.json', OUT / 'distance_rules.json']
    save(OUT / 'evaluation_verification.json', {'verified': True, 'all_target_model_cohort_cases': 960, 'new_target_fitting': 0, 'old_training_rerun': False, 'evaluation_manifest_sha256': sha(OUT / 'evaluation_manifest.json'), 'output_sha256': {str(p): sha(p) for p in files}, 'dependencies_unchanged': True, 'runtime_seconds': time.time() - start})
    head = summary[(summary.definition == 'weather_only') & (summary.state_fips == 'pooled') & summary.distance_bin.isin(['overall', 'high']) & summary.method.isin(PRIMARY)]
    print(head.to_string(index=False), flush=True)
    print('EXTENSION_EVALUATION_VERIFIED', round(time.time() - start, 1), flush=True)
if __name__ == '__main__':
    raise SystemExit('Use scripts/train_mainline.py for mainline fitting or the saved-result analysis scripts. This historical entry is retained for method provenance, not default execution.')
