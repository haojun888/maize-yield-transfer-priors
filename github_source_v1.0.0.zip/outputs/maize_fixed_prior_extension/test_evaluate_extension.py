import sys as _sys
from pathlib import Path as _Path
_release_root = _Path(__file__).resolve().parents[2]
_sys.path.insert(0, str(_release_root))
from release_support import configured_path as _configured_path, prepare_transfer as _prepare_transfer
import unittest
import numpy as np
import pandas as pd
from evaluate_extension import aligned_prediction, frozen_bins

class EvaluationChecks(unittest.TestCase):

    def test_reused_prediction_identity(self):
        frame = pd.DataFrame({'adm_id': ['US-48-003', 'US-48-001'], 'year': [2021, 2020], 'observed_yield_t_ha': [7.0, 6.0], 'predicted_yield_t_ha': [7.5, 6.5]})
        counties = np.array(['US-48-001', 'US-48-003'])
        years = np.array([2020, 2021])
        y = np.array([6.0, 7.0])
        np.testing.assert_array_equal(aligned_prediction(frame, counties, years, y), [6.5, 7.5])
        with self.assertRaises(AssertionError):
            aligned_prediction(pd.concat([frame, frame]), counties, years, y)
        with self.assertRaises(AssertionError):
            aligned_prediction(frame.iloc[:1], counties, years, y)
        with self.assertRaises(AssertionError):
            aligned_prediction(frame, counties, years, y + 1)

    def test_fixed_cutoff_not_new_target_quantiles(self):
        distance = np.array([0.1, 0.3, 0.4, 0.45688, 2.0, np.nan])
        np.testing.assert_array_equal(frozen_bins(distance, 0.28327, 0.4568798), [0, 1, 1, 2, 2, -1])
        np.testing.assert_array_equal(frozen_bins(distance[:3], 0.28327, 0.4568798), [0, 1, 1])
if __name__ == '__main__':
    raise SystemExit('Use scripts/train_mainline.py for mainline fitting or the saved-result analysis scripts. This historical entry is retained for method provenance, not default execution.')
