import sys as _sys
from pathlib import Path as _Path
_release_root = _Path(__file__).resolve().parents[2]
_sys.path.insert(0, str(_release_root))
from release_support import configured_path as _configured_path, prepare_transfer as _prepare_transfer
'Source-only fixed priors; train only twelve new selection and final heads.'
import hashlib
import json
import sys
import time
from pathlib import Path
import numpy as np
import pandas as pd
import torch
OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
sys.path.insert(0, str(ROOT / 'outputs/maize_high_weather_transfer'))
import high_weather_eval as h
s, t, b, i = (h.s, h.t, h.b, h.i)
SEEDS = [42, 2026, 3407]
NEW = ['source_permutation_fixed', 'sobol_sqrt', 'sobol_square', 'sobol_uniform_half']
sha, read, save = (h.sha, h.read, h.save)

def state_code(county):
    country, state, district = str(county).split('-')
    assert country == 'US' and len(state) == 2 and (len(district) == 3)
    return state

def normalized(values):
    values = np.asarray(values, dtype=np.float64)
    assert values.shape == (7,) and np.isfinite(values).all() and (values >= 0).all()
    assert values.sum() > 0
    return values / values.sum()

def transformed_priors(prior):
    p = normalized(prior)
    return {'sobol_sqrt': normalized(np.sqrt(p)), 'sobol_square': normalized(p * p), 'sobol_uniform_half': 0.5 * p + 0.5 / 7}

def within_year_orders(years, seed, repeats):
    years = np.asarray(years)
    rng = np.random.default_rng(seed + 20261012)
    orders = np.tile(np.arange(len(years)), (repeats, 1))
    for row in orders:
        for year in np.unique(years):
            positions = np.flatnonzero(years == year)
            row[positions] = rng.permutation(positions)
    return orders

def permutation_prior(bank, residual, years, predictor, seed, repeats=20):
    bank = np.asarray(bank)
    residual = np.asarray(residual, dtype=np.float64)
    assert bank.shape[1] == 7 and len(bank) == len(residual) == len(years)
    assert np.isfinite(bank).all() and np.isfinite(residual).all()
    base = np.asarray(predictor(bank), dtype=np.float64)
    base_mse = float(np.mean((base - residual) ** 2))
    deltas = []
    for order in within_year_orders(years, seed, repeats):
        scores = []
        for group in range(7):
            changed = bank.copy()
            changed[:, group] = bank[order, group]
            prediction = np.asarray(predictor(changed), dtype=np.float64)
            assert prediction.shape == residual.shape and np.isfinite(prediction).all()
            scores.append(float(np.mean((prediction - residual) ** 2) - base_mse))
        deltas.append(scores)
    means = np.mean(deltas, axis=0)
    positive = np.maximum(means, 0.0)
    fallback = bool(positive.sum() == 0)
    prior = np.ones(7) / 7 if fallback else normalized(positive + 1e-08)
    return (prior, {'rows': len(bank), 'repeats': repeats, 'base_mse': base_mse, 'delta_mse_repeats': deltas, 'delta_mse_mean': means.tolist(), 'fallback_uniform': fallback, 'prior': prior.tolist(), 'scope': 'within-year whole latent-group predictive information; not physical contribution'})

def historic_hashes():
    records = {}
    directories = ['maize_fusion_transfer', 'maize_gain_sources', 'maize_budget_controls', 'maize_external_region', 'maize_high_weather_transfer']

    def collect(obj, parent):
        if isinstance(obj, dict):
            for key, value in obj.items():
                if isinstance(value, str) and len(value) == 64 and all((c in '0123456789abcdef' for c in value)):
                    p = Path(key)
                    if not p.is_absolute():
                        p = parent / p
                    if p.is_file():
                        key = str(p)
                        if key in records:
                            assert records[key] == value, f'Conflicting historical hash {key}'
                        records[key] = value
                else:
                    collect(value, parent)
        elif isinstance(obj, list):
            for item in obj:
                collect(item, parent)
    for name in directories:
        directory = ROOT / 'outputs' / name
        for file in directory.glob('*.json'):
            if 'verification' in file.name or file.name in {'manifest.json', 'model_protocol.json', 'evaluation_design.json', 'target_lock.json'}:
                collect(read(file), directory)
    return records

def lock():
    file = OUT / 'source_manifest.json'
    if file.exists():
        old = read(file)
        for path, expected in old['sha256'].items():
            assert sha(path) == expected, f'Locked dependency changed: {path}'
        return old
    historic = historic_hashes()
    deps = [Path(__file__), OUT / 'test_extension.py', OUT / 'protocol.md', s.CACHE / 'gdd_evi.npz', t.OUT / 'split_E_to_W.npz', t.OUT / 'background_E_to_W.json']
    for module in [h, h.previous, b, i, s, t, s.e, s.g, h.cov]:
        deps.append(Path(module.__file__))
    for seed in SEEDS:
        folder = t.OUT / f'gdd_evi__E_to_W_{seed}'
        for name in ['teacher.pt', 'bank.npy', 'preprocessing.json', 'priors.json', 'teacher_complete.json']:
            deps.append(folder / name)
    hashes = {str(p): sha(p) for p in deps}
    checked = 0
    for path, expected in historic.items():
        assert sha(path) == expected, f'Historical dependency changed: {path}'
        checked += 1
    for path, digest in hashes.items():
        if str(Path(path).parent) != str(OUT):
            assert path in historic and digest == historic[path], f'Missing historical provenance: {path}'
    fp = hashlib.sha256(json.dumps(hashes, sort_keys=True).encode()).hexdigest()
    record = {'fingerprint': fp, 'sha256': hashes, 'historical_hash_checks': checked, 'methods': NEW, 'seeds': SEEDS, 'source': 'E_to_W', 'selection_models': 12, 'final_models': 12, 'new_teachers': 0, 'target_selection': False, 'target_outcomes_known_before_design': True, 'no_target_evaluation_started': True}
    save(file, record)
    return record

def source_context(seed):
    folder = t.OUT / f'gdd_evi__E_to_W_{seed}'
    d = np.load(s.CACHE / 'gdd_evi.npz')
    split = np.load(t.OUT / 'split_E_to_W.npz')
    ck = torch.load(folder / 'teacher.pt', map_location='cpu', weights_only=True)
    teacher = s.Teacher(ck['width'], ck['groups']).to(s.DEVICE)
    teacher.load_state_dict(ck['state_dict'])
    teacher.eval()
    for p in teacher.parameters():
        p.requires_grad_(False)
    bank = np.load(folder / 'bank.npy')
    background_spec = read(t.OUT / 'background_E_to_W.json')
    backgrounds = {phase: s.e.background_predict(spec, d['years'], d['counties']) for phase, spec in background_spec.items()}
    residual = {phase: (d['y'] - value).astype(np.float32) for phase, value in backgrounds.items()}
    return (d, split, teacher, bank, residual, ck)

def train():
    start = time.time()
    manifest = lock()
    fp = manifest['fingerprint']
    rows = []
    for seed in SEEDS:
        d, split, teacher, bank, residual, teacher_ck = source_context(seed)
        folder = OUT / str(seed)
        folder.mkdir(exist_ok=True)
        prior_file = folder / 'priors.json'
        if prior_file.exists():
            priors = read(prior_file)
            assert priors['fingerprint'] == fp
        else:
            mask = split['prior']
            assert set(d['years'][mask]) == {2014, 2015, 2016}
            assert np.isin(np.array([state_code(c) for c in d['counties'][mask]]), ['17', '18', '26', '39', '55']).all()

            def predictor(inputs):
                return s.g.bank_head_predict(teacher.head, inputs, np.ones(7) / 7) * teacher_ck['target_std'] + teacher_ck['target_mean']
            p, detail = permutation_prior(bank[mask], residual['teacher'][mask], d['years'][mask], predictor, seed)
            original = read(t.OUT / f'gdd_evi__E_to_W_{seed}/priors.json')['prior']
            weights = {'source_permutation_fixed': p, **transformed_priors(original)}
            priors = {'fingerprint': fp, 'weights': {k: v.tolist() for k, v in weights.items()}, 'permutation_detail': detail, 'source_rows': np.flatnonzero(mask).tolist(), 'source_years': sorted(set(d['years'][mask].tolist()))}
            save(prior_file, priors)
        for method in NEW:
            prior = np.array(priors['weights'][method])
            path = folder / f'selection_{method}.pt'
            meta = folder / f'selection_{method}.json'
            if not path.exists():
                model, mean, std, epoch, history, score = s.train(teacher.head, 'fixed', prior, 0.0, bank, residual['selection'], split['train'], split['val'], seed)
                assert sum((p.numel() for p in model.parameters())) == 577
                torch.save({'state_dict': model.cpu().state_dict(), 'prior': prior.tolist(), 'epoch': epoch, 'target_mean': mean, 'target_std': std, 'fingerprint': fp, 'parameters': 577}, path)
                save(meta, {'method': method, 'seed': seed, 'epoch': epoch, 'val_rmse': score, 'fingerprint': fp})
                pd.DataFrame(history).to_csv(folder / f'selection_{method}_history.csv', index=False)
            ck = torch.load(path, map_location='cpu', weights_only=True)
            assert ck['fingerprint'] == fp
            np.testing.assert_allclose(ck['prior'], prior, rtol=0, atol=0)
            rows.append(read(meta))
            print('SOURCE_SELECTION', seed, method, rows[-1]['epoch'], round(rows[-1]['val_rmse'], 4), flush=True)
    assert len(rows) == 12
    pd.DataFrame(rows).to_csv(OUT / 'validation_candidates.csv', index=False)
    save(OUT / 'selection_complete.json', {'fingerprint': fp, 'models': 12, 'target_predictions_started': False})
    model_hashes = {}
    prior_rows = []
    for seed in SEEDS:
        d, split, teacher, bank, residual, teacher_ck = source_context(seed)
        folder = OUT / str(seed)
        priors = read(folder / 'priors.json')
        for method in NEW:
            prior = np.array(priors['weights'][method])
            meta = read(folder / f'selection_{method}.json')
            path = folder / f'final_{method}.pt'
            if not path.exists():
                model, mean, std = t.fit_final(teacher.head, 'fixed', prior, 0.0, bank, residual['final_fit'], split['fit'], seed, meta['epoch'])
                torch.save({'state_dict': model.cpu().state_dict(), 'prior': prior.tolist(), 'epoch': meta['epoch'], 'target_mean': mean, 'target_std': std, 'fingerprint': fp, 'parameters': 577, 'mode': 'fixed'}, path)
            ck = torch.load(path, map_location='cpu', weights_only=True)
            assert ck['fingerprint'] == fp and ck['epoch'] == meta['epoch']
            np.testing.assert_allclose(ck['prior'], prior, atol=0, rtol=0)
            model_hashes[str(path)] = sha(path)
            prior_rows.append({'seed': seed, 'method': method, **dict(zip(s.NAMES, prior)), 'optical_total': float(prior[[3, 5]].sum()), 'concentration': float((prior ** 2).sum())})
            print('SOURCE_FINAL', seed, method, meta['epoch'], flush=True)
    pd.DataFrame(prior_rows).to_csv(OUT / 'priors.csv', index=False)
    artifacts = [OUT / 'validation_candidates.csv', OUT / 'priors.csv', OUT / 'selection_complete.json']
    artifacts += [p for seed in SEEDS for p in (OUT / str(seed)).iterdir() if p.suffix in {'.pt', '.json', '.csv'}]
    lock()
    save(OUT / 'training_verification.json', {'verified': True, 'fingerprint': fp, 'source_manifest_sha256': sha(OUT / 'source_manifest.json'), 'new_selection_models': 12, 'new_final_models': 12, 'new_teachers': 0, 'old_training_rerun': False, 'model_sha256': model_hashes, 'artifacts_sha256': {str(p): sha(p) for p in artifacts}, 'all_final_models_locked_before_target_prediction': True, 'runtime_seconds': time.time() - start})
    print('FIXED_PRIORS_SOURCE_LOCKED', round(time.time() - start, 1), flush=True)
if __name__ == '__main__':
    raise SystemExit('Use scripts/train_mainline.py for mainline fitting or the saved-result analysis scripts. This historical entry is retained for method provenance, not default execution.')
