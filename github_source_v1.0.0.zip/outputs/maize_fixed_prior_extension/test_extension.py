import sys as _sys
from pathlib import Path as _Path
_release_root = _Path(__file__).resolve().parents[2]
_sys.path.insert(0, str(_release_root))
from release_support import configured_path as _configured_path, prepare_transfer as _prepare_transfer
import unittest
import numpy as np
from extension import transformed_priors, within_year_orders, permutation_prior, state_code

class FixedPriorChecks(unittest.TestCase):

    def test_county_state_format(self):
        self.assertEqual(state_code('US-17-001'), '17')
        self.assertEqual(state_code('US-48-001'), '48')

    def test_transform_concentration_and_support(self):
        p = np.array([0.02, 0.03, 0.05, 0.1, 0.15, 0.25, 0.4])
        weights = transformed_priors(p)
        self.assertEqual(set(weights), {'sobol_sqrt', 'sobol_square', 'sobol_uniform_half'})
        for w in weights.values():
            self.assertAlmostEqual(w.sum(), 1.0)
            self.assertTrue((w > 0).all())
            np.testing.assert_array_equal(np.argsort(w), np.argsort(p))
        self.assertLess((weights['sobol_sqrt'] ** 2).sum(), (p ** 2).sum())
        self.assertGreater((weights['sobol_square'] ** 2).sum(), (p ** 2).sum())
        np.testing.assert_allclose(weights['sobol_uniform_half'], 0.5 * p + 0.5 / 7)

    def test_year_permutations_are_bijections_and_reproducible(self):
        years = np.repeat([2014, 2015, 2016], 20)
        a = within_year_orders(years, 42, 20)
        np.testing.assert_array_equal(a, within_year_orders(years, 42, 20))
        self.assertEqual(a.shape, (20, 60))
        for row in a:
            np.testing.assert_array_equal(years[row], years)
            np.testing.assert_array_equal(np.sort(row), np.arange(60))

    def test_predictive_signal_and_zero_effect_fallback(self):
        rng = np.random.default_rng(9)
        bank = rng.normal(size=(120, 7, 2))
        years = np.repeat([2014, 2015, 2016], 40)
        y = bank[:, 0, 0] * 2
        predictor = lambda x: x[:, 0, 0] * 2
        p, detail = permutation_prior(bank, y, years, predictor, 42)
        self.assertGreater(p[0], 0.999)
        self.assertTrue((p > 0).all())
        self.assertEqual(detail['rows'], 120)
        self.assertEqual(len(detail['delta_mse_repeats']), 20)
        self.assertLess(detail['base_mse'], 1e-15)
        p, detail = permutation_prior(bank, y, years, lambda x: np.zeros(len(x)), 42)
        np.testing.assert_allclose(p, np.ones(7) / 7)
        self.assertTrue(detail['fallback_uniform'])
if __name__ == '__main__':
    raise SystemExit('Use scripts/train_mainline.py for mainline fitting or the saved-result analysis scripts. This historical entry is retained for method provenance, not default execution.')
