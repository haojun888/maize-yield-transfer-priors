import sys as _sys
from pathlib import Path as _Path
_release_root = _Path(__file__).resolve().parents[2]
_sys.path.insert(0, str(_release_root))
from release_support import configured_path as _configured_path, prepare_transfer as _prepare_transfer
'Predefined high-weather support test, using old East models without refitting.'
import hashlib
import json
import sys
import time
from pathlib import Path
import numpy as np
import pandas as pd
import torch
OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
WORK = ROOT / 'work/maize_high_weather_transfer'
sys.path.insert(0, str(ROOT / 'outputs/maize_external_region'))
import evaluate as previous
b = previous.b
i = b.i
s = b.s
t = b.t
cov = previous.cov
frozen_arrays = previous.frozen_arrays
encode = previous.encode
METHODS = ['uniform', 'sobol_fixed', 'learned', 'guided_sobol', 'guided_uniform', 'global_sobol_init', 'dynamic_sobol_init', 'capacity_sobol_fixed']
PRIMARY = METHODS[:4]

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for part in iter(lambda: stream.read(4 * 1024 * 1024), b''):
            h.update(part)
    return h.hexdigest()

def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))

def save(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

def specifications(seed):
    specs = {}
    for name in METHODS:
        folder = i.GAIN / f'E_to_W_{seed}' if name in METHODS[5:] else t.OUT / f'gdd_evi__E_to_W_{seed}'
        path = folder / f'final_{name}.pt'
        ck = torch.load(path, weights_only=True, map_location='cpu')
        mode = name if name in METHODS[5:] else ck['mode']
        specs[name] = (path, mode, np.array(ck['prior'], dtype=float), ck)
        if name.startswith('guided_'):
            assert ck['strength'] == 0.25
    return specs

def lock_models():
    file = OUT / 'model_protocol.json'
    parent = read(b.OUT / 'verification.json')
    assert parent['verified']
    hashes = {str(Path(__file__)): sha(__file__), str(OUT / 'evaluation_protocol.md'): sha(OUT / 'evaluation_protocol.md'), str(OUT / 'test_evaluation.py'): sha(OUT / 'test_evaluation.py'), str(ROOT / 'outputs/maize_external_region/evaluate.py'): sha(ROOT / 'outputs/maize_external_region/evaluate.py'), str(b.OUT / 'verification.json'): sha(b.OUT / 'verification.json')}
    metadata = []
    for seed in b.SEEDS:
        for name, (path, mode, prior, ck) in specifications(seed).items():
            hashes[str(path)] = sha(path)
            metadata.append({'seed': seed, 'method': name, 'mode': mode, 'parameters': ck['parameters'], 'source_selected_epoch': ck['epoch'], 'source_selected_strength': ck.get('strength', 0.0), 'prior': prior.tolist(), 'checkpoint': str(path)})
        folder = t.OUT / f'gdd_evi__E_to_W_{seed}'
        for name in ['teacher.pt', 'preprocessing.json', 'teacher_complete.json', 'priors.json', 'bank.npy']:
            hashes[str(folder / name)] = sha(folder / name)
    for path in [t.OUT / 'background_E_to_W.json', ROOT / 'outputs/maize_environment_coverage/standardization.json', ROOT / 'work/maize_environment_coverage/environment.npy', s.CACHE / 'gdd_evi.npz', t.OUT / 'split_E_to_W.npz']:
        hashes[str(path)] = sha(path)
    for definition in cov.DEFS:
        path = ROOT / f'work/maize_environment_coverage/{definition}__fusion_2019__E_to_W__joint.npz'
        hashes[str(path)] = sha(path)
    record = {'methods': METHODS, 'primary_methods': PRIMARY, 'seeds': b.SEEDS, 'new_training': False, 'no_target_fitting': True, 'no_target_selection': True, 'model_metadata': metadata, 'sha256': hashes}
    if file.exists():
        assert read(file) == record, 'Locked source models/protocol changed'
    else:
        save(file, record)
    return record

def load_data():
    v = read(OUT / 'verification.json')
    assert v['verified']
    data = np.load(WORK / 'dataset.npz')
    windows = pd.read_csv(OUT / 'date_windows.csv', parse_dates=['start', 'cutoff', 'sos_date', 'eos_date'], dtype={'adm_id': str})
    cohort = pd.read_csv(OUT / 'target_cohort_manifest.csv', dtype={'adm_id': str, 'state_fips': str})
    np.testing.assert_array_equal(data['counties'], cohort.adm_id)
    np.testing.assert_array_equal(data['years'], cohort.year)
    np.testing.assert_array_equal(data['counties'], windows.adm_id)
    np.testing.assert_array_equal(data['years'], windows.year)
    np.testing.assert_allclose(data['y'], cohort['yield'], atol=2e-06)
    np.testing.assert_array_equal(data['lengths'], windows.length)
    assert not cohort.duplicated(['adm_id', 'year']).any()
    assert ((windows.sos_date - windows.start).dt.days == 90).all()
    assert ((windows.eos_date - windows.cutoff).dt.days == 60).all()
    assert np.isfinite(data['static']).all() and data['x'].shape[-1] == 10
    valid = np.arange(data['x'].shape[1])[None, :] < data['lengths'][:, None]
    assert np.isnan(data['x'][~valid]).all()
    old = np.load(s.CACHE / 'gdd_evi.npz')
    ky = np.load(ROOT / 'work/maize_external_region/dataset.npz')
    assert not set(data['counties']) & set(old['counties'])
    assert not set(data['counties']) & set(ky['counties'])
    assert set(data['years']).issubset({2020, 2021, 2022, 2023})
    if 'dataset_sha256' in v:
        assert sha(WORK / 'dataset.npz') == v['dataset_sha256']
    return (data, windows, cohort)

def descriptors(data, windows):
    features = cov.environment(data, windows)
    original = np.load(ROOT / 'work/maize_environment_coverage/environment.npy')
    split = np.load(t.OUT / 'split_E_to_W.npz')
    parameters = read(ROOT / 'outputs/maize_environment_coverage/standardization.json')
    results = {}
    rows = []
    for definition, (cols, groups) in cov.DEFS.items():
        p = parameters[f'{definition}__fusion_2019']

        def transform(a):
            return ((a[:, cols] - np.array(p['mean'])) / np.array(p['scale']) / np.sqrt(p['group_sizes'])).astype(np.float32)
        source = transform(original)
        reference = split['fit'] & np.isfinite(original[:, cols]).all(1)
        z = transform(features)
        complete = np.isfinite(z).all(1)
        distance = np.full(len(z), np.nan)
        distance[complete] = cov.neighbor_distance(z[complete], source[reference])
        direct = []
        for first in range(0, int(complete.sum()), 32):
            query = z[complete][first:first + 32].astype(np.float64)
            squared = ((query[:, None] - source[reference][None].astype(np.float64)) ** 2).sum(-1)
            direct.extend(np.sqrt(np.partition(squared, 4, axis=1)[:, :5]).mean(1))
        np.testing.assert_allclose(distance[complete], direct, atol=8e-05, rtol=8e-05)
        old = np.load(ROOT / f'work/maize_environment_coverage/{definition}__fusion_2019__E_to_W__joint.npz')
        q95 = float(old['source_q95'])
        low = float(old['distance'][old['binid'] == 0].max())
        high = max(q95, float(old['distance'][old['binid'] == 2].min()))
        bins = np.where(~complete, -1, np.where(distance <= low, 0, np.where(distance >= high, 2, 1)))
        results[definition] = {'distance': distance, 'bins': bins, 'source_q95': q95, 'low_max': low, 'high_min': high, 'source_n': int(reference.sum()), 'complete': complete}
        for j in range(len(z)):
            rows.append({'definition': definition, 'row': j, 'adm_id': data['counties'][j], 'year': int(data['years'][j]), 'distance': distance[j], 'distance_bin': int(bins[j]), 'above_source_q95': bool(distance[j] > q95)})
    pd.DataFrame(rows).to_csv(OUT / 'evaluation_distances.csv', index=False)
    save(OUT / 'distance_rules.json', {k: {key: value for key, value in v.items() if key not in ['distance', 'bins', 'complete']} for k, v in results.items()})
    return results

def summarize(data, cohort, predictions, background, environment):
    frames = []
    metrics = []
    paired = []
    year_rows = []
    associations = []
    states = ['pooled'] + sorted(set(cohort.state_fips))
    reference_index = METHODS.index('sobol_fixed')
    for si, seed in enumerate(b.SEEDS):
        for mi, method in enumerate(METHODS):
            frames.append(pd.DataFrame({'seed': seed, 'method': method, 'adm_id': data['counties'], 'state_fips': cohort.state_fips, 'year': data['years'], 'observed_yield_t_ha': data['y'], 'predicted_yield_t_ha': predictions[si, mi], 'background_t_ha': background, 'weather_distance': environment['weather_only']['distance'], 'weather_bin': environment['weather_only']['bins']}))
    pd.concat(frames, ignore_index=True).to_csv(OUT / 'predictions.csv', index=False)
    for definition in cov.DEFS:
        env = environment[definition]
        bins = env['bins']
        for state in states:
            state_mask = np.ones(len(cohort), dtype=bool) if state == 'pooled' else cohort.state_fips.to_numpy() == state
            groups = [('overall', state_mask), ('source_q95_above', state_mask & (env['distance'] > env['source_q95']))]
            groups += [(label, state_mask & (bins == j)) for j, label in enumerate(['low', 'middle', 'high'])]
            for label, mask in groups:
                if not mask.any():
                    continue
                y = data['y'][mask].astype(np.float64)
                for si, seed in enumerate(b.SEEDS):
                    ref = predictions[si, reference_index, mask].astype(np.float64) - y
                    for mi, method in enumerate(METHODS):
                        value = predictions[si, mi, mask].astype(np.float64)
                        error = value - y
                        metrics.append({'definition': definition, 'state_fips': state, 'distance_bin': label, 'seed': seed, 'method': method, **s.e.metrics(y, value), 'mse': np.mean(error ** 2), 'mse_minus_sobol': np.mean(error ** 2 - ref ** 2), 'background_skill': 1 - np.mean(error ** 2) / np.mean((background[mask] - y) ** 2)})
                counties = data['counties'][mask]
                unique, inverse = np.unique(counties, return_inverse=True)
                count = np.bincount(inverse)
                rng = np.random.default_rng(20261011)
                draws = rng.integers(0, len(unique), (2000, len(unique)))
                den = count[draws].sum(1)
                squared = (predictions[:, :, mask].astype(np.float64) - y) ** 2
                for method in ['uniform', 'learned', 'guided_sobol', 'guided_uniform']:
                    values = (squared[:, METHODS.index(method)] - squared[:, reference_index]).mean(0)
                    sums = np.bincount(inverse, weights=values)
                    boot = sums[draws].sum(1) / den
                    low, high = np.quantile(boot, [0.025, 0.975])
                    paired.append({'definition': definition, 'state_fips': state, 'distance_bin': label, 'method': method, 'mse_minus_sobol': values.mean(), 'county_bootstrap_low': low, 'county_bootstrap_high': high, 'n': int(mask.sum()), 'counties': len(unique)})
            for method in ['uniform', 'learned', 'guided_sobol']:
                error = predictions[:, METHODS.index(method)].astype(np.float64) - data['y']
                ref = predictions[:, reference_index].astype(np.float64) - data['y']
                gain = (error ** 2 - ref ** 2).mean(0)
                associations.append({'definition': definition, 'state_fips': state, 'method': method, 'n': int(state_mask.sum()), 'rho_distance_method_minus_sobol_mse': cov.rho(env['distance'][state_mask], gain[state_mask])})
            for year in [2020, 2021, 2022, 2023]:
                for label, mask in [('overall', state_mask & (data['years'] == year)), ('high', state_mask & (data['years'] == year) & (bins == 2))]:
                    if not mask.any():
                        continue
                    y = data['y'][mask].astype(np.float64)
                    ref = predictions[:, reference_index, mask].astype(np.float64) - y
                    for mi, method in enumerate(METHODS):
                        error = predictions[:, mi, mask].astype(np.float64) - y
                        year_rows.append({'definition': definition, 'state_fips': state, 'year': year, 'distance_bin': label, 'method': method, 'n': int(mask.sum()), 'rmse_mean': np.sqrt((error ** 2).mean(1)).mean(), 'mse_minus_sobol': (error ** 2 - ref ** 2).mean()})
    metrics = pd.DataFrame(metrics)
    metrics.to_csv(OUT / 'metrics.csv', index=False)
    summary = metrics.groupby(['definition', 'state_fips', 'distance_bin', 'method'], sort=False).agg(n=('n', 'first'), rmse_mean=('rmse_t_ha', 'mean'), rmse_seed_sd=('rmse_t_ha', 'std'), mse_mean=('mse', 'mean'), r2_mean=('r2', 'mean'), bias_mean=('bias_t_ha', 'mean'), mse_minus_sobol=('mse_minus_sobol', 'mean'), background_skill=('background_skill', 'mean')).reset_index()
    summary.to_csv(OUT / 'summary.csv', index=False)
    pd.DataFrame(paired).to_csv(OUT / 'paired_county_intervals.csv', index=False)
    pd.DataFrame(year_rows).to_csv(OUT / 'year_sensitivity.csv', index=False)
    pd.DataFrame(associations).to_csv(OUT / 'distance_associations.csv', index=False)
    return summary

def run():
    start = time.time()
    protocol = lock_models()
    data, windows, cohort = load_data()
    locks = {str(WORK / 'dataset.npz'): sha(WORK / 'dataset.npz'), str(OUT / 'date_windows.csv'): sha(OUT / 'date_windows.csv'), str(OUT / 'target_cohort_manifest.csv'): sha(OUT / 'target_cohort_manifest.csv'), str(OUT / 'verification.json'): sha(OUT / 'verification.json')}
    for name in ['screening_policy.json', 'selection.json', 'screening_states.csv', 'screening_distances.csv', 'design.json']:
        if (OUT / name).exists():
            locks[str(OUT / name)] = sha(OUT / name)
    target_lock = {'source_protocol_sha256': sha(OUT / 'model_protocol.json'), 'target_sha256': locks, 'methods': METHODS, 'no_predictions_started': True, 'source_parameters_only': True}
    if (OUT / 'target_lock.json').exists():
        assert read(OUT / 'target_lock.json') == target_lock
    else:
        save(OUT / 'target_lock.json', target_lock)
    environment = descriptors(data, windows)
    sys.path.insert(0, str(i.GAIN))
    import controls as c
    all_predictions = []
    all_weights = []
    model_hashes = {}
    bank_checks = []
    for seed in b.SEEDS:
        original, split, teacher, bank, bg, residual, prior = i.load_context(seed)
        params = read(t.OUT / f'gdd_evi__E_to_W_{seed}/preprocessing.json')
        reconstructed = encode(teacher, original, params)
        np.testing.assert_allclose(reconstructed, bank, atol=3e-06, rtol=3e-06)
        target_bank = encode(teacher, data, params)
        np.testing.assert_allclose(target_bank, encode(teacher, data, params), atol=2e-06)
        np.save(WORK / f'bank_E_{seed}.npy', target_bank)
        background = s.e.background_predict(read(t.OUT / 'background_E_to_W.json')['final_fit'], data['years'], data['counties'])
        values = []
        weights = []
        for method, (path, mode, p, ck) in specifications(seed).items():
            model = c.factory(teacher.head, mode, p).to(s.DEVICE)
            model.load_state_dict(ck['state_dict'])
            np.testing.assert_allclose(model.prior.cpu().numpy(), p, atol=1e-07)
            assert sum((v.numel() for v in model.parameters())) == ck['parameters']
            value, w = s.predict(model, target_bank, ck['target_mean'], ck['target_std'])
            value = value + background
            again = c.factory(teacher.head, mode, p).to(s.DEVICE)
            again.load_state_dict(torch.load(path, map_location='cpu', weights_only=True)['state_dict'])
            repeated, rw = s.predict(again, target_bank, ck['target_mean'], ck['target_std'])
            np.testing.assert_allclose(value, repeated + background, atol=2e-06, rtol=2e-06)
            np.testing.assert_allclose(w, rw, atol=2e-06)
            values.append(value)
            weights.append(w)
            model_hashes[str(path)] = sha(path)
        all_predictions.append(values)
        all_weights.append(weights)
        bank_checks.append({'seed': seed, 'source_bank_max_difference': float(np.max(np.abs(reconstructed - bank))), 'target_bank_sha256': sha(WORK / f'bank_E_{seed}.npy')})
        print('HIGH WEATHER MODEL CASES VERIFIED', seed, len(values), 'targets', len(cohort), flush=True)
    predictions = np.array(all_predictions, dtype=np.float32)
    weights = np.array(all_weights, dtype=np.float32)
    assert predictions.shape == (3, 8, len(cohort)) and np.isfinite(predictions).all()
    np.savez_compressed(OUT / 'model_predictions.npz', predictions=predictions, weights=weights, seeds=np.array(b.SEEDS), methods=np.array(METHODS), y=data['y'], counties=data['counties'], years=data['years'], states=cohort.state_fips.to_numpy(dtype=str), background=background, weather_bins=environment['weather_only']['bins'], calendar_bins=environment['weather_calendar']['bins'])
    summary = summarize(data, cohort, predictions, background, environment)
    headline = summary[(summary.definition == 'weather_only') & summary.method.isin(PRIMARY) & summary.distance_bin.isin(['overall', 'high'])]
    lines = ['# 高天气距离新区域确认（2026-10-11）', '', '仅依据冻结天气距离和数据条件筛选新州，完整队列和高组均报告。旧东部源模型直接推断，零新训练、零目标拟合；源KL强度维持0.25。RMSE单位t/ha，MSE差为方法−Sobol，负值支持该方法。', '', '| 州／合并 | 分组 | 方法 | n | RMSE | R² | MSE−Sobol | 背景技能 |', '|---|---|---|---:|---:|---:|---:|---:|']
    for row in headline.itertuples():
        lines.append(f'| {row.state_fips} | {row.distance_bin} | {row.method} | {row.n} | {row.rmse_mean:.4f} | {row.r2_mean:.4f} | {row.mse_minus_sobol:+.4f} | {row.background_skill:.4f} |')
    lines += ['', '## 解释与核验', '', '筛选未使用目标预测误差，所有入选州、八方法及三种子完整保留。天气距离主分析与天气＋日历辅助分析分开，阈值沿用原尺度，没有在新队列重新取分位数。相对支持阈值不是严格外推边界；若固定优势成立，也仅限本次源模型、区域和输入协议。', '', '各种子分别评分后平均，不默认预测集成；县区间描述条件误差，不涵盖全部共同年份冲击、多重比较及训练不确定性。共享2020—2023年份、原数据产品和2021固定作物掩膜，独立的是地域，未证明历史实时可用性。新的光学信息干预未运行，不能把模型排序作为生理因果贡献。', '', '全源银行重建与原缓存一致，目标两次编码一致，全部24模型×完整目标队列案例重载推断一致；各种州及高组统计来自相同保存数组。旧模型、预处理、教师、背景及锁定目标输入哈希保持一致。']
    (OUT / '结果报告.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')
    for collection in [protocol['sha256'], locks]:
        for path, digest in collection.items():
            assert sha(path) == digest, path
    files = [OUT / name for name in ['model_predictions.npz', 'predictions.csv', 'metrics.csv', 'summary.csv', 'paired_county_intervals.csv', 'year_sensitivity.csv', 'distance_associations.csv', 'evaluation_distances.csv', 'distance_rules.json', '结果报告.md']]
    save(OUT / 'evaluation_verification.json', {'verified': True, 'target_model_cases': 24, 'states': sorted(set(cohort.state_fips)), 'samples': len(cohort), 'counties': cohort.adm_id.nunique(), 'new_training': 0, 'no_target_fitting': True, 'source_bank_checks': bank_checks, 'model_protocol_sha256': sha(OUT / 'model_protocol.json'), 'target_lock_sha256': sha(OUT / 'target_lock.json'), 'model_sha256': model_hashes, 'output_sha256': {str(path): sha(path) for path in files}, 'dependencies_unchanged': True, 'runtime_seconds': time.time() - start})
    print(headline.to_string(index=False), flush=True)
    print('HIGH WEATHER TRANSFER VERIFIED', round(time.time() - start, 1), flush=True)
if __name__ == '__main__':
    raise SystemExit('Use scripts/train_mainline.py for mainline fitting or the saved-result analysis scripts. This historical entry is retained for method provenance, not default execution.')
