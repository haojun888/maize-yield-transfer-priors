import sys as _sys
from pathlib import Path as _Path
_release_root = _Path(__file__).resolve().parents[2]
_sys.path.insert(0, str(_release_root))
from release_support import configured_path as _configured_path, prepare_transfer as _prepare_transfer
'Outcome-blind frozen weather screen, followed by independent raw inputs.'
import ast, concurrent.futures, hashlib, json, sys, subprocess, time, zipfile, types
from pathlib import Path
from datetime import datetime, timezone
import numpy as np
import pandas as pd
import torch
OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
WORK = ROOT / 'work/maize_high_weather_transfer'
sys.dont_write_bytecode = True
FEATURES = ['tmin', 'tmax', 'tavg', 'prec', 'cwb', 'rad', 'ndvi', 'ssm', 'gdd_cumulative', 'evi']
STATIC = ['awc', 'bulk_density']
AGG = {'tmin': 'min', 'tmax': 'max', 'tavg': 'mean', 'prec': 'sum', 'cwb': 'sum', 'rad': 'mean', 'ndvi': 'mean', 'ssm': 'mean'}
EXCLUDE = {'17', '18', '26', '39', '55', '19', '20', '27', '29', '31', '38', '46', '21', '47'}

def loadfun(path, name):
    tree = ast.parse(Path(path).read_text(encoding='utf-8-sig'))
    node = next((n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == name))
    exec(compile(ast.Module(body=[node], type_ignores=[]), str(path), 'exec'), globals())
for name in ['sha', 'save', 'token', 'geometries', 'evi']:
    loadfun(ROOT / 'outputs/maize_external_region/prepare.py', name)
loadfun(ROOT / 'outputs/maize_feature_increments/prepare.py', 'weather_bins')
loadfun(ROOT / 'outputs/maize_environment_coverage/coverage_analysis.py', 'environment')
s = types.SimpleNamespace(DEVICE='cuda' if torch.cuda.is_available() else 'cpu')
loadfun(ROOT / 'outputs/maize_environment_coverage/coverage_analysis.py', 'neighbor_distance')

def join_windows(frame, w):
    frame = frame.copy()
    frame['observed_date'] = pd.to_datetime(frame.date.astype(str), format='%Y%m%d')
    if 'year' in frame:
        frame = frame.drop(columns='year')
    frame = frame.merge(w[['adm_id', 'year', 'start', 'cutoff']], on='adm_id', how='inner', validate='many_to_many')
    return frame[(frame.observed_date >= frame.start) & (frame.observed_date <= frame.cutoff)].copy()

def aggregate_harvest(frame, w, aggregations):
    frame = join_windows(frame, w)
    frame['bin'] = ((frame.observed_date - frame.start).dt.days // 10).astype(int)
    spec = {'date': ['max']}
    for c, how in aggregations.items():
        frame[c] = frame[c].replace([np.inf, -np.inf], np.nan)
        spec[c] = ['sum', 'count'] if how in ['sum', 'mean'] else [how, 'count']
    got = frame.groupby(['adm_id', 'year', 'bin'], observed=True).agg(spec)
    got.columns = ['_'.join(c) for c in got.columns]
    return got.rename(columns={'date_max': 'latest'}).reset_index()

def period_good(weight, quality, evi, ndvi, doy, start, end):
    dayok = (doy >= start.dayofyear) & (doy <= end.dayofyear) if start.year == end.year else (doy >= start.dayofyear) | (doy <= end.dayofyear)
    return (weight > 0) & (quality == 0) & (evi >= -2000) & (evi <= 10000) & (ndvi >= -2000) & (ndvi <= 10000) & dayok

def rank_states(rows):
    return rows[rows.eligible].sort_values(['distance_median', 'high_n', 'state_fips'], ascending=[False, False, True]).head(2).state_fips.tolist()

def policy():
    path = ROOT / 'work/maize_environment_coverage/weather_only__fusion_2019__E_to_W__joint.npz'
    with np.load(path) as d:
        q95 = float(d['source_q95'])
        high = float(d['distance'][d['binid'] == 2].min())
        low = float(d['distance'][d['binid'] == 0].max())
    deps = [ROOT / 'outputs/maize_environment_coverage/standardization.json', ROOT / 'work/maize_environment_coverage/environment.npy', path, ROOT / 'outputs/maize_baseline/sample_manifest.csv', ROOT / 'outputs/maize_baseline/pipeline.py', ROOT / 'outputs/maize_feature_increments/prepare.py', ROOT / 'outputs/maize_environment_coverage/coverage_analysis.py', ROOT / 'work/evi_geometry/US.shp', ROOT / 'work/evi_geometry/crop_mask_maize_WC.tif', Path(__file__)]
    d = {'policy_version': 1, 'candidate_years': [2020, 2023], 'excluded_state_fips': sorted(EXCLUDE), 'outcome_access': 'metadata-only usecols before selection; positive outcome QC/storage only after selected-state manifest persisted', 'crossyear_growing_season': 'exclude SOS>EOS or EOS−60<SOS', 'prewindow': 'support previous-calendar-year dates; join county-date to explicit harvest-year windows', 'descriptors': ['tavg mean', 'prec sum', 'cwb sum', 'ssm mean', 'rad mean'], 'descriptor_rule': 'exact old environment(): bins>=9; growing-days weighted means >=80%coverage; totals all growing bins observed', 'standardization': 'frozen weather_only__fusion_2019, including group-size weights', 'reference': 'original East2004–2019 completeweather; expected6007', 'distance': 'old torch.cdist float32 mean5nearest', 'source_q95': q95, 'old_high_min': high, 'old_low_max': low, 'high_cutoff': max(q95, high), 'state_min_complete_samples': 80, 'state_min_counties': 20, 'state_min_completeness': 0.95, 'state_median_min': max(q95, high), 'high_min_samples': 50, 'high_min_counties': 15, 'rank': ['median distance descending', 'high count descending', 'FIPS ascending'], 'maximum_states': 2, 'no_threshold_relaxation': True, 'prepare_full_selected_state_cohort': True, 'no_training_prediction_metrics': True, 'dynamic_features': FEATURES, 'static_features': STATIC, 'dependencies': {str(p.relative_to(ROOT)): sha(p) for p in deps}}
    if (OUT / 'design.json').exists():
        assert json.loads((OUT / 'design.json').read_text()) == d
    else:
        save('design.json', d)
    print('Policy frozen, high cutoff', d['high_cutoff'], flush=True)
    return d

def windows(metadata):
    with zipfile.ZipFile(_configured_path('external_e22e1afd74')) as z:
        with z.open('cybench-data/maize/US/crop_calendar_maize_US.csv') as f:
            cal = pd.read_csv(f)
        with z.open('cybench-data/maize/US/soil_maize_US.csv') as f:
            soil = pd.read_csv(f)
    w = metadata.merge(cal[['adm_id', 'sos', 'eos']], on='adm_id', validate='many_to_one')
    w = w[(w.sos.astype(int) <= w.eos.astype(int)) & (w.eos.astype(int) - 60 >= w.sos.astype(int))]
    w = w.merge(soil[['adm_id'] + STATIC], on='adm_id', validate='many_to_one')
    w = w[np.isfinite(w[STATIC]).all(1)]
    sys.path.insert(0, str(ROOT / 'work/maize_external_region'))
    import shapefile
    geo = {r['adm_id'] for r in shapefile.Reader(str(ROOT / 'work/evi_geometry/US.shp')).records()}
    w = w[w.adm_id.isin(geo)].copy()
    for n in ['sos', 'eos']:
        w[n + '_date'] = pd.to_datetime(w.year * 1000 + w[n].astype(int), format='%Y%j')
    w['start'] = w.sos_date - pd.Timedelta(days=90)
    w['cutoff'] = w.eos_date - pd.Timedelta(days=60)
    w['length'] = ((w.cutoff - w.start).dt.days // 10 + 1).astype(int)
    cov = pd.read_csv(ROOT / 'outputs/maize_data_audit/meteo_county_year_coverage.csv')
    cov = cov[(cov.complete_rows >= 365) & (cov['year'] >= 2019)]
    covset = set(zip(cov.adm_id, cov.year))
    keep = [all(((r.adm_id, y) in covset for y in range(r.start.year, r.cutoff.year + 1))) for r in w.itertuples()]
    w = w[keep].sort_values(['adm_id', 'year']).reset_index(drop=True)
    return w

def raw8(w, name, weather_only=False):
    path = WORK / (name + '.npz')
    if path.exists():
        return dict(np.load(path))
    ids = set(w.adm_id)
    T = max(23, int(w.length.max()))
    pieces = []
    daily = []
    minyear = int(w.start.dt.year.min())
    sources = [('meteo', FEATURES[:6]), ('soil_moisture', ['ssm'])] if weather_only else [('meteo', FEATURES[:6]), ('ndvi', ['ndvi']), ('soil_moisture', ['ssm'])]
    with zipfile.ZipFile(_configured_path('external_e22e1afd74')) as z:
        for source, cols in sources:
            chunks = []
            with z.open('cybench-data/maize/US/' + source + '_maize_US.csv') as f:
                for frame in pd.read_csv(f, usecols=['adm_id', 'date'] + cols, chunksize=250000):
                    frame = frame[frame.adm_id.isin(ids) & frame.date.between(minyear * 10000 + 101, 20231231)]
                    if frame.empty:
                        continue
                    chunks.append(aggregate_harvest(frame, w, {c: AGG[c] for c in cols}))
                    if source == 'meteo' and (not weather_only):
                        daily.append(frame[['adm_id', 'date', 'tmin', 'tmax', 'prec']])
            stats = pd.concat(chunks, ignore_index=True)
            reducers = {'latest': 'max'}
            for c in cols:
                how = AGG[c]
                reducers[c + '_count'] = 'sum'
                reducers[c + '_' + ('sum' if how in ['sum', 'mean'] else how)] = 'sum' if how in ['sum', 'mean'] else how
            stats = stats.groupby(['adm_id', 'year', 'bin']).agg(reducers)
            for c in cols:
                how = AGG[c]
                v = stats[c + '_' + ('sum' if how in ['sum', 'mean'] else how)]
                stats[c] = v / stats[c + '_count'] if how == 'mean' else v
                stats.loc[stats[c + '_count'] == 0, c] = np.nan
            check = stats.reset_index().merge(w[['adm_id', 'year', 'cutoff']], on=['adm_id', 'year'])
            assert (pd.to_datetime(check.latest.astype(str), format='%Y%m%d') <= check.cutoff).all()
            pieces.append(stats[cols])
            print(name, 'prepared', source, len(stats), flush=True)
    index = pd.MultiIndex.from_tuples([(r.adm_id, r.year, b) for r in w.itertuples() for b in range(T)], names=['adm_id', 'year', 'bin'])
    x = np.full((len(w), T, 9), np.nan, np.float32)
    allstats = pd.concat(pieces, axis=1)
    for j, c in enumerate(FEATURES[:8]):
        if c in allstats:
            x[:, :, j] = allstats.reindex(index)[c].to_numpy(np.float32).reshape(len(w), T)
    if not weather_only:
        weather = pd.concat(daily, ignore_index=True)
        weather['observed_date'] = pd.to_datetime(weather.date.astype(str), format='%Y%m%d')
        weather['year'] = weather.observed_date.dt.year
        groups = {k: v for k, v in weather.groupby(['adm_id', 'year'])}
        for i, r in enumerate(w.itertuples()):
            x[i, :r.length, 8] = weather_bins(groups[r.adm_id, r.year], r.start, r.sos_date, r.cutoff, r.length)[:, 0]
    else:
        x[:, :, 8] = 0
    lengths = w.length.to_numpy()
    valid = np.arange(T)[None, :] < lengths[:, None]
    x[~valid] = np.nan
    data = {'x': x, 'lengths': lengths, 'years': w.year.to_numpy(), 'counties': w.adm_id.to_numpy(dtype=str), 'static': w[STATIC].to_numpy(np.float32)}
    np.savez_compressed(path, **data)
    return data

def screen(d):
    meta = pd.read_csv(ROOT / 'outputs/maize_data_audit/candidate_labels_2004_2023.csv', usecols=['adm_id', 'harvest_year', 'state_fips'], dtype={'state_fips': str}).rename(columns={'harvest_year': 'year'})
    meta = meta[meta.year.between(2020, 2023) & ~meta.state_fips.isin(EXCLUDE)].sort_values(['adm_id', 'year']).reset_index(drop=True)
    meta.to_csv(OUT / 'screen_candidate_metadata.csv', index=False)
    w = windows(meta)
    w.to_csv(OUT / 'screen_windows.csv', index=False)
    data = raw8(w, 'screen_weather', True)
    env = environment(data, w)[:, [0, 2, 3, 4, 5]]
    complete = np.isfinite(env).all(1)
    params = json.loads((ROOT / 'outputs/maize_environment_coverage/standardization.json').read_text())['weather_only__fusion_2019']
    mean = np.array(params['mean'])
    scale = np.array(params['scale'])
    counts = np.array(params['group_sizes'])
    old = np.load(ROOT / 'work/maize_environment_coverage/environment.npy')[:, [0, 2, 3, 4, 5]]
    om = pd.read_csv(ROOT / 'outputs/maize_baseline/sample_manifest.csv', usecols=['adm_id', 'year'])
    fit = om.year.between(2004, 2019).to_numpy() & om.adm_id.str.split('-').str[1].isin(['17', '18', '26', '39', '55']).to_numpy() & np.isfinite(old).all(1)
    assert fit.sum() == 6007
    reference = ((old[fit] - mean) / scale / np.sqrt(counts)).astype(np.float32)
    query = ((env[complete] - mean) / scale / np.sqrt(counts)).astype(np.float32)
    dist = np.full(len(w), np.nan)
    dist[complete] = neighbor_distance(query, reference)
    w['weather_complete'] = complete
    w['weather_distance'] = dist
    w['high_distance'] = dist >= d['high_cutoff']
    w['low_distance'] = dist <= d['old_low_max']
    w[['adm_id', 'year', 'state_fips', 'weather_complete', 'weather_distance', 'high_distance', 'low_distance']].to_csv(OUT / 'weather_distances.csv', index=False)
    rows = []
    for state, mc in meta.groupby('state_fips'):
        wc = w[w.state_fips == state]
        good = wc[wc.weather_complete]
        high = good[good.high_distance]
        n = len(good)
        median = float(good.weather_distance.median()) if n else np.nan
        fraction = n / len(mc)
        eligible = n >= 80 and good.adm_id.nunique() >= 20 and (fraction >= 0.95) and (median >= d['high_cutoff']) and (len(high) >= 50) and (high.adm_id.nunique() >= 15)
        rows.append({'state_fips': state, 'metadata_n': len(mc), 'calendar_geometry_soil_weather_n': len(wc), 'complete_n': n, 'complete_counties': good.adm_id.nunique(), 'completeness': fraction, 'distance_p10': float(good.weather_distance.quantile(0.1)) if n else np.nan, 'distance_median': median, 'distance_p90': float(good.weather_distance.quantile(0.9)) if n else np.nan, 'high_n': len(high), 'high_counties': high.adm_id.nunique(), 'eligible': eligible})
    states = pd.DataFrame(rows)
    states.to_csv(OUT / 'state_screening.csv', index=False)
    chosen = rank_states(states)
    selection = {'selected_states': chosen, 'policy_sha256': sha(OUT / 'design.json'), 'screening_sha256': sha(OUT / 'state_screening.csv'), 'distances_sha256': sha(OUT / 'weather_distances.csv'), 'reference_n': 6007, 'selection_outcome_blind': True, 'prediction_access': False}
    save('selection_manifest.json', selection)
    print('Selected states', chosen, flush=True)
    if not chosen:
        return (None, None)
    selected = w[w.state_fips.isin(chosen)].drop(columns=['weather_complete', 'weather_distance', 'high_distance', 'low_distance']).reset_index(drop=True)
    selected.to_csv(OUT / 'selected_metadata_before_outcome.csv', index=False)
    outcome = pd.read_csv(ROOT / 'outputs/maize_data_audit/candidate_labels_2004_2023.csv', usecols=['adm_id', 'harvest_year', 'yield']).rename(columns={'harvest_year': 'year'})
    selected = selected.merge(outcome, on=['adm_id', 'year'], validate='one_to_one')
    assert (selected['yield'] > 0).all()
    selected.to_csv(OUT / 'target_cohort_manifest.csv', index=False)
    selected.to_csv(OUT / 'date_windows.csv', index=False)
    return (selected, selection)

def inventory(w):
    import math, urllib.request
    ids = set(w.adm_id)
    tiles = set()
    reader = shapefile.Reader(str(ROOT / 'work/evi_geometry/US.shp'))
    for r in reader.iterShapeRecords():
        if r.record['adm_id'] not in ids:
            continue
        for lon, lat in r.shape.points:
            tiles.add((math.floor(18 + lon * math.cos(math.radians(lat)) / 10), math.floor(9 - lat / 10)))
    print('Cohort MODIS tiles', sorted(tiles), flush=True)
    allitems = []
    for h, v in sorted(tiles):
        file = WORK / f'inventory_{h}_{v}.json'
        if file.exists():
            allitems.extend(json.loads(file.read_text())['features'])
            continue
        payload = {'collections': ['modis-13Q1-061'], 'datetime': str(w.start.min().date()) + 'T00:00:00Z/' + str(w.cutoff.max().date()) + 'T23:59:59Z', 'query': {'modis:horizontal-tile': {'eq': h}, 'modis:vertical-tile': {'eq': v}}, 'limit': 1000}
        url = 'https://planetarycomputer.microsoft.com/api/stac/v1/search'
        features = []
        while url:
            for retry in range(3):
                try:
                    req = urllib.request.Request(url, data=json.dumps(payload).encode() if payload else None, headers={'Content-Type': 'application/json'})
                    res = json.loads(urllib.request.urlopen(req, timeout=60).read())
                    break
                except Exception:
                    if retry == 2:
                        raise
                    time.sleep(2)
            features.extend(res['features'])
            nxt = next((l for l in res.get('links', []) if l.get('rel') == 'next'), None)
            url = nxt['href'] if nxt else None
            payload = nxt.get('body') if nxt and nxt.get('method') == 'POST' else None
        file.write_text(json.dumps({'features': features}), encoding='utf-8')
        allitems.extend(features)
        print('Inventory tile', h, v, len(features), flush=True)
    unique = {}
    for item in allitems:
        p = item['properties']
        start = pd.Timestamp(p['start_datetime']).tz_localize(None).normalize()
        end = pd.Timestamp(p['end_datetime']).tz_localize(None).normalize()
        key = (p['modis:horizontal-tile'], p['modis:vertical-tile'], p['start_datetime'])
        if not ((w.start <= start) & (w.cutoff >= end)).any():
            continue
        if key not in unique or (p['created'], item['id']) > (unique[key]['properties']['created'], unique[key]['id']):
            unique[key] = item
    items = sorted(unique.values(), key=lambda i: (i['properties']['start_datetime'], i['id']))
    return items

def extract(item, path, sas, ncounties):
    output = WORK / (item['id'] + '.npz')
    if output.exists():
        return (item['id'], 'cached')
    try:
        with np.load(path) as g:
            labels = g['labels']
            weight = g['weight']
            win = Window(*[int(v) for v in g['window']])
            arrays = []
            with rasterio.Env(**ENV):
                for name in BANDS:
                    with rasterio.open(item['assets'][name]['href'] + '?' + sas) as ds:
                        np.testing.assert_allclose(tuple(ds.transform)[:6], g['transform'], rtol=0, atol=1e-06)
                        assert ds.crs == rasterio.crs.CRS.from_wkt(str(g['crs']))
                        arrays.append(ds.read(1, window=win))
        evi, ndvi, quality, doy = arrays
        p = item['properties']
        good = period_good(weight, quality, evi, ndvi, doy, pd.Timestamp(p['start_datetime']), pd.Timestamp(p['end_datetime']))
        ids = labels[good]
        ww = weight[good].astype(float)
        n = ncounties + 1
        np.savez_compressed(output, evi_sum=np.bincount(ids, weights=ww * evi[good] * 0.0001, minlength=n), ndvi_sum=np.bincount(ids, weights=ww * ndvi[good] * 0.0001, minlength=n), valid_weight=np.bincount(ids, weights=ww, minlength=n), valid_pixels=np.bincount(ids, minlength=n))
        return (item['id'], 'done')
    except Exception as exc:
        return (item['id'], 'error:' + type(exc).__name__)

def acquire(w, d):
    global rasterio, shapefile, certifi, rasterize, bounds, transform_geom, WarpedVRT, Resampling, Window, BANDS, ENV
    sys.path.insert(0, str(ROOT / 'work/evi_libs'))
    sys.path.insert(0, str(ROOT / 'work/maize_external_region'))
    import rasterio, shapefile, certifi
    from rasterio.features import rasterize, bounds
    from rasterio.warp import transform_geom
    from rasterio.vrt import WarpedVRT
    from rasterio.enums import Resampling
    from rasterio.windows import Window
    BANDS = ['250m_16_days_EVI', '250m_16_days_NDVI', '250m_16_days_pixel_reliability', '250m_16_days_composite_day_of_the_year']
    ENV = {'GDAL_DISABLE_READDIR_ON_OPEN': 'EMPTY_DIR', 'CPL_VSIL_CURL_ALLOWED_EXTENSIONS': '.tif', 'GDAL_HTTP_TIMEOUT': '30', 'CURL_CA_BUNDLE': certifi.where(), 'CPL_LOG': 'NUL', 'GDAL_CACHEMAX': 64 * 1024 * 1024}
    data = raw8(w, 'base9')
    data['y'] = w['yield'].to_numpy(np.float32)
    ids = sorted(w.adm_id.unique())
    items = inventory(w)
    taskmanifest = {'selection_sha256': sha(OUT / 'selection_manifest.json'), 'windows_sha256': sha(OUT / 'date_windows.csv'), 'sample_n': len(w), 'county_n': len(ids), 'T': data['x'].shape[1], 'tasks': [{'id': i['id'], 'start': i['properties']['start_datetime'], 'end': i['properties']['end_datetime'], 'tile': [i['properties']['modis:horizontal-tile'], i['properties']['modis:vertical-tile']]} for i in items], 'no_target_fitting': True}
    if (OUT / 'acquisition_manifest.json').exists():
        assert json.loads((OUT / 'acquisition_manifest.json').read_text()) == taskmanifest
    else:
        save('acquisition_manifest.json', taskmanifest)
    geo = geometries(items, ids)
    gross = np.zeros(len(ids) + 1)
    for path in geo.values():
        with np.load(path) as g:
            gross += np.bincount(g['labels'].ravel(), weights=g['weight'].ravel(), minlength=len(gross))
    assert (gross[1:] > 0).all()
    done = 0
    errors = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        for first in range(0, len(items), 8):
            sas = token()
            batch = items[first:first + 8]
            fs = [pool.submit(extract, i, geo[i['properties']['modis:horizontal-tile'], i['properties']['modis:vertical-tile']], sas, len(ids)) for i in batch]
            for item, f in zip(batch, fs):
                iid, status = f.result()
                if status.startswith('error'):
                    for retry in range(2):
                        time.sleep(2)
                        iid, status = extract(item, geo[item['properties']['modis:horizontal-tile'], item['properties']['modis:vertical-tile']], token(), len(ids))
                        if not status.startswith('error'):
                            break
                if status.startswith('error'):
                    errors.append({'id': iid, 'status': status})
                done += 1
            save('progress.json', {'processed': done, 'total': len(items), 'errors': errors, 'complete': False})
            print('EVI', done, '/', len(items), 'errors', len(errors), flush=True)
    if errors:
        raise RuntimeError('Missing remote tasks')
    grouped = {}
    for item in items:
        p = item['properties']
        key = (p['start_datetime'][:10], p['end_datetime'][:10])
        total = grouped.setdefault(key, [np.zeros(len(ids) + 1) for _ in range(4)])
        with np.load(WORK / (item['id'] + '.npz')) as g:
            for a, k in zip(total, ['evi_sum', 'ndvi_sum', 'valid_weight', 'valid_pixels']):
                a += g[k]
    records = []
    idindex = {c: i + 1 for i, c in enumerate(ids)}
    for (st, en), (es, ns, v, c) in sorted(grouped.items()):
        start = pd.Timestamp(st)
        end = pd.Timestamp(en)
        for r in w[(w.start <= start) & (w.cutoff >= end)].itertuples():
            idx = idindex[r.adm_id]
            coverage = v[idx] / gross[idx]
            obs = coverage >= 0.2 and v[idx] > 0
            records.append({'adm_id': r.adm_id, 'year': r.year, 'period_start': st, 'period_end': en, 'cutoff': str(r.cutoff.date()), 'evi': es[idx] / v[idx] if obs else np.nan, 'matched_ndvi': ns[idx] / v[idx] if obs else np.nan, 'valid_crop_weight_fraction': coverage, 'valid_pixels': int(c[idx]), 'observed': obs, 'bin': int((end - r.start).days // 10)})
    table = pd.DataFrame(records)
    table.to_csv(OUT / 'county_period_features.csv', index=False)
    stats = table.groupby(['adm_id', 'year', 'bin']).evi.mean()
    x = np.full((*data['x'].shape[:2], 10), np.nan, np.float32)
    x[:, :, :9] = data['x']
    lookup = {(r.adm_id, r.year): i for i, r in enumerate(w.itertuples())}
    for (c, y, b), value in stats.items():
        idx = lookup[c, y]
        assert b < data['lengths'][idx]
        x[idx, b, 9] = value
    valid = np.arange(x.shape[1])[None, :] < data['lengths'][:, None]
    assert np.isnan(x[~valid]).all() and np.isfinite(data['static']).all() and np.isfinite(x[:, :, 8][valid]).all()
    np.testing.assert_array_equal(x[:, :, :9], data['x'])
    data['x'] = x
    np.savez_compressed(WORK / 'dataset.npz', **data)
    save('feature_order.json', {'dynamic_features': FEATURES, 'static_features': STATIC})
    report = {'verified': True, 'samples': len(w), 'counties': len(ids), 'shape': list(x.shape), 'max_valid_length': int(w.length.max()), 'previous_year_windows': int((w.start.dt.year < w.year).sum()), 'EVI_previous_year_period_rows': int((pd.to_datetime(table.period_start).dt.year < table.year).sum()), 'missing_fraction_valid_steps': {f: float(np.isnan(x[:, :, i][valid]).mean()) for i, f in enumerate(FEATURES)}, 'source_overlap': 0, 'excluded_samples': 0, 'all_counties_crop_weight_positive': True, 'no_target_fitting': True, 'new_geography': True, 'new_years': False, 'historical_product_release_not_certified': True, 'dataset_sha256': sha(WORK / 'dataset.npz'), 'design_sha256': sha(OUT / 'design.json'), 'selection_sha256': sha(OUT / 'selection_manifest.json'), 'tasks': len(items), 'dependencies_unchanged': all((sha(ROOT / k) == v for k, v in d['dependencies'].items()))}
    assert report['dependencies_unchanged']
    save('verification.json', report)
    save('metadata.json', {**report, 'dynamic_features': FEATURES, 'static_features': STATIC, 'dataset_path': str(WORK / 'dataset.npz')})
    save('progress.json', {'processed': len(items), 'total': len(items), 'errors': [], 'complete': True})
    print('DATASET VERIFIED', list(x.shape), flush=True)

def run():
    torch.set_num_threads(4)
    d = policy()
    w, selection = screen(d)
    if w is None:
        save('verification.json', {'complete_screen': True, 'eligible_states': 0, 'no_threshold_relaxation': True})
        return
    print('Selection frozen before EVI; selected samples', len(w), flush=True)
    acquire(w, d)
if __name__ == '__main__':
    raise SystemExit('Use scripts/train_mainline.py for mainline fitting or the saved-result analysis scripts. This historical entry is retained for method provenance, not default execution.')
