import sys as _sys
from pathlib import Path as _Path
_release_root = _Path(__file__).resolve().parents[2]
_sys.path.insert(0, str(_release_root))
from release_support import configured_path as _configured_path, prepare_transfer as _prepare_transfer
'New evaluation must use source transforms and not padded/future target information.'
import importlib.util
import unittest
import numpy as np

class FrozenInputContract(unittest.TestCase):

    def test_source_transform_and_valid_steps(self):
        self.assertIsNotNone(importlib.util.find_spec('high_weather_eval'), 'Evaluator is missing')
        import high_weather_eval as h
        data = {'x': np.array([[[30.0, np.nan], [np.nan, 14.0], [999.0, 999.0]]], np.float32), 'static': np.array([[30.0, np.nan]], np.float32), 'lengths': np.array([2]), 'y': np.array([999.0])}
        params = {'median': [10.0, 10.0], 'mean': [10.0, 10.0], 'scale': [2.0, 2.0], 'static_median': [10.0, 10.0], 'static_mean': [10.0, 10.0], 'static_scale': [2.0, 2.0]}
        seq, soil = h.frozen_arrays(data, params)
        np.testing.assert_array_equal(seq, [[[10.0, 0.0, 1.0, 0.0, 1.0], [0.0, 2.0, 0.0, 1.0, 1.0], [0.0, 0.0, 0.0, 0.0, 0.0]]])
        np.testing.assert_array_equal(soil, [[10.0, 0.0]])
        data['y'] = np.array([-12345.0])
        again = h.frozen_arrays(data, params)
        np.testing.assert_array_equal(again[0], seq)
        np.testing.assert_array_equal(again[1], soil)
if __name__ == '__main__':
    raise SystemExit('Use scripts/train_mainline.py for mainline fitting or the saved-result analysis scripts. This historical entry is retained for method provenance, not default execution.')
