import sys as _sys
from pathlib import Path as _Path
_release_root = _Path(__file__).resolve().parents[2]
_sys.path.insert(0, str(_release_root))
from release_support import configured_path as _configured_path, prepare_transfer as _prepare_transfer
import unittest
import numpy as np
import pandas as pd
from prepare import join_windows, aggregate_harvest, weather_bins, rank_states, period_good

class Contract(unittest.TestCase):

    def test_previous_year_join_and_cutoff(self):
        w = pd.DataFrame({'adm_id': ['A'], 'year': [2020], 'start': [pd.Timestamp('2019-12-01')], 'cutoff': [pd.Timestamp('2020-01-10')]})
        f = pd.DataFrame({'adm_id': ['A', 'A', 'A', 'B'], 'date': [20191201, 20200110, 20200111, 20191201], 'prec': [2.0, 3.0, 999.0, 8.0]})
        got = join_windows(f, w)
        self.assertEqual(got.year.tolist(), [2020, 2020])
        self.assertEqual(got.prec.sum(), 5)
        ag = aggregate_harvest(f, w, {'prec': 'sum'})
        self.assertEqual(ag.prec_sum.sum(), 5)

    def test_gdd_future_causal(self):
        f = pd.DataFrame({'observed_date': pd.date_range('2020-01-01', periods=12), 'tmin': [0.0] * 12, 'tmax': [40.0] * 12, 'prec': [0.0] * 12})
        got = weather_bins(f, pd.Timestamp('2019-12-22'), pd.Timestamp('2020-01-01'), pd.Timestamp('2020-01-12'), 3)
        np.testing.assert_array_equal(got[:, 0], [0, 100, 120])
        f.loc[11, 'tmax'] = 999
        early = weather_bins(f, pd.Timestamp('2019-12-22'), pd.Timestamp('2020-01-01'), pd.Timestamp('2020-01-10'), 2)
        np.testing.assert_array_equal(early[:, 0], got[:2, 0])

    def test_wrap_doy_and_qa(self):
        good = period_good(np.array([0.2, 0.2, 0.2, 0.2]), np.array([0, 0, 0, 1]), np.array([100, 100, 100, 100]), np.array([200, 200, 200, 200]), np.array([362, 5, 200, 362]), pd.Timestamp('2019-12-27'), pd.Timestamp('2020-01-11'))
        np.testing.assert_array_equal(good, [True, True, False, False])

    def test_rank_uses_distance_counts_only(self):
        rows = pd.DataFrame([dict(state_fips='48', eligible=True, distance_median=1.0, high_n=80), dict(state_fips='40', eligible=True, distance_median=1.0, high_n=90), dict(state_fips='08', eligible=False, distance_median=9.0, high_n=90)])
        self.assertEqual(rank_states(rows), ['40', '48'])
if __name__ == '__main__':
    raise SystemExit('Use scripts/train_mainline.py for mainline fitting or the saved-result analysis scripts. This historical entry is retained for method provenance, not default execution.')
