import sys as _sys
from pathlib import Path as _Path
_release_root = _Path(__file__).resolve().parents[2]
_sys.path.insert(0, str(_release_root))
from release_support import configured_path as _configured_path, prepare_transfer as _prepare_transfer
'Read-only historical dependency check before new target prediction.'
import hashlib
import json
import sys
from pathlib import Path
OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for part in iter(lambda: stream.read(4 * 1024 * 1024), b''):
            h.update(part)
    return h.hexdigest()

def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))

def run():
    dictionaries = []
    records = 0
    sources = [ROOT / 'outputs/maize_budget_controls/manifest.json', ROOT / 'outputs/maize_budget_controls/verification.json', ROOT / 'outputs/maize_fusion_transfer/verification.json', ROOT / 'outputs/maize_gain_sources/verification.json']
    for file in sources:
        record = read(file)
        if file.name == 'verification.json':
            assert record['verified']
        for key in ['sha256', 'model_sha256', 'output_sha256', 'outputs_sha256', 'cache_sha256']:
            if key in record:
                mapping = {str((file.parent / Path(p)).resolve()) if not Path(p).is_absolute() else str(Path(p).resolve()): value for p, value in record[key].items()}
                dictionaries.append(mapping)
                records += len(mapping)
    expected = {}
    for mapping in dictionaries:
        for path, digest in mapping.items():
            if path in expected:
                assert expected[path] == digest, 'Contradictory historical hash'
            expected[path] = digest
    for path, digest in expected.items():
        assert sha(path) == digest, path
    executed = [ROOT / 'outputs/maize_fusion_screen/screen.py', ROOT / 'outputs/maize_fusion_transfer/transfer.py', ROOT / 'outputs/maize_anomaly_transfer/experiment.py', ROOT / 'outputs/maize_baseline/pipeline.py', ROOT / 'outputs/maize_baseline/train.py', ROOT / 'outputs/maize_gain_sources/controls.py', ROOT / 'outputs/maize_environment_coverage/coverage_analysis.py', ROOT / 'outputs/maize_group_interventions/interventions.py', ROOT / 'outputs/maize_budget_controls/budget_controls.py', ROOT / 'outputs/maize_external_region/evaluate.py']
    previous = read(ROOT / 'outputs/maize_external_region/evaluation_verification.json')
    assert previous['verified'] and sha(executed[-1]) == previous['code_sha256']
    missing = []
    for file in executed[:-1]:
        if str(file.resolve()) not in expected:
            missing.append(file)
    coverage = read(ROOT / 'outputs/maize_environment_coverage/run_complete.json')
    coverage_hashes = {str(Path(p).resolve()): v for p, v in coverage['source_sha256'].items()}
    for file in missing:
        path = str(file.resolve())
        assert path in coverage_hashes, 'Executed old source not historically bound: ' + path
        assert sha(path) == coverage_hashes[path], path
        expected[path] = coverage_hashes[path]
    source_protocol = read(OUT / 'model_protocol.json')
    for path, digest in source_protocol['sha256'].items():
        assert sha(path) == digest, path
    checks = {'verified': True, 'historical_hash_records': records, 'historical_unique_files': len(expected), 'historical_inputs_unchanged': True, 'executed_old_code_sha256': {str(p): sha(p) for p in executed}, 'source_verification_sha256': {str(p): sha(p) for p in sources}, 'model_protocol_sha256': sha(OUT / 'model_protocol.json'), 'audit_code_sha256': sha(__file__), 'before_target_prediction': not (OUT / 'predictions.csv').exists()}
    (OUT / 'preflight_verification.json').write_text(json.dumps(checks, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print('HISTORICAL PREFLIGHT VERIFIED', records, len(expected), flush=True)
if __name__ == '__main__':
    raise SystemExit('Use scripts/train_mainline.py for mainline fitting or the saved-result analysis scripts. This historical entry is retained for method provenance, not default execution.')
