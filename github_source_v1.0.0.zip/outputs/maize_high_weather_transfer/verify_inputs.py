import sys as _sys
from pathlib import Path as _Path
_release_root = _Path(__file__).resolve().parents[2]
_sys.path.insert(0, str(_release_root))
from release_support import configured_path as _configured_path, prepare_transfer as _prepare_transfer
'Independent raw-input reassembly and frozen-selection verification.'
import hashlib, json, pathlib, zipfile
import numpy as np
import pandas as pd
OUT = pathlib.Path(__file__).resolve().parent
ROOT = OUT.parents[1]
WORK = ROOT / 'work/maize_high_weather_transfer'

def sha(p):
    h = hashlib.sha256()
    with pathlib.Path(p).open('rb') as f:
        for b in iter(lambda: f.read(4 * 1024 * 1024), b''):
            h.update(b)
    return h.hexdigest()

def run():
    d = json.loads((OUT / 'design.json').read_text())
    selection = json.loads((OUT / 'selection_manifest.json').read_text())
    acq = json.loads((OUT / 'acquisition_manifest.json').read_text())
    v = json.loads((OUT / 'verification.json').read_text())
    assert v['verified']
    assert sha(WORK / 'dataset.npz') == v['dataset_sha256']
    w = pd.read_csv(OUT / 'date_windows.csv', parse_dates=['start', 'cutoff', 'sos_date', 'eos_date'], dtype={'state_fips': str})
    m = pd.read_csv(OUT / 'target_cohort_manifest.csv', dtype={'state_fips': str})
    states = pd.read_csv(OUT / 'state_screening.csv', dtype={'state_fips': str})
    dist = pd.read_csv(OUT / 'weather_distances.csv', dtype={'state_fips': str})
    eligible = states[states.eligible].sort_values(['distance_median', 'high_n', 'state_fips'], ascending=[False, False, True])
    assert eligible.head(2).state_fips.tolist() == selection['selected_states']
    assert set(m.state_fips) == set(selection['selected_states'])
    assert ((w.sos_date - w.start).dt.days == 90).all() and ((w.eos_date - w.cutoff).dt.days == 60).all()
    assert (w.length == (w.cutoff - w.start).dt.days // 10 + 1).all()
    for t in acq['tasks']:
        assert t['id'].startswith('MOD13Q1.')
        s = pd.Timestamp(t['start']).tz_localize(None).normalize()
        e = pd.Timestamp(t['end']).tz_localize(None).normalize()
        assert ((w.start <= s) & (w.cutoff >= e)).any()
    with np.load(WORK / 'dataset.npz') as z:
        data = {k: z[k] for k in z.files}
    with np.load(WORK / 'base9.npz') as z:
        base = {k: z[k] for k in z.files}
    x = data['x']
    np.testing.assert_array_equal(x[:, :, :9], base['x'])
    np.testing.assert_array_equal(data['counties'], w.adm_id)
    np.testing.assert_array_equal(data['years'], w.year)
    np.testing.assert_array_equal(data['lengths'], w.length)
    np.testing.assert_array_equal(data['y'], w['yield'].to_numpy(np.float32))
    np.testing.assert_array_equal(data['static'], w[['awc', 'bulk_density']].to_numpy(np.float32))
    valid = np.arange(x.shape[1])[None, :] < data['lengths'][:, None]
    assert np.isnan(x[~valid]).all() and np.isfinite(data['static']).all()
    assert np.isfinite(x[:, :, 8][valid]).all()
    old = pd.read_csv(ROOT / 'outputs/maize_baseline/sample_manifest.csv', usecols=['adm_id'])
    assert not set(old.adm_id) & set(w.adm_id)
    table = pd.read_csv(OUT / 'county_period_features.csv', parse_dates=['period_start', 'period_end', 'cutoff'])
    joined = table.merge(w[['adm_id', 'year', 'start', 'cutoff', 'length']], on=['adm_id', 'year'], validate='many_to_one', suffixes=('', '_window'))
    assert (joined.period_start >= joined.start).all() and (joined.period_end <= joined.cutoff_window).all()
    assert ((joined.period_end - joined.start).dt.days // 10 == joined['bin']).all()
    assert (joined['bin'] < joined.length).all()
    assert (table.observed == (table.valid_crop_weight_fraction >= 0.2) & (table.valid_pixels > 0)).all()
    assert np.isfinite(table.loc[table.observed, 'evi']).all() and table.loc[~table.observed, 'evi'].isna().all()
    re = np.full(x.shape[:2], np.nan, np.float32)
    lookup = {(c, int(y)): i for i, (c, y) in enumerate(zip(data['counties'], data['years']))}
    for (c, y, b), value in table.groupby(['adm_id', 'year', 'bin']).evi.mean().items():
        re[lookup[c, int(y)], int(b)] = value
    np.testing.assert_array_equal(re, x[:, :, 9])
    ids = sorted(set(w.adm_id))
    gross = np.zeros(len(ids) + 1)
    for file in WORK.glob('geometry_*.npz'):
        with np.load(file) as g:
            labels = g['labels']
            weight = g['weight']
            assert labels.shape == weight.shape
            assert labels.max() <= len(ids)
            assert np.isfinite(weight).all() and (weight >= 0).all() and (weight <= 100).all()
            assert (weight[labels == 0] == 0).all()
            gross += np.bincount(labels.ravel(), weights=weight.ravel(), minlength=len(gross))
    assert (gross[1:] > 0).all()
    taskids = [t['id'] for t in acq['tasks']]
    assert len(taskids) == len(set(taskids))
    taskkeys = [(tuple(t['tile']), t['start'], t['end']) for t in acq['tasks']]
    assert len(taskkeys) == len(set(taskkeys))
    assert {p.stem for p in WORK.glob('MOD13Q1.*.npz')} == set(taskids)
    grouped = {}
    for task in acq['tasks']:
        start = pd.Timestamp(task['start']).tz_localize(None).normalize()
        end = pd.Timestamp(task['end']).tz_localize(None).normalize()
        key = (start, end)
        total = grouped.setdefault(key, [np.zeros(len(ids) + 1) for _ in range(4)])
        with np.load(WORK / (task['id'] + '.npz')) as z:
            assert set(z.files) == {'evi_sum', 'ndvi_sum', 'valid_weight', 'valid_pixels'}
            for arr, name in zip(total, ['evi_sum', 'ndvi_sum', 'valid_weight', 'valid_pixels']):
                a = z[name]
                assert a.shape == (len(ids) + 1,) and np.isfinite(a).all()
                arr += a
            assert (z['valid_weight'] >= 0).all() and (z['valid_pixels'] >= 0).all()
    expected = []
    countyindex = {c: i + 1 for i, c in enumerate(ids)}
    for (start, end), (es, ns, weight, pixels) in sorted(grouped.items()):
        for row in w[(w.start <= start) & (w.cutoff >= end)].itertuples():
            idx = countyindex[row.adm_id]
            fraction = weight[idx] / gross[idx]
            observed = fraction >= 0.2 and weight[idx] > 0
            expected.append({'adm_id': row.adm_id, 'year': row.year, 'period_start': start, 'period_end': end, 'evi': es[idx] / weight[idx] if observed else np.nan, 'matched_ndvi': ns[idx] / weight[idx] if observed else np.nan, 'valid_crop_weight_fraction': fraction, 'valid_pixels': int(pixels[idx]), 'observed': observed, 'bin': int((end - row.start).days // 10)})
    expected = pd.DataFrame(expected)
    keys = ['adm_id', 'year', 'period_start', 'period_end']
    assert not table.duplicated(keys).any() and (not expected.duplicated(keys).any())
    actual = table.sort_values(keys).reset_index(drop=True)
    expected = expected.sort_values(keys).reset_index(drop=True)
    assert len(actual) == len(expected)
    pd.testing.assert_frame_equal(actual[keys], expected[keys], check_dtype=False)
    for name in ['evi', 'matched_ndvi', 'valid_crop_weight_fraction']:
        np.testing.assert_allclose(actual[name], expected[name], rtol=1e-12, atol=1e-12, equal_nan=True)
    for name in ['valid_pixels', 'observed', 'bin']:
        np.testing.assert_array_equal(actual[name], expected[name])
    assert all((sha(ROOT / k) == value for k, value in d['dependencies'].items()))
    assert selection['policy_sha256'] == sha(OUT / 'design.json')
    assert selection['screening_sha256'] == sha(OUT / 'state_screening.csv')
    assert selection['distances_sha256'] == sha(OUT / 'weather_distances.csv')
    chosen = dist[dist.state_fips.isin(selection['selected_states'])]
    assert len(chosen) == len(w)
    assert (chosen.high_distance == (chosen.weather_distance >= d['high_cutoff'])).all()
    assert (chosen.low_distance == (chosen.weather_distance <= d['old_low_max'])).all()
    codefiles = ['prepare.py', 'resume_prepare.py', 'verify_inputs.py', 'test_preparation.py']
    artifactfiles = ['design.json', 'screening_policy.json', 'selection_manifest.json', 'acquisition_manifest.json', 'acquisition_sensor_correction.json', 'date_windows.csv', 'target_cohort_manifest.csv', 'county_period_features.csv', 'state_screening.csv', 'weather_distances.csv']
    result = {'verified': True, 'shape': list(x.shape), 'samples': len(w), 'counties': len(ids), 'high_samples': int(chosen.high_distance.sum()), 'high_counties': chosen[chosen.high_distance].adm_id.nunique(), 'Terra_only_tasks': len(acq['tasks']), 'task_ids_unique_complete': True, 'complete_expected_county_period_rows': len(expected), 'tile_cache_to_complete_county_period_table': True, 'no_source_county_overlap': True, 'independent_EVI_table_reassembly': True, 'base9_exact': True, 'geometry_weights_valid': True, 'calendar_bins_padding_valid': True, 'frozen_selection_reproduced': True, 'source_dependencies_unchanged': True, 'data_sha256': sha(WORK / 'dataset.npz'), 'code_sha256': {f: sha(OUT / f) for f in codefiles}, 'artifacts_sha256': {f: sha(OUT / f) for f in artifactfiles}, 'base9_sha256': sha(WORK / 'base9.npz'), 'tile_summary_sha256': {t['id']: sha(WORK / (t['id'] + '.npz')) for t in acq['tasks']}, 'geometry_sha256': {p.name: sha(p) for p in WORK.glob('geometry_*.npz')}}
    (OUT / 'independent_input_verification.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
    print(json.dumps({k: v for k, v in result.items() if not isinstance(v, dict)}), flush=True)
    with zipfile.ZipFile(_configured_path('external_e22e1afd74')) as z:
        names = ['crop_calendar', 'soil', 'meteo', 'ndvi', 'soil_moisture']
        provenance = {n: {'archive_member': 'cybench-data/maize/US/' + n + '_maize_US.csv', 'CRC32': f"{z.getinfo('cybench-data/maize/US/' + n + '_maize_US.csv').CRC:08x}", 'bytes': z.getinfo('cybench-data/maize/US/' + n + '_maize_US.csv').file_size} for n in names}
    (OUT / 'raw_provenance.json').write_text(json.dumps({'archive_sha256': sha(_configured_path('external_e22e1afd74')), 'members': provenance, 'tile_summary_sha256': {t['id']: sha(WORK / (t['id'] + '.npz')) for t in acq['tasks']}, 'geometry_sha256': {p.name: sha(p) for p in WORK.glob('geometry_*.npz')}}, indent=2), encoding='utf-8')
if __name__ == '__main__':
    raise SystemExit('Use scripts/train_mainline.py for mainline fitting or the saved-result analysis scripts. This historical entry is retained for method provenance, not default execution.')
