import sys as _sys
from pathlib import Path as _Path
_release_root = _Path(__file__).resolve().parents[2]
_sys.path.insert(0, str(_release_root))
from release_support import configured_path as _configured_path, prepare_transfer as _prepare_transfer
import unittest
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'maize_fixed_gates'))
import gates
import torch
import learned
import concat_control

class GateTests(unittest.TestCase):

    def test_concat_same_initial_information_and_capacity(self):
        template = gates.Teacher().head.eval()
        model = concat_control.Concat(template).eval()
        bank = torch.randn(7, 5, 16)
        torch.testing.assert_close(model(bank), template(bank.mean(1)).squeeze(1), rtol=1e-05, atol=1e-06)
        self.assertEqual(sum((p.numel() for p in model.parameters())), 3281)

    def test_uniform_initial_function_and_capacity(self):
        self.assertTrue(hasattr(learned, 'Fusion'), 'Fusion missing')
        template = gates.Teacher().head.eval()
        bank = torch.randn(6, 5, 16)
        expected = template(bank.mean(1)).squeeze(1)
        for mode in ['learned_global', 'learned_dynamic', 'uniform_capacity']:
            model = learned.Fusion(template, mode).eval()
            values, weights = model(bank, return_weights=True)
            torch.testing.assert_close(values, expected, rtol=1e-05, atol=1e-06)
            torch.testing.assert_close(weights, torch.ones(6, 5) / 5)
        dynamic = learned.Fusion(template, 'learned_dynamic')
        capacity = learned.Fusion(template, 'uniform_capacity')
        self.assertEqual(sum((p.numel() for p in dynamic.parameters())), 3334)
        self.assertEqual(sum((p.numel() for p in capacity.parameters())), 3331)

    def test_global_weights_receive_gradient(self):
        self.assertTrue(hasattr(learned, 'Fusion'), 'Fusion missing')
        model = learned.Fusion(gates.Teacher().head, 'learned_global')
        model(torch.randn(8, 5, 16)).sum().backward()
        self.assertTrue(torch.isfinite(model.logits.grad).all())
        self.assertGreater(float(model.logits.grad.abs().sum()), 0.0)
if __name__ == '__main__':
    raise SystemExit('Use scripts/train_mainline.py for mainline fitting or the saved-result analysis scripts. This historical entry is retained for method provenance, not default execution.')
