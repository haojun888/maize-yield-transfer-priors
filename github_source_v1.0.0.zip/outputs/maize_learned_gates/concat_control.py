import sys as _sys
from pathlib import Path as _Path
_release_root = _Path(__file__).resolve().parents[2]
_sys.path.insert(0, str(_release_root))
from release_support import configured_path as _configured_path, prepare_transfer as _prepare_transfer
'Information-access control: concatenated frozen bank, no gate.'
import copy
import hashlib
import json
import time
from pathlib import Path
import numpy as np
import pandas as pd
import torch
from torch import nn
from torch.utils.data import TensorDataset, DataLoader
import learned as l

class Concat(nn.Module):

    def __init__(self, template):
        super().__init__()
        self.head = nn.Sequential(nn.Linear(80, 40), nn.ReLU(), nn.Dropout(0.1), nn.Linear(40, 1))
        with torch.no_grad():
            for j in range(5):
                self.head[0].weight[:32, j * 16:(j + 1) * 16].copy_(template[0].weight / 5)
            self.head[0].bias[:32].copy_(template[0].bias)
            self.head[3].weight.zero_()
            self.head[3].weight[:, :32].copy_(template[3].weight)
            self.head[3].bias.copy_(template[3].bias)

    def forward(self, bank):
        return self.head(bank.flatten(1)).squeeze(1)

def predict(model, bank, mean, std):
    model.eval()
    parts = []
    with torch.no_grad():
        for chunk in np.array_split(bank, max(1, int(np.ceil(len(bank) / 512)))):
            parts.append(model(torch.from_numpy(chunk).to(l.g.DEVICE)).cpu().numpy() * std + mean)
    return np.concatenate(parts)

def train(template, bank, residual, fit, val, seed, epochs=60):
    l.g.seed_all(seed + 992)
    model = Concat(template).to(l.g.DEVICE)
    l.g.seed_all(seed + 991)
    mean = float(residual[fit].mean())
    std = float(residual[fit].std())
    loader = DataLoader(TensorDataset(torch.from_numpy(bank[fit]), torch.from_numpy(((residual[fit] - mean) / std).astype(np.float32))), batch_size=512, shuffle=True, generator=torch.Generator().manual_seed(seed + 991), num_workers=0)
    opt = torch.optim.Adam(model.parameters(), lr=0.001, weight_decay=0.0001)
    best = float('inf')
    state = None
    stale = 0
    bestepoch = epochs
    history = []
    for epoch in range(1, epochs + 1):
        model.train()
        total = 0.0
        for xb, yb in loader:
            opt.zero_grad(set_to_none=True)
            loss = nn.functional.mse_loss(model(xb.to(l.g.DEVICE)), yb.to(l.g.DEVICE))
            loss.backward()
            opt.step()
            total += float(loss.detach().cpu()) * len(xb)
        row = {'epoch': epoch, 'train_mse': total / int(fit.sum())}
        if val is not None:
            score = l.g.e.metrics(residual[val], predict(model, bank[val], mean, std))['rmse_t_ha']
            row['val_rmse'] = score
            if score < best - 1e-05:
                best = score
                stale = 0
                state = copy.deepcopy(model.state_dict())
                bestepoch = epoch
            else:
                stale += 1
        history.append(row)
        if val is not None and stale >= 8:
            break
    if state is not None:
        model.load_state_dict(state)
    return (model, mean, std, bestepoch, history)

def run():
    started = time.time()
    d = np.load(l.g.e.CACHE / 'dataset.npz')
    x, soil, lengths, y, years, counties = [d[k] for k in ['x', 'static', 'lengths', 'y', 'years', 'counties']]
    fingerprint = hashlib.sha256(Path(__file__).read_bytes() + Path(l.__file__).read_bytes() + Path(l.g.__file__).read_bytes() + hashlib.sha256((l.g.e.CACHE / 'dataset.npz').read_bytes()).digest()).hexdigest()
    allrows = []
    for protocol in ['T', 'E_to_W', 'W_to_E']:
        split = l.g.e.make_split(years, counties, protocol)
        for seed in l.g.e.SEEDS:
            folder = l.OUT / f'{protocol}_{seed}'
            folder.mkdir(exist_ok=True)
            if (folder / 'concat_complete.json').exists():
                old = json.loads((folder / 'concat_complete.json').read_text())
                if old['fingerprint'] != fingerprint:
                    raise ValueError('Concat fingerprint changed')
                allrows.append(pd.read_csv(folder / 'concat_predictions.csv'))
                continue
            teacher, bank = l.load_bank(l.g.OUT / f'{protocol}_{seed}', x, soil, lengths)
            bg = json.loads((l.g.OUT / f'{protocol}_{seed}' / 'background.json').read_text())
            base = {k: l.g.e.background_predict(bg[k], years, counties) for k in ['selection', 'final_fit']}
            residual = {k: (y - v).astype(np.float32) for k, v in base.items()}
            model, ym, ys, epochs, h = train(teacher.head, bank, residual['selection'], split['train'], split['val'], seed)
            val = l.g.e.metrics(y[split['val']], predict(model, bank[split['val']], ym, ys) + base['selection'][split['val']])
            model, ym, ys, _, h2 = train(teacher.head, bank, residual['final_fit'], split['fit'], None, seed, epochs)
            rows = []
            for scenario, mask in split.items():
                if scenario not in ['time', 'space', 'joint']:
                    continue
                rows.append(pd.DataFrame({'protocol': protocol, 'scenario': scenario, 'variant': 'concat_capacity', 'seed': seed, 'adm_id': counties[mask], 'year': years[mask], 'observed_yield_t_ha': y[mask], 'predicted_yield_t_ha': predict(model, bank[mask], ym, ys) + base['final_fit'][mask]}))
            frame = pd.concat(rows, ignore_index=True)
            frame.to_csv(folder / 'concat_predictions.csv', index=False)
            torch.save({'state_dict': model.cpu().state_dict(), 'target_mean': ym, 'target_std': ys, 'epochs': epochs, 'seed': seed, 'parameters': sum((p.numel() for p in model.parameters()))}, folder / 'concat_capacity.pt')
            l.g.e.save_json(folder / 'concat_selection.json', {'best_epoch': epochs, **val})
            for r in h:
                r['phase'] = 'selection'
            for r in h2:
                r['phase'] = 'final_fit'
            pd.DataFrame(h + h2).to_csv(folder / 'concat_history.csv', index=False)
            l.g.e.save_json(folder / 'concat_complete.json', {'fingerprint': fingerprint, 'source_teacher_sha256': hashlib.sha256((l.g.OUT / f'{protocol}_{seed}' / 'teacher.pt').read_bytes()).hexdigest()})
            allrows.append(frame)
            del teacher, bank, model
            print('Concat saved', protocol, seed, 'epochs', epochs, flush=True)
    pd.concat(allrows, ignore_index=True).to_csv(l.OUT / 'concat_predictions.csv', index=False)
    l.g.e.save_json(l.OUT / 'concat_run_complete.json', {'new_models': 9, 'runtime_seconds': time.time() - started, 'fingerprint': fingerprint})
if __name__ == '__main__':
    raise SystemExit('Use scripts/train_mainline.py for mainline fitting or the saved-result analysis scripts. This historical entry is retained for method provenance, not default execution.')
