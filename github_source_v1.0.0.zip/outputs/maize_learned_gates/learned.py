import sys as _sys
from pathlib import Path as _Path
_release_root = _Path(__file__).resolve().parents[2]
_sys.path.insert(0, str(_release_root))
from release_support import configured_path as _configured_path, prepare_transfer as _prepare_transfer
'Learned gate and capacity controls over the same verified frozen banks.'
import copy
import hashlib
import json
import sys
import time
from pathlib import Path
import numpy as np
import pandas as pd
import torch
from torch import nn
from torch.utils.data import TensorDataset, DataLoader
OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
sys.path.insert(0, str(ROOT / 'outputs/maize_fixed_gates'))
import gates as g
MODES = ['learned_global', 'learned_dynamic', 'uniform_capacity']

class Fusion(nn.Module):

    def __init__(self, template, mode):
        super().__init__()
        self.mode = mode
        if mode == 'uniform_capacity':
            self.head = nn.Sequential(nn.Linear(16, 185), nn.ReLU(), nn.Dropout(0.1), nn.Linear(185, 1))
            with torch.no_grad():
                self.head[0].weight[:32].copy_(template[0].weight)
                self.head[0].bias[:32].copy_(template[0].bias)
                self.head[3].weight.zero_()
                self.head[3].weight[:, :32].copy_(template[3].weight)
                self.head[3].bias.copy_(template[3].bias)
        else:
            self.head = copy.deepcopy(template)
        if mode == 'learned_global':
            self.logits = nn.Parameter(torch.zeros(5))
        elif mode == 'learned_dynamic':
            self.gate = nn.Sequential(nn.Linear(80, 32), nn.ReLU(), nn.Linear(32, 5))
            nn.init.zeros_(self.gate[2].weight)
            nn.init.zeros_(self.gate[2].bias)
        elif mode != 'uniform_capacity':
            raise ValueError(mode)
        for p in self.parameters():
            p.requires_grad_(True)

    def forward(self, bank, return_weights=False):
        if self.mode == 'learned_global':
            weights = torch.softmax(self.logits, dim=0)[None, :].expand(len(bank), -1)
        elif self.mode == 'learned_dynamic':
            weights = torch.softmax(self.gate(bank.flatten(1)), dim=1)
        else:
            weights = torch.full((len(bank), 5), 0.2, dtype=bank.dtype, device=bank.device)
        value = self.head((bank * weights[:, :, None]).sum(1)).squeeze(1)
        return (value, weights) if return_weights else value

def predict(model, bank, mean, std):
    model.eval()
    values = []
    weights = []
    with torch.no_grad():
        for chunk in np.array_split(bank, max(1, int(np.ceil(len(bank) / 512)))):
            y, w = model(torch.from_numpy(chunk).to(g.DEVICE), return_weights=True)
            values.append(y.cpu().numpy() * std + mean)
            weights.append(w.cpu().numpy())
    return (np.concatenate(values), np.concatenate(weights))

def train(template, mode, bank, residual, fit, val, seed, epochs=60):
    g.seed_all(seed + 992)
    model = Fusion(template, mode).to(g.DEVICE)
    g.seed_all(seed + 991)
    mean = float(residual[fit].mean())
    std = float(residual[fit].std())
    loader = DataLoader(TensorDataset(torch.from_numpy(bank[fit]), torch.from_numpy(((residual[fit] - mean) / std).astype(np.float32))), batch_size=512, shuffle=True, generator=torch.Generator().manual_seed(seed + 991), num_workers=0)
    optimizer = torch.optim.Adam(model.parameters(), lr=0.001, weight_decay=0.0001)
    best = float('inf')
    stale = 0
    state = None
    bestepoch = epochs
    history = []
    for epoch in range(1, epochs + 1):
        model.train()
        total = 0.0
        for xb, yb in loader:
            optimizer.zero_grad(set_to_none=True)
            loss = nn.functional.mse_loss(model(xb.to(g.DEVICE)), yb.to(g.DEVICE))
            loss.backward()
            optimizer.step()
            total += float(loss.detach().cpu()) * len(xb)
        row = {'epoch': epoch, 'train_mse': total / int(fit.sum())}
        if val is not None:
            p, _ = predict(model, bank[val], mean, std)
            score = g.e.metrics(residual[val], p)['rmse_t_ha']
            row['val_rmse'] = score
            if score < best - 1e-05:
                best = score
                stale = 0
                state = copy.deepcopy(model.state_dict())
                bestepoch = epoch
            else:
                stale += 1
        history.append(row)
        if val is not None and stale >= 8:
            break
    if state is not None:
        model.load_state_dict(state)
    return (model, mean, std, bestepoch, history)

def load_bank(folder, x, soil, lengths):
    params = json.loads((folder / 'preprocessing.json').read_text())
    valid = np.arange(x.shape[1])[None, :] < lengths[:, None]
    observed = np.isfinite(x) & valid[:, :, None]
    med = np.array(params['median'], dtype=np.float32)
    mean = np.array(params['mean'], dtype=np.float32)
    scale = np.array(params['scale'], dtype=np.float32)
    norm = (np.where(observed, x, med) - mean) / scale
    norm[~valid] = 0.0
    seq = np.concatenate([norm, observed.astype(np.float32), valid[:, :, None].astype(np.float32)], axis=2).astype(np.float32)
    static = ((soil - np.array(params['static_mean'], dtype=np.float32)) / np.array(params['static_scale'], dtype=np.float32)).astype(np.float32)
    ck = torch.load(folder / 'teacher.pt', map_location='cpu', weights_only=True)
    teacher = g.Teacher().to(g.DEVICE)
    teacher.load_state_dict(ck['state_dict'])
    teacher.eval()
    for p in teacher.parameters():
        p.requires_grad_(False)
    parts = []
    with torch.no_grad():
        for ids in np.array_split(np.arange(len(x)), max(1, int(np.ceil(len(x) / 512)))):
            parts.append(teacher.encode(torch.from_numpy(seq[ids]).to(g.DEVICE), torch.from_numpy(static[ids]).to(g.DEVICE), torch.from_numpy(lengths[ids])).cpu().numpy())
    return (teacher, np.concatenate(parts).astype(np.float32))

def run():
    start = time.time()
    d = np.load(g.e.CACHE / 'dataset.npz')
    x, soil, lengths, y, years, counties = [d[k] for k in ['x', 'static', 'lengths', 'y', 'years', 'counties']]
    sources = [Path(__file__), Path(g.__file__), g.e.CACHE / 'dataset.npz', g.OUT / 'background_choices.json']
    fingerprint = hashlib.sha256(''.join((hashlib.sha256(p.read_bytes()).hexdigest() for p in sources)).encode()).hexdigest()
    frames = []
    weights_frames = []
    for protocol in ['T', 'E_to_W', 'W_to_E']:
        split = g.e.make_split(years, counties, protocol)
        for seed in g.e.SEEDS:
            source = g.OUT / f'{protocol}_{seed}'
            out = OUT / f'{protocol}_{seed}'
            out.mkdir(exist_ok=True)
            if (out / 'complete.json').exists():
                old = json.loads((out / 'complete.json').read_text())
                if old['fingerprint'] != fingerprint:
                    raise ValueError('Existing learned case fingerprint changed')
                frames.append(pd.read_csv(out / 'predictions.csv'))
                weights_frames.append(pd.read_csv(out / 'weights.csv'))
                continue
            teacher, bank = load_bank(source, x, soil, lengths)
            backgrounds = json.loads((source / 'background.json').read_text())
            bg = {k: g.e.background_predict(backgrounds[k], years, counties) for k in ['selection', 'final_fit']}
            residual = {k: (y - v).astype(np.float32) for k, v in bg.items()}
            rows = []
            wrows = []
            selections = []
            histories = []
            for mode in MODES:
                model, ym, ys, epochs, h = train(teacher.head, mode, bank, residual['selection'], split['train'], split['val'], seed)
                p, _ = predict(model, bank[split['val']], ym, ys)
                selections.append({'mode': mode, 'best_epoch': epochs, **g.e.metrics(y[split['val']], p + bg['selection'][split['val']])})
                for row in h:
                    row.update({'mode': mode, 'phase': 'selection'})
                histories.extend(h)
                del model
                model, ym, ys, _, h = train(teacher.head, mode, bank, residual['final_fit'], split['fit'], None, seed, epochs=epochs)
                for row in h:
                    row.update({'mode': mode, 'phase': 'final_fit'})
                histories.extend(h)
                for scenario, mask in split.items():
                    if scenario not in ['time', 'space', 'joint']:
                        continue
                    p, w = predict(model, bank[mask], ym, ys)
                    rows.append(pd.DataFrame({'protocol': protocol, 'scenario': scenario, 'variant': mode, 'seed': seed, 'adm_id': counties[mask], 'year': years[mask], 'observed_yield_t_ha': y[mask], 'predicted_yield_t_ha': p + bg['final_fit'][mask]}))
                    wrows.append(pd.DataFrame({'protocol': protocol, 'scenario': scenario, 'variant': mode, 'seed': seed, 'adm_id': counties[mask], 'year': years[mask], **{name: w[:, j] for j, name in enumerate(g.GROUP_NAMES)}}))
                torch.save({'state_dict': model.cpu().state_dict(), 'mode': mode, 'target_mean': ym, 'target_std': ys, 'epochs': epochs, 'seed': seed, 'parameters': sum((p.numel() for p in model.parameters()))}, out / f'{mode}.pt')
                del model
                print('Learned/capacity saved', protocol, seed, mode, 'epochs', epochs, flush=True)
            frame = pd.concat(rows, ignore_index=True)
            wf = pd.concat(wrows, ignore_index=True)
            frame.to_csv(out / 'predictions.csv', index=False)
            wf.to_csv(out / 'weights.csv', index=False)
            g.e.save_json(out / 'selection.json', selections)
            pd.DataFrame(histories).to_csv(out / 'history.csv', index=False)
            g.e.save_json(out / 'complete.json', {'fingerprint': fingerprint, 'source_teacher_sha256': hashlib.sha256((source / 'teacher.pt').read_bytes()).hexdigest(), 'encoder_frozen': True})
            frames.append(frame)
            weights_frames.append(wf)
            del teacher, bank
    pred = pd.concat(frames, ignore_index=True)
    pred.to_csv(OUT / 'new_predictions.csv', index=False)
    pd.concat(weights_frames, ignore_index=True).to_csv(OUT / 'learned_weights.csv', index=False)
    fixed = pd.read_csv(g.OUT / 'all_predictions.csv').drop(columns=['background_kind'])
    allpred = pd.concat([fixed, pred], ignore_index=True)
    allpred.to_csv(OUT / 'all_predictions.csv', index=False)
    rows = []
    for key, group in allpred.groupby(['protocol', 'scenario', 'variant', 'seed']):
        rows.append({**dict(zip(['protocol', 'scenario', 'variant', 'seed'], key)), **g.e.metrics(group.observed_yield_t_ha.to_numpy(), group.predicted_yield_t_ha.to_numpy())})
    metrics = pd.DataFrame(rows)
    metrics.to_csv(OUT / 'metrics.csv', index=False)
    summary = metrics.groupby(['protocol', 'scenario', 'variant']).agg(n=('n', 'first'), rmse_mean=('rmse_t_ha', 'mean'), rmse_seed_sd=('rmse_t_ha', 'std'), r2_mean=('r2', 'mean'), mae_mean=('mae_t_ha', 'mean'), bias_mean=('bias_t_ha', 'mean')).reset_index()
    summary.to_csv(OUT / 'summary.csv', index=False)
    g.e.save_json(OUT / 'run_complete.json', {'fingerprint': fingerprint, 'runtime_seconds': time.time() - start, 'new_models': 27, 'encoder_reused': True, 'source_only_learning': True})
    print(summary.to_string(index=False), flush=True)
if __name__ == '__main__':
    raise SystemExit('Use scripts/train_mainline.py for mainline fitting or the saved-result analysis scripts. This historical entry is retained for method provenance, not default execution.')
