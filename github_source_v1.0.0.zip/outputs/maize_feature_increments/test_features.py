import unittest
import numpy as np
import pandas as pd
from prepare import weather_bins
class FeatureTests(unittest.TestCase):

    def test_weather_cumulative_and_boundaries(self):
        days = pd.date_range('2020-05-01', periods=12)
        f = pd.DataFrame({'observed_date': days, 'tmin': [0.0] * 12, 'tmax': [40.0] * 12, 'prec': [0.0] * 10 + [3.0, 0.0]})
        x = weather_bins(f, pd.Timestamp('2020-04-21'), pd.Timestamp('2020-05-01'), pd.Timestamp('2020-05-12'), 3)
        np.testing.assert_allclose(x[0], [0, 0, 0])
        np.testing.assert_allclose(x[1], [100, 100, 10])
        np.testing.assert_allclose(x[2], [120, 120, 10])
        future = f.copy()
        future.loc[11, ['tmax', 'prec']] = [100.0, 0.0]
        early = weather_bins(future, pd.Timestamp('2020-04-21'), pd.Timestamp('2020-05-01'), pd.Timestamp('2020-05-10'), 2)
        np.testing.assert_allclose(early, x[:2])

    def test_missing_day_rejected(self):
        f = pd.DataFrame({'observed_date': pd.to_datetime(['2020-05-01', '2020-05-03']), 'tmin': [10.0, 10.0], 'tmax': [20.0, 20.0], 'prec': [0.0, 0.0]})
        with self.assertRaises(ValueError):
            weather_bins(f, pd.Timestamp('2020-05-01'), pd.Timestamp('2020-05-01'), pd.Timestamp('2020-05-03'), 1)

    def test_distinct_weather_channels(self):
        f = pd.DataFrame({'observed_date': pd.date_range('2020-05-01', periods=2), 'tmin': [5.0, 20.0], 'tmax': [25.0, 35.0], 'prec': [0.0, 2.0]})
        got = weather_bins(f, pd.Timestamp('2020-05-01'), pd.Timestamp('2020-05-01'), pd.Timestamp('2020-05-02'), 1)
        np.testing.assert_allclose(got[0], [22.5, 5.0, 1.0])
