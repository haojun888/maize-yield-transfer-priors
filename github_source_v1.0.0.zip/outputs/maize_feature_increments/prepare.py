"""Daily weather aggregation shared by the mainline. Legacy FPAR routines are excluded."""
import numpy as np
import pandas as pd
def weather_bins(frame, start, sos, cutoff, length):
    frame = frame[(frame.observed_date >= sos) & (frame.observed_date <= cutoff)].sort_values('observed_date')
    expected = pd.date_range(sos, cutoff)
    if not np.array_equal(frame.observed_date.to_numpy(), expected.to_numpy()):
        raise ValueError('Missing/duplicate growing-season weather day')
    values = frame[['tmin', 'tmax', 'prec']].to_numpy(dtype=float)
    if not np.isfinite(values).all():
        raise ValueError('Missing weather cannot be treated as dry')
    low, high, rain = values.T
    if (low > high).any() or (rain < 0).any() or np.max(np.abs(values[:, :2])) > 80:
        raise ValueError('Unexpected weather units/range')
    gdd = np.cumsum(np.maximum((np.clip(low, 10, 30) + np.clip(high, 10, 30)) / 2 - 10, 0))
    heat = np.cumsum(np.maximum(high - 30, 0))
    dry = []
    run = 0
    longest = 0
    for value in rain:
        run = run + 1 if value < 1 else 0
        longest = max(longest, run)
        dry.append(longest)
    result = np.zeros((length, 3), dtype=np.float32)
    daily = np.stack([gdd, heat, dry], axis=1)
    for b in range(length):
        end = min(start + pd.Timedelta(days=10 * b + 9), cutoff)
        if end >= sos:
            result[b] = daily[(end - sos).days]
    return result
