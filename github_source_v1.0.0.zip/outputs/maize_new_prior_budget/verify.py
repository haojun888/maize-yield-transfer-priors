import sys as _sys
from pathlib import Path as _Path
_release_root = _Path(__file__).resolve().parents[2]
_sys.path.insert(0, str(_release_root))
from release_support import configured_path as _configured_path, prepare_transfer as _prepare_transfer
'Independent alignment/invariants and descriptive same-state-year optical coverage audit.'
import sys
sys.dont_write_bytecode = True
import numpy as np
import pandas as pd
import torch
import budget as b
OUT, ROOT = (b.OUT, b.ROOT)

def run():
    b.lock()
    v = b.read(OUT / 'training_verification.json')
    ev = b.read(OUT / 'evaluation_verification.json')
    assert v['new_selection_models'] == v['new_final_models'] == 24 and ev['model_cohort_cases'] == 120
    prior = pd.read_csv(OUT / 'priors.csv')
    assert len(prior) == 24
    for seed in b.SEEDS:
        for r in b.REFERENCES:
            p = np.array(b.read(b.x.OUT / str(seed) / 'priors.json')['weights'][r])
            for variant, q in b.controls(p).items():
                b.validate(p, q, variant)
                ck = torch.load(OUT / str(seed) / f'final_{r}__{variant}.pt', map_location='cpu', weights_only=True)
                np.testing.assert_array_equal(ck['prior'], q)
                assert sum((v.numel() for k, v in ck['state_dict'].items() if k != 'prior')) == 577
                if variant == 'block_equal':
                    assert (q * q).sum() < (p * p).sum()
    raw = np.load(b.s.CACHE / 'gdd_evi.npz')
    split = np.load(b.t.OUT / 'split_E_to_W.npz')
    coverage = []
    sensitivity = []
    checks = []
    for label in ['W_space', 'W_joint', 'KYTN', 'TXGA']:
        z = np.load(OUT / f'predictions_{label}.npz')
        old = np.load(b.x.OUT / f'predictions_{label}.npz')
        for key in ['y', 'years', 'counties', 'states', 'background', 'weather_only', 'weather_calendar']:
            np.testing.assert_array_equal(z[key], old[key])
        assert z['methods'].tolist() == b.METHODS and z['seeds'].tolist() == b.SEEDS
        for si, seed in enumerate(b.SEEDS):
            for mi, r in enumerate(b.REFERENCES):
                np.testing.assert_array_equal(z['predictions'][si, mi], old['predictions'][old['seeds'].tolist().index(seed), old['methods'].tolist().index(r)])
        assert np.isfinite(z['predictions']).all()
        if label.startswith('W_'):
            mask = split[label[2:]]
            data = {k: raw[k][mask] for k in ['x', 'lengths', 'years', 'counties']}
        else:
            data = np.load(ROOT / 'work' / ('maize_external_region' if label == 'KYTN' else 'maize_high_weather_transfer') / 'dataset.npz')
        np.testing.assert_array_equal(data['counties'], z['counties'])
        np.testing.assert_array_equal(data['years'], z['years'])
        valid = np.arange(data['x'].shape[1])[None, :] < data['lengths'][:, None]
        ndvi = np.isfinite(data['x'][:, :, 6]) & valid
        evi = np.isfinite(data['x'][:, :, 9]) & valid
        ndvi_rate = ndvi.sum(1) / data['lengths']
        evi_rate = evi.sum(1) / data['lengths']
        bg = b.read(OUT / 'distance_rules.json')['weather_only']
        high = z['weather_only'] >= bg['high_min']
        for state in ['pooled'] + sorted(set(z['states'])):
            sm = np.ones(len(z['y']), bool) if state == 'pooled' else z['states'] == state
            for group, mask in [('overall', sm), ('high', sm & high)]:
                if not mask.any():
                    continue
                coverage.append({'cohort': label, 'state_fips': state, 'distance_bin': group, 'n': int(mask.sum()), 'ndvi_valid_fraction_mean': ndvi_rate[mask].mean(), 'evi_valid_fraction_mean': evi_rate[mask].mean(), 'evi_valid_fraction_median': np.median(evi_rate[mask]), 'evi_zero_fraction': (evi_rate[mask] == 0).mean(), 'scope': 'finite raw optical observations within valid sequence; not crop-weight coverage'})
                if state == 'pooled':
                    continue
                for year in sorted(set(z['years'][mask])):
                    ym = mask & (z['years'] == year)
                    squared = (z['predictions'][:, :, ym].astype(float) - z['y'][ym]) ** 2
                    for method in b.NEW:
                        mi = b.METHODS.index(method)
                        ref = method.split('__')[0]
                        ri = b.METHODS.index(ref)
                        sensitivity.append({'cohort': label, 'state_fips': state, 'year': int(year), 'distance_bin': group, 'method': method, 'reference': ref, 'n': int(ym.sum()), 'ndvi_valid_fraction_mean': ndvi_rate[ym].mean(), 'evi_valid_fraction_mean': evi_rate[ym].mean(), 'mse_method_minus_reference': (squared[:, mi] - squared[:, ri]).mean(), 'scope': 'descriptive same-state-year paired errors; no causal inference'})
        checks.append({'cohort': label, 'rows': len(z['y']), 'cases': 30, 'references_bitwise_reused': True, 'rows_and_distances_exact': True})
    metrics = pd.read_csv(OUT / 'metrics.csv')
    pairs = pd.read_csv(OUT / 'paired_county_intervals.csv')
    assert set(metrics.method) == set(b.METHODS) and set(pairs.method) == set(b.NEW)
    assert set(metrics.seed) == set(b.SEEDS) and set(pairs.seed.astype(str)) == {'seed_mean', '42', '2026', '3407'}
    assert (pairs.draws == 2000).all()
    pd.DataFrame(coverage).to_csv(OUT / 'optical_observation_coverage.csv', index=False)
    pd.DataFrame(sensitivity).to_csv(OUT / 'state_year_paired_sensitivity.csv', index=False)
    for record in [b.read(OUT / 'source_manifest.json'), b.read(OUT / 'evaluation_manifest.json')]:
        for p, digest in record['sha256'].items():
            assert b.sha(p) == digest, p
    for p, digest in v['artifacts_sha256'].items():
        assert b.sha(p) == digest, p
    for p, digest in ev['output_sha256'].items():
        assert b.sha(p) == digest, p
    b.save(OUT / 'release_verification.json', {'verified': True, 'checks': checks, 'source_and_evaluation_hashes_unchanged': True, 'selection_and_final_heads': 48, 'all_parameters': 577, 'all_variants_and_seeds_reported': True, 'reference_predictions_recomputed': False, 'optical_coverage_scope': 'finite raw dynamic values in valid length, NDVI column6/EVI column9', 'auxiliary_sha256': {str(OUT / name): b.sha(OUT / name) for name in ['optical_observation_coverage.csv', 'state_year_paired_sensitivity.csv']}})
    print('INDEPENDENT_RELEASE_VERIFIED', checks, flush=True)
if __name__ == '__main__':
    raise SystemExit('Use scripts/train_mainline.py for mainline fitting or the saved-result analysis scripts. This historical entry is retained for method provenance, not default execution.')
