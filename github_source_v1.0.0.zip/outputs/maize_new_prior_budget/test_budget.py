import sys as _sys
from pathlib import Path as _Path
_release_root = _Path(__file__).resolve().parents[2]
_sys.path.insert(0, str(_release_root))
from release_support import configured_path as _configured_path, prepare_transfer as _prepare_transfer
import unittest
import numpy as np
from budget import controls, validate

class Tests(unittest.TestCase):

    def test_all_locked_priors(self):
        from budget import x, SEEDS, REFERENCES
        for seed in SEEDS:
            for ref in REFERENCES:
                p = np.array(x.read(x.OUT / str(seed) / 'priors.json')['weights'][ref])
                q = controls(p)
                self.assertEqual(len(q), 4)
                for name, v in q.items():
                    validate(p, v, name)
                np.testing.assert_array_equal(q['optical_swap'][[3, 5]], p[[5, 3]])
                np.testing.assert_array_equal(q['weather_reverse'][[0, 1, 2, 4]], p[[4, 2, 1, 0]])

    def test_wrong_index_fails(self):
        p = np.arange(1, 8, dtype=float) / 28
        q = p.copy()
        q[[3, 6]] = q[[6, 3]]
        with self.assertRaises(AssertionError):
            validate(p, q, 'optical_swap')
        with self.assertRaises(AssertionError):
            controls(np.ones(6))
if __name__ == '__main__':
    raise SystemExit('Use scripts/train_mainline.py for mainline fitting or the saved-result analysis scripts. This historical entry is retained for method provenance, not default execution.')
