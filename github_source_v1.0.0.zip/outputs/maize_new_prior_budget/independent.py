import sys as _sys
from pathlib import Path as _Path
_release_root = _Path(__file__).resolve().parents[2]
_sys.path.insert(0, str(_release_root))
from release_support import configured_path as _configured_path, prepare_transfer as _prepare_transfer
'Append independently prepared 342-row states45/40/28 after source heads frozen.'
import sys, time
sys.dont_write_bytecode = True
import numpy as np
import pandas as pd
import torch
import budget as b
MODEL_OUT = b.OUT
OUT = MODEL_OUT / 'independent_confirmation'
COHORT = 'Independent342'

def run():
    start = time.time()
    b.lock()
    frozen = b.read(MODEL_OUT / 'training_verification.json')
    assert frozen['verified']
    for path, digest in frozen['artifacts_sha256'].items():
        assert b.sha(path) == digest, path
    source = b.ROOT / 'outputs/maize_independent_confirmation/model_predictions.npz'
    bank_dir = b.ROOT / 'work/maize_independent_confirmation'
    deps = [source] + [bank_dir / f'bank_E_{seed}.npy' for seed in b.SEEDS]
    assert all((p.exists() for p in deps)), 'Independent confirmation artifacts not ready'
    OUT.mkdir(exist_ok=True)
    record = {'training_sha256': b.sha(MODEL_OUT / 'training_verification.json'), 'sha256': {str(p): b.sha(p) for p in deps}, 'source_final_heads': frozen['model_sha256'], 'methods': b.METHODS, 'reference_predictions_reused': True, 'source_freeze_precedes_independent_read': True}
    manifest = OUT / 'evaluation_manifest.json'
    if manifest.exists():
        assert b.read(manifest) == record
    else:
        b.save(manifest, record)
    z = np.load(source)
    assert len(z['y']) == 342 and len(set(z['counties'])) == 120 and (set(z['states']) == {'45', '40', '28'})
    rules = b.read(MODEL_OUT / 'distance_rules.json')
    assert (z['weather_only'] >= rules['weather_only']['high_min']).sum() == 241
    predictions = np.empty((3, len(b.METHODS), 342), np.float32)
    cases = []
    for si, seed in enumerate(b.SEEDS):
        for mi, ref in enumerate(b.REFERENCES):
            predictions[si, mi] = z['predictions'][z['seeds'].tolist().index(seed), z['methods'].tolist().index(ref)]
            cases.append({'cohort': COHORT, 'seed': seed, 'method': ref, 'reused_prediction': True})
        _, _, teacher, _, _, _ = b.x.source_context(seed)
        bank = np.load(bank_dir / f'bank_E_{seed}.npy')
        assert bank.shape == (342, 7, 16) and np.isfinite(bank).all()
        for method in b.NEW:
            path = MODEL_OUT / str(seed) / f'final_{method}.pt'
            ck = torch.load(path, map_location='cpu', weights_only=True)
            model = b.s.Fusion(teacher.head, 'fixed', np.array(ck['prior'])).to(b.s.DEVICE)
            model.load_state_dict(ck['state_dict'])
            value, w = b.s.predict(model, bank, ck['target_mean'], ck['target_std'])
            repeat, rw = b.s.predict(model, bank, ck['target_mean'], ck['target_std'])
            np.testing.assert_array_equal(value, repeat)
            np.testing.assert_allclose(w, np.broadcast_to(ck['prior'], w.shape), atol=1e-07, rtol=1e-06)
            predictions[si, b.METHODS.index(method)] = value + z['background']
            cases.append({'cohort': COHORT, 'seed': seed, 'method': method, 'reused_prediction': False, 'parameters': 577, 'checkpoint': str(path)})
        print('INDEPENDENT_PREDICTED', seed, flush=True)
    np.savez_compressed(OUT / f'predictions_{COHORT}.npz', predictions=predictions, methods=np.array(b.METHODS), seeds=np.array(b.SEEDS), **{k: z[k] for k in ['y', 'years', 'counties', 'states', 'background', 'weather_only', 'weather_calendar']}, evaluation_manifest_sha256=np.array(b.sha(manifest)))
    pd.DataFrame(cases).to_csv(OUT / 'evaluated_models.csv', index=False)
    b.OUT = OUT
    b.summarize([COHORT], rules)
    b.OUT = MODEL_OUT
    for p, digest in record['sha256'].items():
        assert b.sha(p) == digest, p
    for p, digest in frozen['model_sha256'].items():
        assert b.sha(p) == digest, p
    b.save(OUT / 'evaluation_verification.json', {'verified': True, 'n': 342, 'counties': 120, 'weather_high_n': 241, 'model_cases': 30, 'inferred_cases': 24, 'reused_cases': 6, 'new_target_fitting': 0, 'source_heads_unchanged': True, 'output_sha256': {str(p): b.sha(p) for p in OUT.iterdir() if p.suffix in ['.csv', '.npz']}, 'runtime_seconds': time.time() - start})
if __name__ == '__main__':
    raise SystemExit('Use scripts/train_mainline.py for mainline fitting or the saved-result analysis scripts. This historical entry is retained for method provenance, not default execution.')
