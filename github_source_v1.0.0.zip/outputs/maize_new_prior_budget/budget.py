import sys as _sys
from pathlib import Path as _Path
_release_root = _Path(__file__).resolve().parents[2]
_sys.path.insert(0, str(_release_root))
from release_support import configured_path as _configured_path, prepare_transfer as _prepare_transfer
'Budget-preserving tests of two frozen source priors; old artifacts read-only.'
import os, sys, json, hashlib, time
from pathlib import Path
os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
sys.dont_write_bytecode = True
import numpy as np
import pandas as pd
import torch
OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
sys.path.insert(0, str(ROOT / 'outputs/maize_fixed_prior_extension'))
import extension as x
s, t = (x.s, x.t)
sha, read, save = (x.sha, x.read, x.save)
SEEDS = x.SEEDS
REFERENCES = ['source_permutation_fixed', 'sobol_square']
VARIANTS = ['optical_swap', 'weather_reverse', 'both', 'block_equal']
NEW = [r + '__' + v for r in REFERENCES for v in VARIANTS]
METHODS = REFERENCES + NEW
BLOCKS = [[3, 5], [0, 1, 2, 4], [6]]

def controls(prior):
    p = np.array(prior, dtype=np.float64)
    assert p.shape == (7,) and np.isfinite(p).all() and (p >= 0).all()
    assert abs(p.sum() - 1) < 1e-12
    a = p.copy()
    a[[3, 5]] = p[[5, 3]]
    b = p.copy()
    b[[0, 1, 2, 4]] = p[[4, 2, 1, 0]]
    c = b.copy()
    c[[3, 5]] = p[[5, 3]]
    d = p.copy()
    for block in BLOCKS:
        d[block] = p[block].mean()
    result = dict(zip(VARIANTS, [a, b, c, d]))
    for name, q in result.items():
        validate(p, q, name)
    return result

def validate(p, q, variant):
    assert variant in VARIANTS and q.shape == (7,) and np.isfinite(q).all()
    for block in BLOCKS:
        np.testing.assert_allclose(q[block].sum(), p[block].sum(), atol=1e-15, rtol=0)
        if variant != 'block_equal':
            np.testing.assert_array_equal(np.sort(q[block]), np.sort(p[block]))
        else:
            np.testing.assert_allclose(q[block], np.full(len(block), p[block].mean()), rtol=0, atol=0)
    if variant != 'block_equal':
        np.testing.assert_array_equal(np.sort(q), np.sort(p))
        np.testing.assert_allclose((q * q).sum(), (p * p).sum(), atol=1e-15, rtol=0)
    np.testing.assert_array_equal(q[6], p[6])
    expected = p.copy()
    if variant in ['optical_swap', 'both']:
        expected[[3, 5]] = p[[5, 3]]
    if variant in ['weather_reverse', 'both']:
        expected[[0, 1, 2, 4]] = p[[4, 2, 1, 0]]
    if variant != 'block_equal':
        np.testing.assert_array_equal(q, expected)

def lock():
    path = OUT / 'source_manifest.json'
    if path.exists():
        record = read(path)
        for p, digest in record['sha256'].items():
            assert sha(p) == digest, p
        return record
    deps = [Path(__file__), OUT / 'test_budget.py', OUT / 'protocol.md', x.OUT / 'training_verification.json', x.OUT / 'source_manifest.json']
    original = read(x.OUT / 'source_manifest.json')
    for p, digest in original['sha256'].items():
        assert sha(p) == digest, p
    deps += [Path(p) for p in original['sha256']]
    for seed in SEEDS:
        deps += [x.OUT / str(seed) / 'priors.json'] + [x.OUT / str(seed) / f'final_{r}.pt' for r in REFERENCES]
    hashes = {str(p): sha(p) for p in deps}
    fp = hashlib.sha256(json.dumps(hashes, sort_keys=True).encode()).hexdigest()
    record = {'fingerprint': fp, 'sha256': hashes, 'references': REFERENCES, 'variants': VARIANTS, 'seeds': SEEDS, 'selection_models': 24, 'final_models': 24, 'new_teachers': 0, 'all_variants_retained': True, 'complete_mapping_family': False, 'target_outcomes_previously_known': True, 'target_selection': False}
    save(path, record)
    return record

def train():
    start = time.time()
    fp = lock()['fingerprint']
    rows = []
    prior_rows = []
    for seed in SEEDS:
        folder = OUT / str(seed)
        folder.mkdir(exist_ok=True)
        priors = {}
        for r in REFERENCES:
            p = np.array(read(x.OUT / str(seed) / 'priors.json')['weights'][r])
            for variant, q in controls(p).items():
                priors[r + '__' + variant] = q
                prior_rows.append({'seed': seed, 'reference': r, 'variant': variant, 'method': r + '__' + variant, **dict(zip(s.NAMES, q)), 'optical_total': q[[3, 5]].sum(), 'weather_total': q[[0, 1, 2, 4]].sum(), 'soil_total': q[6], 'concentration': (q * q).sum(), 'reference_concentration': (p * p).sum(), 'value_set_preserved': variant != 'block_equal', 'complete_mapping_family': False})
        save(folder / 'priors.json', {'fingerprint': fp, 'weights': {k: v.tolist() for k, v in priors.items()}})
        d, split, teacher, bank, residual, _ = x.source_context(seed)
        assert set(d['years'][split['train']]) == set(range(2004, 2017))
        assert set(d['years'][split['val']]) == {2017, 2018, 2019}
        assert set(d['years'][split['fit']]) == set(range(2004, 2020))
        for method, prior in priors.items():
            path = folder / f'selection_{method}.pt'
            meta = folder / f'selection_{method}.json'
            if not path.exists():
                model, mean, std, epoch, history, score = s.train(teacher.head, 'fixed', prior, 0.0, bank, residual['selection'], split['train'], split['val'], seed)
                assert sum((p.numel() for p in model.parameters())) == 577
                torch.save({'state_dict': model.cpu().state_dict(), 'prior': prior.tolist(), 'epoch': epoch, 'target_mean': mean, 'target_std': std, 'fingerprint': fp, 'parameters': 577, 'mode': 'fixed'}, path)
                save(meta, {'method': method, 'seed': seed, 'epoch': epoch, 'val_rmse': score, 'fingerprint': fp})
                pd.DataFrame(history).to_csv(folder / f'selection_{method}_history.csv', index=False)
            ck = torch.load(path, map_location='cpu', weights_only=True)
            assert ck['fingerprint'] == fp
            np.testing.assert_array_equal(ck['prior'], prior)
            rows.append(read(meta))
            print('SELECTION', seed, method, rows[-1]['epoch'], rows[-1]['val_rmse'], flush=True)
    assert len(rows) == 24
    pd.DataFrame(rows).to_csv(OUT / 'validation_candidates.csv', index=False)
    pd.DataFrame(prior_rows).to_csv(OUT / 'priors.csv', index=False)
    save(OUT / 'selection_complete.json', {'fingerprint': fp, 'models': 24, 'target_predictions_started': False})
    model_hashes = {}
    for seed in SEEDS:
        d, split, teacher, bank, residual, _ = x.source_context(seed)
        folder = OUT / str(seed)
        for method, values in read(folder / 'priors.json')['weights'].items():
            prior = np.array(values)
            meta = read(folder / f'selection_{method}.json')
            path = folder / f'final_{method}.pt'
            if not path.exists():
                model, mean, std = t.fit_final(teacher.head, 'fixed', prior, 0.0, bank, residual['final_fit'], split['fit'], seed, meta['epoch'])
                assert sum((p.numel() for p in model.parameters())) == 577
                torch.save({'state_dict': model.cpu().state_dict(), 'prior': values, 'epoch': meta['epoch'], 'target_mean': mean, 'target_std': std, 'fingerprint': fp, 'parameters': 577, 'mode': 'fixed'}, path)
            ck = torch.load(path, map_location='cpu', weights_only=True)
            assert ck['fingerprint'] == fp and ck['epoch'] == meta['epoch']
            np.testing.assert_array_equal(ck['prior'], prior)
            model_hashes[str(path)] = sha(path)
            print('FINAL', seed, method, meta['epoch'], flush=True)
    lock()
    artifacts = [p for seed in SEEDS for p in (OUT / str(seed)).iterdir() if p.suffix in ['.json', '.pt', '.csv']]
    save(OUT / 'training_verification.json', {'verified': True, 'fingerprint': fp, 'new_selection_models': 24, 'new_final_models': 24, 'new_teachers': 0, 'reference_retraining': False, 'source_manifest_sha256': sha(OUT / 'source_manifest.json'), 'model_sha256': model_hashes, 'artifacts_sha256': {str(p): sha(p) for p in artifacts}, 'all_final_models_locked_before_target_prediction': True, 'runtime_seconds': time.time() - start})
    print('SOURCE_FROZEN', flush=True)

def evaluate():
    start = time.time()
    lock()
    training = read(OUT / 'training_verification.json')
    assert training['verified']
    for p, digest in training['artifacts_sha256'].items():
        assert sha(p) == digest, p
    rules = read(x.OUT / 'distance_rules.json')
    cohorts = ['W_space', 'W_joint', 'KYTN', 'TXGA']
    deps = {}
    for cohort in cohorts:
        deps[str(x.OUT / f'predictions_{cohort}.npz')] = sha(x.OUT / f'predictions_{cohort}.npz')
    for seed in SEEDS:
        deps[str(t.OUT / f'gdd_evi__E_to_W_{seed}/bank.npy')] = sha(t.OUT / f'gdd_evi__E_to_W_{seed}/bank.npy')
        for name in ['maize_external_region', 'maize_high_weather_transfer']:
            p = ROOT / 'work' / name / f'bank_E_{seed}.npy'
            deps[str(p)] = sha(p)
    deps[str(x.OUT / 'distance_rules.json')] = sha(x.OUT / 'distance_rules.json')
    manifest = {'training_sha256': sha(OUT / 'training_verification.json'), 'sha256': deps, 'methods': METHODS, 'seeds': SEEDS, 'cohorts': cohorts, 'reference_predictions_reused': True, 'new_target_fitting': 0}
    if (OUT / 'evaluation_manifest.json').exists():
        assert read(OUT / 'evaluation_manifest.json') == manifest
    else:
        save(OUT / 'evaluation_manifest.json', manifest)
    cases = []
    for cohort in cohorts:
        old = np.load(x.OUT / f'predictions_{cohort}.npz')
        file = OUT / f'predictions_{cohort}.npz'
        if file.exists():
            continue
        preds = np.empty((3, len(METHODS), len(old['y'])), np.float32)
        for si, seed in enumerate(SEEDS):
            for mi, reference in enumerate(REFERENCES):
                preds[si, mi] = old['predictions'][old['seeds'].tolist().index(seed), old['methods'].tolist().index(reference)]
                cases.append({'cohort': cohort, 'seed': seed, 'method': reference, 'reused_prediction': True})
            d, split, teacher, bank, _, _ = x.source_context(seed)
            if cohort.startswith('W_'):
                bank = bank[split[cohort[2:]]]
            else:
                bank = np.load(ROOT / 'work' / ('maize_external_region' if cohort == 'KYTN' else 'maize_high_weather_transfer') / f'bank_E_{seed}.npy')
            assert bank.shape == (len(old['y']), 7, 16) and np.isfinite(bank).all()
            for method in NEW:
                path = OUT / str(seed) / f'final_{method}.pt'
                ck = torch.load(path, map_location='cpu', weights_only=True)
                model = s.Fusion(teacher.head, 'fixed', np.array(ck['prior'])).to(s.DEVICE)
                model.load_state_dict(ck['state_dict'])
                value, w = s.predict(model, bank, ck['target_mean'], ck['target_std'])
                preds[si, METHODS.index(method)] = value + old['background']
                repeat, rw = s.predict(model, bank, ck['target_mean'], ck['target_std'])
                np.testing.assert_array_equal(value, repeat)
                np.testing.assert_allclose(w, np.broadcast_to(ck['prior'], w.shape), atol=1e-07, rtol=1e-06)
                cases.append({'cohort': cohort, 'seed': seed, 'method': method, 'reused_prediction': False, 'checkpoint': str(path), 'parameters': 577})
            print('PREDICTED', cohort, seed, len(old['y']), flush=True)
        np.savez_compressed(file, predictions=preds, methods=np.array(METHODS), seeds=np.array(SEEDS), **{k: old[k] for k in ['y', 'years', 'counties', 'states', 'background', 'weather_only', 'weather_calendar']}, evaluation_manifest_sha256=np.array(sha(OUT / 'evaluation_manifest.json')))
    if cases:
        pd.DataFrame(cases).to_csv(OUT / 'evaluated_models.csv', index=False)
    summarize(cohorts, rules)
    for p, digest in deps.items():
        assert sha(p) == digest, p
    lock()
    save(OUT / 'evaluation_verification.json', {'verified': True, 'model_cohort_cases': 120, 'inferred_cases': 96, 'reused_cases': 24, 'new_target_fitting': 0, 'reference_inference_rerun': False, 'dependencies_unchanged': True, 'output_sha256': {str(p): sha(p) for p in OUT.iterdir() if p.suffix in ['.npz', '.csv']}, 'runtime_seconds': time.time() - start})

def summarize(cohorts, rules):
    metrics = []
    paired = []
    for cohort in cohorts:
        z = np.load(OUT / f'predictions_{cohort}.npz')
        y = z['y'].astype(float)
        pred = z['predictions'].astype(float)
        assert np.isfinite(pred).all()
        err = (pred - y) ** 2
        for definition, rule in rules.items():
            distance = z[definition]
            bins = np.where(distance <= rule['low_max'], 0, np.where(distance >= rule['high_min'], 2, 1))
            for state in ['pooled'] + sorted(set(z['states'])):
                sm = np.ones(len(y), bool) if state == 'pooled' else z['states'] == state
                for group, mask in [('overall', sm), ('high', sm & (bins == 2)), ('low', sm & (bins == 0)), ('middle', sm & (bins == 1))]:
                    if not mask.any():
                        continue
                    squared = err[:, :, mask]
                    for si, seed in enumerate(SEEDS):
                        for mi, method in enumerate(METHODS):
                            reference = method.split('__')[0]
                            ri = METHODS.index(reference)
                            metrics.append({'cohort': cohort, 'definition': definition, 'state_fips': state, 'distance_bin': group, 'seed': seed, 'method': method, 'reference': reference, **s.e.metrics(y[mask], pred[si, mi, mask]), 'mse': squared[si, mi].mean(), 'mse_minus_reference': (squared[si, mi] - squared[si, ri]).mean(), 'background_skill': 1 - squared[si, mi].mean() / np.mean((z['background'][mask] - y[mask]) ** 2)})
                    if group not in ['overall', 'high']:
                        continue
                    unique, inverse = np.unique(z['counties'][mask], return_inverse=True)
                    counts = np.bincount(inverse)
                    draws = np.random.default_rng(20261012).integers(0, len(unique), (2000, len(unique)))
                    den = counts[draws].sum(1)
                    for method in NEW:
                        mi = METHODS.index(method)
                        reference = method.split('__')[0]
                        ri = METHODS.index(reference)
                        for seed_label, delta in [('seed_mean', (squared[:, mi] - squared[:, ri]).mean(0))] + [(str(seed), squared[si, mi] - squared[si, ri]) for si, seed in enumerate(SEEDS)]:
                            sums = np.bincount(inverse, weights=delta)
                            boots = sums[draws].sum(1) / den
                            ci = np.quantile(boots, [0.025, 0.975])
                            paired.append({'cohort': cohort, 'definition': definition, 'state_fips': state, 'distance_bin': group, 'method': method, 'reference': reference, 'seed': seed_label, 'n': int(mask.sum()), 'counties': len(unique), 'mse_method_minus_reference': delta.mean(), 'county_ci_low': ci[0], 'county_ci_high': ci[1], 'draws': 2000})
    m = pd.DataFrame(metrics)
    m.to_csv(OUT / 'metrics.csv', index=False)
    summary = m.groupby(['cohort', 'definition', 'state_fips', 'distance_bin', 'method', 'reference'], sort=False).agg(n=('n', 'first'), rmse_mean=('rmse_t_ha', 'mean'), rmse_seed_sd=('rmse_t_ha', 'std'), mse_mean=('mse', 'mean'), r2_mean=('r2', 'mean'), background_skill=('background_skill', 'mean'), mse_minus_reference=('mse_minus_reference', 'mean')).reset_index()
    summary.to_csv(OUT / 'summary.csv', index=False)
    pd.DataFrame(paired).to_csv(OUT / 'paired_county_intervals.csv', index=False)
    save(OUT / 'distance_rules.json', rules)
    print(summary[(summary.definition == 'weather_only') & (summary.state_fips == 'pooled') & summary.distance_bin.isin(['overall', 'high'])].to_string(index=False), flush=True)
if __name__ == '__main__':
    raise SystemExit('Use scripts/train_mainline.py for mainline fitting or the saved-result analysis scripts. This historical entry is retained for method provenance, not default execution.')
