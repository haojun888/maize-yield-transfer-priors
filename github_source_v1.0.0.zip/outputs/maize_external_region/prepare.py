import sys as _sys
from pathlib import Path as _Path
_release_root = _Path(__file__).resolve().parents[2]
_sys.path.insert(0, str(_release_root))
from release_support import configured_path as _configured_path, prepare_transfer as _prepare_transfer
'Frozen outside-development cohort; raw inputs only, no fitting or prediction.'
import ast, concurrent.futures, hashlib, json, sys, subprocess, time, zipfile
from pathlib import Path
from datetime import datetime, timezone
import numpy as np
import pandas as pd
OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
WORK = ROOT / 'work/maize_external_region'
sys.dont_write_bytecode = True
sys.path.insert(0, str(ROOT / 'work/evi_libs'))
sys.path.insert(0, str(WORK))
import rasterio, shapefile, certifi
from rasterio.features import rasterize, bounds
from rasterio.warp import transform_geom
from rasterio.vrt import WarpedVRT
from rasterio.enums import Resampling
from rasterio.windows import Window
FEATURES = ['tmin', 'tmax', 'tavg', 'prec', 'cwb', 'rad', 'ndvi', 'ssm', 'gdd_cumulative', 'evi']
AGG = {'tmin': 'min', 'tmax': 'max', 'tavg': 'mean', 'prec': 'sum', 'cwb': 'sum', 'rad': 'mean', 'ndvi': 'mean', 'ssm': 'mean'}
STATIC = ['awc', 'bulk_density']
BANDS = ['250m_16_days_EVI', '250m_16_days_NDVI', '250m_16_days_pixel_reliability', '250m_16_days_composite_day_of_the_year']
ENV = {'GDAL_DISABLE_READDIR_ON_OPEN': 'EMPTY_DIR', 'CPL_VSIL_CURL_ALLOWED_EXTENSIONS': '.tif', 'GDAL_HTTP_TIMEOUT': '30', 'CURL_CA_BUNDLE': certifi.where(), 'CPL_LOG': 'NUL', 'GDAL_CACHEMAX': 64 * 1024 * 1024}

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda: f.read(4 * 1024 * 1024), b''):
            h.update(b)
    return h.hexdigest()

def save(name, obj):
    (OUT / name).write_text(json.dumps(obj, indent=2), encoding='utf-8')

def original_function(path, name):
    tree = ast.parse(Path(path).read_text(encoding='utf-8-sig'))
    node = next((n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == name))
    exec(compile(ast.Module(body=[node], type_ignores=[]), str(path), 'exec'), globals())
original_function(ROOT / 'outputs/maize_baseline/pipeline.py', 'aggregate_chunk')
original_function(ROOT / 'outputs/maize_feature_increments/prepare.py', 'weather_bins')

def freeze():
    labels = pd.read_csv(ROOT / 'outputs/maize_data_audit/candidate_labels_2004_2023.csv', dtype={'state_fips': str})
    labels = labels[labels.state_fips.isin(['21', '47']) & labels.harvest_year.between(2020, 2023)].rename(columns={'harvest_year': 'year'}).sort_values(['adm_id', 'year']).reset_index(drop=True)
    assert len(labels) == 538 and labels.adm_id.nunique() == 175 and (labels['yield'] > 0).all()
    old = json.loads((ROOT / 'outputs/maize_evi_preparation/full_manifest.json').read_text())['county_ids']
    assert not set(old) & set(labels.adm_id)
    with zipfile.ZipFile(_configured_path('external_e22e1afd74')) as z:
        with z.open('cybench-data/maize/US/crop_calendar_maize_US.csv') as f:
            cal = pd.read_csv(f)
    w = labels[['adm_id', 'year']].merge(cal[['adm_id', 'sos', 'eos']], on='adm_id', validate='many_to_one')
    assert (w.sos.astype(int) <= w.eos.astype(int)).all()
    for n in ['sos', 'eos']:
        w[n + '_date'] = pd.to_datetime(w.year * 1000 + w[n].astype(int), format='%Y%j')
    w['start'] = w.sos_date - pd.Timedelta(days=90)
    w['cutoff'] = w.eos_date - pd.Timedelta(days=60)
    w['length'] = ((w.cutoff - w.start).dt.days // 10 + 1).astype(int)
    items = {}
    for f in sorted((ROOT / 'outputs/maize_evi_preparation').glob('inventory_page_*.json')):
        for item in json.loads(f.read_text())['features']:
            p = item['properties']
            start = pd.Timestamp(p['start_datetime']).tz_localize(None).normalize()
            end = pd.Timestamp(p['end_datetime']).tz_localize(None).normalize()
            tile = (p['modis:horizontal-tile'], p['modis:vertical-tile'])
            key = (*tile, p['start_datetime'])
            if tile not in {(10, 5), (11, 5)} or start.year not in range(2020, 2024):
                continue
            wy = w[w.year == start.year]
            if not ((wy.start <= start) & (wy.cutoff >= end)).any():
                continue
            if key not in items or (p['created'], item['id']) > (items[key]['properties']['created'], items[key]['id']):
                items[key] = item
    items = sorted(items.values(), key=lambda i: (i['properties']['start_datetime'], i['id']))
    labels[['adm_id', 'year', 'yield', 'state_fips']].to_csv(OUT / 'target_cohort_manifest.csv', index=False)
    w.to_csv(OUT / 'date_windows.csv', index=False)
    design = {'cohort': 'Kentucky and Tennessee, FIPS21/47,2020–2023', 'samples': 538, 'counties': 175, 'selection': 'Geography and existing positive eligible labels; locked before any prediction', 'new_geography': True, 'new_years': False, 'source_overlap_counties': 0, 'no_target_fitting': True, 'dynamic_features': FEATURES, 'static_features': STATIC, 'calendar': 'fixed county SOS/EOS integer day-of-year; SOS−90 through EOS−60 inclusive;10day bins', 'gdd': 'unchanged original weather_bins cumulative from SOS; tmin/tmax clipped10–30; bin last day', 'evi': 'native250m; crop weights resampled average; reliability0; EVI/NDVIrange−2000–10000; composite DOY inside period; entire composite inside window;validweightfraction>=0.2; bin composite end; within-bin mean', 'tasks': [{'id': i['id'], 'tile': [i['properties']['modis:horizontal-tile'], i['properties']['modis:vertical-tile']], 'start': i['properties']['start_datetime'], 'end': i['properties']['end_datetime']} for i in items], 'dependencies': {str(f.relative_to(ROOT)): sha(f) for f in [ROOT / 'outputs/maize_baseline/pipeline.py', ROOT / 'outputs/maize_feature_increments/prepare.py', ROOT / 'outputs/maize_evi_preparation/full.py', ROOT / 'work/evi_geometry/US.shp', ROOT / 'work/evi_geometry/crop_mask_maize_WC.tif', OUT / 'target_cohort_manifest.csv', OUT / 'date_windows.csv']}, 'archive_sha256': sha(_configured_path('external_e22e1afd74')), 'max_valid_length': int(w.length.max()), 'padded_width': max(23, int(w.length.max()))}
    if (OUT / 'design.json').exists():
        assert json.loads((OUT / 'design.json').read_text()) == design
    else:
        save('design.json', design)
    print('Frozen cohort', len(labels), labels.adm_id.nunique(), 'tasks', len(items), 'T', design['padded_width'], flush=True)
    return (labels, w, items, design)

def base(labels, w, T):
    path = WORK / 'base9.npz'
    if path.exists():
        return dict(np.load(path))
    pieces = []
    daily = []
    prefix = 'cybench-data/maize/US/'
    ids = set(labels.adm_id)
    with zipfile.ZipFile(_configured_path('external_e22e1afd74')) as z:
        with z.open(prefix + 'soil_maize_US.csv') as f:
            soil = pd.read_csv(f)
        for source, cols in [('meteo', FEATURES[:6]), ('ndvi', ['ndvi']), ('soil_moisture', ['ssm'])]:
            chunkstats = []
            with z.open(prefix + source + '_maize_US.csv') as f:
                for frame in pd.read_csv(f, usecols=['adm_id', 'date'] + cols, chunksize=250000):
                    frame = frame[frame.adm_id.isin(ids) & frame.date.between(20200101, 20231231)]
                    if frame.empty:
                        continue
                    chunkstats.append(aggregate_chunk(frame, w, {c: AGG[c] for c in cols}))
                    if source == 'meteo':
                        daily.append(frame[['adm_id', 'date', 'tmin', 'tmax', 'prec']].copy())
            stats = pd.concat(chunkstats, ignore_index=True)
            reducers = {'latest': 'max'}
            for c in cols:
                how = AGG[c]
                reducers[c + '_count'] = 'sum'
                reducers[c + '_' + ('sum' if how in ['sum', 'mean'] else how)] = 'sum' if how in ['sum', 'mean'] else how
            stats = stats.groupby(['adm_id', 'year', 'bin']).agg(reducers)
            for c in cols:
                how = AGG[c]
                v = stats[c + '_' + ('sum' if how in ['sum', 'mean'] else how)]
                stats[c] = v / stats[c + '_count'] if how == 'mean' else v
                stats.loc[stats[c + '_count'] == 0, c] = np.nan
            check = stats.reset_index().merge(w[['adm_id', 'year', 'cutoff']], on=['adm_id', 'year'])
            assert (pd.to_datetime(check.latest.astype(str), format='%Y%m%d') <= check.cutoff).all()
            pieces.append(stats[cols])
            print('Prepared raw', source, len(stats), flush=True)
    index = pd.MultiIndex.from_tuples([(r.adm_id, r.year, b) for r in w.itertuples() for b in range(T)], names=['adm_id', 'year', 'bin'])
    x = np.full((len(w), T, 9), np.nan, np.float32)
    x[:, :, :8] = pd.concat(pieces, axis=1).reindex(index)[FEATURES[:8]].to_numpy(np.float32).reshape(len(w), T, 8)
    weather = pd.concat(daily, ignore_index=True)
    weather['observed_date'] = pd.to_datetime(weather.date.astype(str), format='%Y%m%d')
    weather['year'] = weather.observed_date.dt.year
    groups = {k: v for k, v in weather.groupby(['adm_id', 'year'])}
    for i, r in enumerate(w.itertuples()):
        x[i, :r.length, 8] = weather_bins(groups[r.adm_id, r.year], r.start, r.sos_date, r.cutoff, r.length)[:, 0]
    lengths = w.length.to_numpy()
    valid = np.arange(T)[None, :] < lengths[:, None]
    x[~valid] = np.nan
    static = labels.merge(soil[['adm_id'] + STATIC], on='adm_id', validate='many_to_one')[STATIC].to_numpy(np.float32)
    assert np.isfinite(static).all()
    data = dict(x=x, static=static, lengths=lengths, y=labels['yield'].to_numpy(np.float32), years=labels.year.to_numpy(), counties=labels.adm_id.to_numpy(dtype=str))
    np.savez_compressed(path, **data)
    return data

def token():
    import os
    value = os.environ.get('MAIZE_DATA_ACCESS_TOKEN')
    if not value:
        raise RuntimeError('Set MAIZE_DATA_ACCESS_TOKEN for authenticated downloads; no credentials are distributed.')
    return value

def geometries(items, ids):
    lookup = {c: i + 1 for i, c in enumerate(ids)}
    reader = shapefile.Reader(str(ROOT / 'work/evi_geometry/US.shp'))
    geoms = [(r.shape.__geo_interface__, lookup[r.record['adm_id']]) for r in reader.iterShapeRecords() if r.record['adm_id'] in lookup]
    assert len(geoms) == len(ids)
    reps = {}
    for i in items:
        reps.setdefault((i['properties']['modis:horizontal-tile'], i['properties']['modis:vertical-tile']), i)
    result = {}
    for key, item in reps.items():
        path = WORK / f'geometry_{key[0]}_{key[1]}.npz'
        result[key] = path
        if path.exists():
            continue
        with rasterio.Env(**ENV), rasterio.open(item['assets'][BANDS[0]]['href'] + '?' + token()) as ds:
            local = []
            for g, idx in geoms:
                geom = transform_geom('EPSG:4326', ds.crs, g)
                l, b, r, t = bounds(geom)
                if r > ds.bounds.left and l < ds.bounds.right and (t > ds.bounds.bottom) and (b < ds.bounds.top):
                    local.append((geom, idx))
            labels = rasterize(local, out_shape=ds.shape, transform=ds.transform, dtype='uint16')
            rows, cols = np.where(labels > 0)
            r0, r1 = (int(rows.min()), int(rows.max() + 1))
            c0, c1 = (int(cols.min()), int(cols.max() + 1))
            win = Window(c0, r0, c1 - c0, r1 - r0)
            labels = labels[r0:r1, c0:c1]
            with rasterio.open(ROOT / 'work/evi_geometry/crop_mask_maize_WC.tif') as mask, WarpedVRT(mask, crs=ds.crs, transform=ds.transform, width=ds.width, height=ds.height, resampling=Resampling.average, dtype='float32') as vrt:
                weight = vrt.read(1, window=win)
            weight = np.where((labels > 0) & np.isfinite(weight) & (weight > 0) & (weight <= 100), weight, 0).astype(np.float32)
            assert (weight > 0).any()
            np.savez_compressed(path, labels=labels, weight=weight, window=np.array([c0, r0, c1 - c0, r1 - r0]), transform=np.array(tuple(ds.transform)[:6]), crs=np.array(ds.crs.to_wkt()))
        print('New geometry', key, flush=True)
    return result
original_function(ROOT / 'outputs/maize_evi_preparation/full.py', 'extract')

def evi(items, geometry, ids, w, data, design):
    gross = np.zeros(len(ids) + 1)
    for path in geometry.values():
        with np.load(path) as g:
            gross += np.bincount(g['labels'].ravel(), weights=g['weight'].ravel(), minlength=len(gross))
    assert (gross[1:] > 0).all()
    errors = []
    done = 0
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        for first in range(0, len(items), 8):
            sas = token()
            batch = items[first:first + 8]
            futures = [pool.submit(extract, i, geometry[i['properties']['modis:horizontal-tile'], i['properties']['modis:vertical-tile']], sas, len(ids)) for i in batch]
            for item, f in zip(batch, futures):
                iid, status = f.result()
                if status.startswith('error'):
                    for retry in range(2):
                        time.sleep(2)
                        iid, status = extract(item, geometry[item['properties']['modis:horizontal-tile'], item['properties']['modis:vertical-tile']], token(), len(ids))
                        if not status.startswith('error'):
                            break
                if status.startswith('error'):
                    errors.append({'id': iid, 'status': status})
                done += 1
            save('progress.json', {'processed': done, 'total': len(items), 'errors': errors, 'complete': False})
            print('EVI tasks', done, '/', len(items), 'errors', len(errors), flush=True)
    if errors:
        raise RuntimeError('Missing remote tasks; safe IDs in progress.json')
    grouped = {}
    for item in items:
        p = item['properties']
        key = (p['start_datetime'][:10], p['end_datetime'][:10])
        total = grouped.setdefault(key, [np.zeros(len(ids) + 1) for _ in range(4)])
        with np.load(WORK / (item['id'] + '.npz')) as g:
            for t, k in zip(total, ['evi_sum', 'ndvi_sum', 'valid_weight', 'valid_pixels']):
                t += g[k]
    records = []
    wi = {(r.adm_id, int(r.year)): r for r in w.itertuples()}
    for (s, e), (es, ns, v, c) in sorted(grouped.items()):
        start = pd.Timestamp(s)
        end = pd.Timestamp(e)
        year = start.year
        for idx, county in enumerate(ids, 1):
            row = wi.get((county, year))
            if row is None or start < row.start or end > row.cutoff:
                continue
            coverage = v[idx] / gross[idx]
            observed = coverage >= 0.2 and v[idx] > 0
            records.append(dict(adm_id=county, year=year, period_start=s, period_end=e, cutoff=str(row.cutoff.date()), evi=es[idx] / v[idx] if observed else np.nan, matched_ndvi=ns[idx] / v[idx] if observed else np.nan, valid_crop_weight_fraction=coverage, valid_pixels=int(c[idx]), observed=observed, bin=int((end - row.start).days // 10)))
    table = pd.DataFrame(records)
    table.to_csv(OUT / 'county_period_features.csv', index=False)
    stats = table.groupby(['adm_id', 'year', 'bin']).evi.mean()
    x = np.full((*data['x'].shape[:2], 10), np.nan, np.float32)
    x[:, :, :9] = data['x']
    lookup = {(c, int(y)): i for i, (c, y) in enumerate(zip(data['counties'], data['years']))}
    for (c, y, b), value in stats.items():
        idx = lookup[c, int(y)]
        assert b < data['lengths'][idx]
        x[idx, b, 9] = value
    valid = np.arange(x.shape[1])[None, :] < data['lengths'][:, None]
    assert np.isnan(x[~valid]).all()
    assert np.isfinite(x[:, :, 8][valid]).all()
    np.testing.assert_array_equal(x[:, :, :9], data['x'])
    assert (pd.to_datetime(table.period_start) >= pd.to_datetime(table[['adm_id', 'year']].merge(w[['adm_id', 'year', 'start']], on=['adm_id', 'year'], how='left').start)).all()
    assert (pd.to_datetime(table.period_end) <= pd.to_datetime(table.cutoff)).all()
    data['x'] = x
    np.savez_compressed(WORK / 'dataset.npz', **data)
    save('feature_order.json', {'dynamic_features': FEATURES, 'static_features': STATIC})
    report = {'verified': True, 'samples': len(x), 'counties': len(ids), 'excluded_samples': 0, 'raw_only': True, 'no_target_fitting': True, 'new_geography': True, 'new_years': False, 'source_county_overlap': 0, 'shape': list(x.shape), 'valid_length_range': [int(data['lengths'].min()), int(data['lengths'].max())], 'static_finite': True, 'gdd_original_function_reused': True, 'base8_aggregation_original_function_reused': True, 'padded_steps_all_nan': True, 'native250m': True, 'all_counties_positive_crop_weight': True, 'common_valid_EVI_NDVI_pixels': True, 'composite_cutoff_checked': True, 'missing_fraction_valid_steps': {f: float(np.isnan(x[:, :, i][valid]).mean()) for i, f in enumerate(FEATURES)}, 'dataset_sha256': sha(WORK / 'dataset.npz'), 'design_sha256': sha(OUT / 'design.json'), 'dependencies_unchanged': all((sha(ROOT / k) == v for k, v in design['dependencies'].items())), 'tile_tasks': len(items), 'county_period_rows': len(table), 'historical_product_release_not_certified': True}
    assert report['dependencies_unchanged']
    save('verification.json', report)
    save('metadata.json', {**report, 'dataset_path': str(WORK / 'dataset.npz'), 'dynamic_features': FEATURES, 'static_features': STATIC})
    save('progress.json', {'processed': len(items), 'total': len(items), 'errors': [], 'complete': True})
    print('Verified dataset', report['shape'], flush=True)

def run():
    labels, w, items, design = freeze()
    data = base(labels, w, design['padded_width'])
    ids = sorted(labels.adm_id.unique())
    geometry = geometries(items, ids)
    evi(items, geometry, ids, w, data, design)
if __name__ == '__main__':
    raise SystemExit('Use scripts/train_mainline.py for mainline fitting or the saved-result analysis scripts. This historical entry is retained for method provenance, not default execution.')
