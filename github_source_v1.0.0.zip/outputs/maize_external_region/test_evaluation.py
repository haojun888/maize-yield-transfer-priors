import sys as _sys
from pathlib import Path as _Path
_release_root = _Path(__file__).resolve().parents[2]
_sys.path.insert(0, str(_release_root))
from release_support import configured_path as _configured_path, prepare_transfer as _prepare_transfer
'Reject target-fitted scaling and padding leakage in external preprocessing.'
import importlib.util
import unittest
import numpy as np

class FrozenTransformContract(unittest.TestCase):

    def test_source_parameters_and_padding(self):
        self.assertIsNotNone(importlib.util.find_spec('evaluate'), 'External evaluator is missing')
        import evaluate as e
        data = {'x': np.array([[[30.0, np.nan], [np.nan, 14.0], [100.0, 100.0]]], dtype=np.float32), 'static': np.array([[30.0, np.nan]], dtype=np.float32), 'lengths': np.array([2]), 'y': np.array([900.0])}
        params = {'median': [10.0, 10.0], 'mean': [10.0, 10.0], 'scale': [2.0, 2.0], 'static_median': [10.0, 10.0], 'static_mean': [10.0, 10.0], 'static_scale': [2.0, 2.0]}
        seq, soil = e.frozen_arrays(data, params)
        np.testing.assert_array_equal(seq, [[[10.0, 0.0, 1.0, 0.0, 1.0], [0.0, 2.0, 0.0, 1.0, 1.0], [0.0, 0.0, 0.0, 0.0, 0.0]]])
        np.testing.assert_array_equal(soil, [[10.0, 0.0]])
        data['y'] = np.array([-999.0])
        second = e.frozen_arrays(data, params)
        np.testing.assert_array_equal(second[0], seq)
        np.testing.assert_array_equal(second[1], soil)
if __name__ == '__main__':
    raise SystemExit('Use scripts/train_mainline.py for mainline fitting or the saved-result analysis scripts. This historical entry is retained for method provenance, not default execution.')
