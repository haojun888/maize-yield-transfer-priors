import sys as _sys
from pathlib import Path as _Path
_release_root = _Path(__file__).resolve().parents[2]
_sys.path.insert(0, str(_release_root))
from release_support import configured_path as _configured_path, prepare_transfer as _prepare_transfer
'Locked external geography evaluation; source-only transforms and old models.'
import hashlib
import json
import sys
import time
from pathlib import Path
import numpy as np
import pandas as pd
import torch
OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
WORK = ROOT / 'work/maize_external_region'
sys.path.insert(0, str(ROOT / 'outputs/maize_budget_controls'))
import budget_controls as b
s = b.s
t = b.t
i = b.i
sys.path.insert(0, str(ROOT / 'outputs/maize_environment_coverage'))
import coverage_analysis as cov

def frozen_arrays(data, params):
    x = data['x']
    static = data['static']
    lengths = data['lengths']
    valid = np.arange(x.shape[1])[None, :] < lengths[:, None]
    observed = np.isfinite(x) & valid[:, :, None]
    median = np.asarray(params['median'], dtype=np.float32)
    mean = np.asarray(params['mean'], dtype=np.float32)
    scale = np.asarray(params['scale'], dtype=np.float32)
    filled = np.where(observed, x, median)
    normalized = (filled - mean) / scale
    normalized[~valid] = 0.0
    packed = np.concatenate([normalized, observed.astype(np.float32), valid[:, :, None].astype(np.float32)], axis=2).astype(np.float32)
    sm = np.asarray(params['static_median'], dtype=np.float32)
    sf = np.where(np.isfinite(static), static, sm)
    soil = ((sf - np.asarray(params['static_mean'], dtype=np.float32)) / np.asarray(params['static_scale'], dtype=np.float32)).astype(np.float32)
    assert np.isfinite(packed).all() and np.isfinite(soil).all()
    return (packed, soil)

def encode(teacher, data, params):
    seq, soil = frozen_arrays(data, params)
    result = []
    teacher.eval()
    with torch.no_grad():
        for first in range(0, len(seq), 512):
            result.append(teacher.encode(torch.from_numpy(seq[first:first + 512]).to(s.DEVICE), torch.from_numpy(soil[first:first + 512]).to(s.DEVICE), torch.from_numpy(data['lengths'][first:first + 512])).cpu().numpy())
    return np.concatenate(result)

def methods(seed, reference):
    specs = {'sobol_fixed': (i.old_checkpoint(seed, 'sobol_fixed'), 'fixed', reference, 'original_sobol')}
    for name, (prior, order, family) in b.specs(reference).items():
        specs[name] = (b.OUT / str(seed) / f'final_{name}.pt', 'fixed', prior, family)
    for name in ['uniform', 'learned']:
        path = t.OUT / f'gdd_evi__E_to_W_{seed}/final_{name}.pt'
        ck = torch.load(path, map_location='cpu', weights_only=True)
        specs[name] = (path, ck['mode'], np.array(ck['prior']), name)
    gain_manifest = b.read(i.GAIN / 'manifest.json')
    for j, order in enumerate(gain_manifest['orders']):
        name = f'random_{j:02d}'
        specs[name] = (i.old_checkpoint(seed, name), 'fixed', reference[order], 'cross_block_random')
    for name in ['global_sobol_init', 'dynamic_sobol_init', 'capacity_sobol_fixed']:
        specs[name] = (i.GAIN / f'E_to_W_{seed}/final_{name}.pt', name, reference, name)
    assert len(specs) == 74
    return specs

def data_audit():
    v = b.read(OUT / 'verification.json')
    design = b.read(OUT / 'design.json')
    assert v['verified'] and v['samples'] == 538 and (v['counties'] == 175) and (v['excluded_samples'] == 0)
    assert v['dataset_sha256'] == s.sha(WORK / 'dataset.npz') and v['design_sha256'] == s.sha(OUT / 'design.json')
    for path, digest in design['dependencies'].items():
        assert s.sha(ROOT / path) == digest, path
    data = np.load(WORK / 'dataset.npz')
    base = np.load(WORK / 'base9.npz')
    np.testing.assert_array_equal(data['x'][:, :, :9], base['x'])
    for key in ['static', 'lengths', 'y', 'years', 'counties']:
        np.testing.assert_array_equal(data[key], base[key])
    cohort = pd.read_csv(OUT / 'target_cohort_manifest.csv', dtype={'adm_id': str, 'state_fips': str})
    windows = pd.read_csv(OUT / 'date_windows.csv', parse_dates=['start', 'cutoff', 'sos_date', 'eos_date'], dtype={'adm_id': str})
    np.testing.assert_array_equal(cohort.adm_id, data['counties'])
    np.testing.assert_array_equal(cohort.year, data['years'])
    np.testing.assert_allclose(cohort['yield'], data['y'], atol=1e-06)
    assert set(cohort.state_fips) == {'21', '47'} and set(data['years']) == {2020, 2021, 2022, 2023}
    source = np.load(s.CACHE / 'gdd_evi.npz')
    assert not set(data['counties']) & set(source['counties'])
    assert not cohort.duplicated(['adm_id', 'year']).any()
    valid = np.arange(23)[None, :] < data['lengths'][:, None]
    assert np.isnan(data['x'][~valid]).all() and np.isfinite(data['static']).all()
    np.testing.assert_array_equal(windows.length, data['lengths'])
    assert ((windows.sos_date - windows.start).dt.days == 90).all()
    assert ((windows.eos_date - windows.cutoff).dt.days == 60).all()
    ids = sorted(set(data['counties']))
    gross = np.zeros(len(ids) + 1)
    geometry_hashes = {}
    tile_hashes = {}
    for path in sorted(WORK.glob('geometry_*.npz')):
        g = np.load(path)
        labels = g['labels']
        weight = g['weight']
        assert labels.max() <= len(ids) and weight.shape == labels.shape
        gross += np.bincount(labels.ravel(), weights=weight.ravel(), minlength=len(gross))
        geometry_hashes[str(path)] = s.sha(path)
    assert (gross[1:] > 0).all()
    grouped = {}
    for task in design['tasks']:
        path = WORK / (task['id'] + '.npz')
        g = np.load(path)
        tile_hashes[str(path)] = s.sha(path)
        key = (task['start'][:10], task['end'][:10])
        record = grouped.setdefault(key, [np.zeros(len(ids) + 1) for _ in range(4)])
        for total, name in zip(record, ['evi_sum', 'ndvi_sum', 'valid_weight', 'valid_pixels']):
            assert len(g[name]) == len(ids) + 1 and np.isfinite(g[name]).all()
            total += g[name]
    expected = {}
    wlookup = {(r.adm_id, int(r.year)): r for r in windows.itertuples()}
    for (start, end), (es, ns, vw, pixels) in grouped.items():
        pstart = pd.Timestamp(start)
        pend = pd.Timestamp(end)
        for j, county in enumerate(ids, 1):
            row = wlookup.get((county, pstart.year))
            if row is None or pstart < row.start or pend > row.cutoff:
                continue
            coverage = vw[j] / gross[j]
            assert coverage <= 1 + 1e-08
            observed = coverage >= 0.2 and vw[j] > 0
            expected[county, pstart.year, start, end] = (es[j] / vw[j] if observed else np.nan, ns[j] / vw[j] if observed else np.nan, coverage, int(pixels[j]), observed, int((pend - row.start).days // 10))
    table = pd.read_csv(OUT / 'county_period_features.csv', dtype={'adm_id': str})
    assert len(table) == len(expected) == 6471
    for row in table.itertuples():
        got = expected[row.adm_id, row.year, row.period_start, row.period_end]
        np.testing.assert_allclose([row.evi, row.matched_ndvi, row.valid_crop_weight_fraction], [*got[:3]], atol=1e-10, equal_nan=True)
        assert row.valid_pixels == got[3] and row.observed == got[4] and (row.bin == got[5])
    reconstructed = np.full((538, 23), np.nan, np.float32)
    lookup = {(c, int(y)): j for j, (c, y) in enumerate(zip(data['counties'], data['years']))}
    for (county, year, binid), value in table.groupby(['adm_id', 'year', 'bin']).evi.mean().items():
        reconstructed[lookup[county, int(year)], binid] = value
    np.testing.assert_array_equal(reconstructed, data['x'][:, :, 9])
    s.save(OUT / 'input_audit.json', {'verified': True, 'samples': 538, 'tile_summaries': 102, 'period_rows': 6471, 'geometry_sha256': geometry_hashes, 'tile_sha256': tile_hashes, 'prepare_code_sha256': s.sha(OUT / 'prepare.py'), 'base9_sha256': s.sha(WORK / 'base9.npz'), 'dataset_sha256': s.sha(WORK / 'dataset.npz'), 'no_source_county_overlap': True, 'EVI_independent_reassembly': True})
    return (data, windows)

def environment(data, windows):
    features = cov.environment(data, windows)
    original = np.load(ROOT / 'work/maize_environment_coverage/environment.npy')
    source = np.load(s.CACHE / 'gdd_evi.npz')
    split = np.load(t.OUT / 'split_E_to_W.npz')
    parameters = b.read(ROOT / 'outputs/maize_environment_coverage/standardization.json')
    result = {}
    rows = []
    for definition, (cols, groups) in cov.DEFS.items():
        p = parameters[f'{definition}__fusion_2019']

        def transform(values):
            return ((values[:, cols] - np.array(p['mean'])) / np.array(p['scale']) / np.sqrt(p['group_sizes'])).astype(np.float32)
        z = transform(features)
        source_z = transform(original)
        reference = split['fit'] & np.isfinite(original[:, cols]).all(1)
        assert np.isfinite(z).all()
        distances = cov.neighbor_distance(z, source_z[reference])
        direct = []
        for first in range(0, len(z), 32):
            squared = ((z[first:first + 32, None, :].astype(np.float64) - source_z[reference][None].astype(np.float64)) ** 2).sum(-1)
            direct.extend(np.sqrt(np.partition(squared, 4, axis=1)[:, :5]).mean(1))
        np.testing.assert_allclose(distances, direct, atol=8e-05, rtol=8e-05)
        old = np.load(ROOT / f'work/maize_environment_coverage/{definition}__fusion_2019__E_to_W__joint.npz')
        low = float(old['distance'][old['binid'] == 0].max())
        high = float(old['distance'][old['binid'] == 2].min())
        binid = np.where(distances <= low, 0, np.where(distances >= high, 2, 1))
        q95 = float(old['source_q95'])
        result[definition] = {'distance': distances, 'binid': binid, 'source_q95': q95, 'original_low_max': low, 'original_high_min': high, 'source_n': int(reference.sum())}
        for j in range(len(z)):
            rows.append({'definition': definition, 'row': j, 'adm_id': data['counties'][j], 'year': data['years'][j], 'distance': float(distances[j]), 'distance_bin': ['low', 'middle', 'high'][binid[j]], 'source_q95': q95, 'above_source_q95': bool(distances[j] > q95)})
    pd.DataFrame(rows).to_csv(OUT / 'environment_distances.csv', index=False)
    s.save(OUT / 'environment_rules.json', {k: {name: value for name, value in v.items() if name not in ['distance', 'binid']} for k, v in result.items()})
    return result

def lock(data):
    path = OUT / 'evaluation_design.json'
    budget = b.read(b.OUT / 'verification.json')
    assert budget['verified'] and budget['parents_unchanged']
    deps = {}
    files = [Path(__file__), OUT / 'test_evaluation.py', OUT / 'design.json', OUT / 'verification.json', OUT / 'input_audit.json', OUT / 'prepare.py', OUT / 'date_windows.csv', OUT / 'target_cohort_manifest.csv', OUT / 'feature_order.json', WORK / 'dataset.npz', b.OUT / 'verification.json', b.OUT / 'manifest.json', ROOT / 'outputs/maize_environment_coverage/standardization.json', ROOT / 'work/maize_environment_coverage/environment.npy']
    for definition in cov.DEFS:
        files.append(ROOT / f'work/maize_environment_coverage/{definition}__fusion_2019__E_to_W__joint.npz')
    for file in files:
        deps[str(file)] = s.sha(file)
    model_hashes = {}
    method_names = None
    for seed in b.SEEDS:
        folder = t.OUT / f'gdd_evi__E_to_W_{seed}'
        prior = np.array(b.read(folder / 'priors.json')['prior'])
        spec = methods(seed, prior)
        names = list(spec)
        if method_names is None:
            method_names = names
        assert names == method_names
        for model, mode, p, family in spec.values():
            digest = s.sha(model)
            model_hashes[str(model)] = digest
            if str(model) in budget['model_sha256']:
                assert digest == budget['model_sha256'][str(model)]
        for name in ['teacher.pt', 'preprocessing.json', 'teacher_complete.json', 'priors.json']:
            deps[str(folder / name)] = s.sha(folder / name)
    deps.update(model_hashes)
    design = {'cohort': 'KY/TN2020-2023', 'samples': 538, 'source': 'unchanged E2004-2019 fusion/E2004-2013 teacher', 'methods': method_names, 'seeds': b.SEEDS, 'target_model_cases': 222, 'new_training': 0, 'primary_comparisons': ['sobol_fixed vs uniform/learned/block_equal', '47 within-block and20cross-block complete distributions'], 'primary_subgroups': ['overall', 'original frozen weather-calendar high-distance rule'], 'secondary': 'original frozen low/middle and weather-only sensitivity', 'no_target_fitting': True, 'no_target_selection': True, 'no_new_target_quantiles': True, 'sha256': deps}
    if path.exists():
        assert b.read(path) == design, 'External evaluation inputs changed'
    else:
        s.save(path, design)
    return design

def run():
    start = time.time()
    data, windows = data_audit()
    design = lock(data)
    fp = hashlib.sha256(json.dumps(design, sort_keys=True).encode()).hexdigest()
    env = environment(data, windows)
    sys.path.insert(0, str(i.GAIN))
    import controls as c
    predictions = []
    weights = []
    model_rows = []
    encode_checks = []
    for seed in b.SEEDS:
        original, split, teacher, bank, bg, residual, reference = i.load_context(seed)
        params = b.read(t.OUT / f'gdd_evi__E_to_W_{seed}/preprocessing.json')
        reconstructed = encode(teacher, original, params)
        np.testing.assert_allclose(reconstructed, bank, atol=3e-06, rtol=3e-06)
        encoded = encode(teacher, data, params)
        np.testing.assert_allclose(encoded, encode(teacher, data, params), atol=2e-06, rtol=2e-06)
        np.save(WORK / f'bank_E_{seed}.npy', encoded)
        background_model = b.read(t.OUT / 'background_E_to_W.json')['final_fit']
        background = s.e.background_predict(background_model, data['years'], data['counties'])
        values = []
        weight_values = []
        for name, (path, mode, prior, family) in methods(seed, reference).items():
            ck = torch.load(path, map_location='cpu', weights_only=True)
            model = c.factory(teacher.head, mode, prior).to(s.DEVICE)
            model.load_state_dict(ck['state_dict'])
            np.testing.assert_allclose(model.prior.cpu().numpy(), prior, atol=1e-07)
            assert sum((p.numel() for p in model.parameters())) == ck['parameters']
            prediction, w = s.predict(model, encoded, ck['target_mean'], ck['target_std'])
            prediction = prediction + background
            reloaded = c.factory(teacher.head, mode, prior).to(s.DEVICE)
            reloaded.load_state_dict(torch.load(path, map_location='cpu', weights_only=True)['state_dict'])
            check, cw = s.predict(reloaded, encoded, ck['target_mean'], ck['target_std'])
            np.testing.assert_allclose(prediction, check + background, atol=2e-06, rtol=2e-06)
            np.testing.assert_allclose(w, cw, atol=2e-06)
            values.append(prediction)
            weight_values.append(w)
            model_rows.append({'seed': seed, 'method': name, 'family': family, 'parameters': ck['parameters'], 'epoch': ck['epoch']})
        predictions.append(values)
        weights.append(weight_values)
        encode_checks.append({'seed': seed, 'source_bank_max_abs_difference': float(np.max(np.abs(reconstructed - bank))), 'new_bank_sha256': s.sha(WORK / f'bank_E_{seed}.npy')})
        print('EXTERNAL MODELS VERIFIED', seed, len(values), round(time.time() - start, 1), flush=True)
    predictions = np.array(predictions, dtype=np.float32)
    weights = np.array(weights, dtype=np.float32)
    assert predictions.shape == (3, 74, 538) and np.isfinite(predictions).all()
    np.savez_compressed(OUT / 'model_predictions.npz', predictions=predictions, weights=weights, seeds=np.array(b.SEEDS), methods=np.array(design['methods']), y=data['y'], counties=data['counties'], years=data['years'], background=background, calendar_bin=env['weather_calendar']['binid'], weather_bin=env['weather_only']['binid'])
    pd.DataFrame(model_rows).to_csv(OUT / 'evaluated_models.csv', index=False)
    frames = []
    metrics = []
    intervals = []
    yearly = []
    distribution = []
    info = {row['method']: row['family'] for row in model_rows}
    for si, seed in enumerate(b.SEEDS):
        for mi, name in enumerate(design['methods']):
            frames.append(pd.DataFrame({'seed': seed, 'method': name, 'family': info[name], 'adm_id': data['counties'], 'year': data['years'], 'observed_yield_t_ha': data['y'], 'predicted_yield_t_ha': predictions[si, mi], 'background_t_ha': background, 'original_calendar_distance_bin': env['weather_calendar']['binid']}))
    pd.concat(frames, ignore_index=True).to_csv(OUT / 'predictions.csv', index=False)
    for definition in cov.DEFS:
        bins = env[definition]['binid']
        for label, subset in [('overall', np.ones(538, dtype=bool))] + [(name, bins == j) for j, name in enumerate(['low', 'middle', 'high'])]:
            if not subset.any():
                continue
            y = data['y'][subset].astype(np.float64)
            for si, seed in enumerate(b.SEEDS):
                for mi, name in enumerate(design['methods']):
                    p = predictions[si, mi, subset].astype(np.float64)
                    error = p - y
                    base = predictions[si, 0, subset].astype(np.float64) - y
                    metrics.append({'definition': definition, 'distance_bin': label, 'seed': seed, 'method': name, 'family': info[name], **s.e.metrics(y, p), 'mse': np.mean(error ** 2), 'mse_minus_sobol': np.mean(error ** 2 - base ** 2), 'background_skill': 1 - np.mean(error ** 2) / np.mean((background[subset] - y) ** 2)})
            counties = data['counties'][subset]
            unique, inverse = np.unique(counties, return_inverse=True)
            count = np.bincount(inverse)
            rng = np.random.default_rng(20261013)
            draws = rng.integers(0, len(unique), (2000, len(unique)))
            den = count[draws].sum(1)
            squared = (predictions[:, :, subset].astype(np.float64) - y) ** 2
            restricted = [j for j, name in enumerate(design['methods']) if name.startswith('within_')]
            cross = [j for j, name in enumerate(design['methods']) if name.startswith('random_')]
            for name, indices in [('block_equal', [design['methods'].index('block_equal')]), ('uniform', [design['methods'].index('uniform')]), ('learned', [design['methods'].index('learned')]), ('within_mean', restricted), ('cross_mean', cross)]:
                difference = (squared[:, indices].mean(1) - squared[:, 0]).mean(0)
                sums = np.bincount(inverse, weights=difference)
                bootstrap = sums[draws].sum(1) / den
                low, high = np.quantile(bootstrap, [0.025, 0.975])
                intervals.append({'definition': definition, 'distance_bin': label, 'comparison': name, 'mse_minus_sobol': difference.mean(), 'county_bootstrap_low': low, 'county_bootstrap_high': high, 'counties': len(unique)})
        for year in [2020, 2021, 2022, 2023]:
            for label, subset in [('overall', data['years'] == year), ('high', (data['years'] == year) & (bins == 2))]:
                if not subset.any():
                    continue
                for mi, name in enumerate(design['methods']):
                    error = predictions[:, mi, subset].astype(np.float64) - data['y'][subset]
                    base = predictions[:, 0, subset].astype(np.float64) - data['y'][subset]
                    yearly.append({'definition': definition, 'year': year, 'distance_bin': label, 'method': name, 'n': int(subset.sum()), 'rmse_mean': np.sqrt((error ** 2).mean(1)).mean(), 'mse_minus_sobol': (error ** 2 - base ** 2).mean()})
    metric = pd.DataFrame(metrics)
    metric.to_csv(OUT / 'metrics.csv', index=False)
    summary = metric.groupby(['definition', 'distance_bin', 'method', 'family'], sort=False).agg(n=('n', 'first'), rmse_mean=('rmse_t_ha', 'mean'), rmse_seed_sd=('rmse_t_ha', 'std'), mse_mean=('mse', 'mean'), r2_mean=('r2', 'mean'), bias_mean=('bias_t_ha', 'mean'), mse_minus_sobol=('mse_minus_sobol', 'mean'), background_skill=('background_skill', 'mean')).reset_index()
    summary.to_csv(OUT / 'summary.csv', index=False)
    for (definition, label), part in summary.groupby(['definition', 'distance_bin'], sort=False):
        base = part[part.method == 'sobol_fixed'].iloc[0]
        for family, prefix in [('restricted_all', 'within_'), ('cross_block_random', 'random_')]:
            values = part[part.method.str.startswith(prefix)].rmse_mean.to_numpy()
            assert len(values) == (47 if prefix == 'within_' else 20)
            distribution.append({'definition': definition, 'distance_bin': label, 'family': family, 'sobol_rmse': base.rmse_mean, 'count': len(values), 'median_rmse': np.median(values), 'q25_rmse': np.quantile(values, 0.25), 'q75_rmse': np.quantile(values, 0.75), 'better_than_sobol': int((values < base.rmse_mean).sum())})
    pd.DataFrame(distribution).to_csv(OUT / 'distribution.csv', index=False)
    pd.DataFrame(intervals).to_csv(OUT / 'paired_county_intervals.csv', index=False)
    pd.DataFrame(yearly).to_csv(OUT / 'year_sensitivity.csv', index=False)
    headline = summary[(summary.definition == 'weather_calendar') & summary.method.isin(['sobol_fixed', 'block_equal', 'uniform', 'learned', 'global_sobol_init', 'dynamic_sobol_init', 'capacity_sobol_fixed'])]
    lines = ['# 独立地域确认结果：肯塔基州＋田纳西州（2026-10-09）', '', '538县年、175县、2020—2023年，全部保留；与原12州无县重叠。队列和输入准备在新区域任何预测之前锁定。使用旧东部源预处理、教师、先验、背景和预测头，零新增训练、零目标拟合或选择。', '', '环境尺度沿用原weather-calendar/仅天气标准化与E2004—2019参考，按原W2020—2023低/高组边界分组，不重新对新队列分位切组。原源内95%距离是相对支持参照，不是严格外推边界或概率。', '', '| 原weather-calendar分组 | 方法 | n | RMSE(t/ha) | R² | MSE−Sobol | 背景技能 |', '|---|---|---:|---:|---:|---:|---:|']
    for row in headline.itertuples():
        lines.append(f'| {row.distance_bin} | {row.method} | {row.n} | {row.rmse_mean:.4f} | {row.r2_mean:.4f} | {row.mse_minus_sobol:+.4f} | {row.background_skill:.4f} |')
    lines += ['', '| 分组 | 分配集合 | 个数 | RMSE中位数 | 优于Sobol |', '|---|---|---:|---:|---:|']
    for row in pd.DataFrame(distribution).query("definition=='weather_calendar'").itertuples():
        lines.append(f'| {row.distance_bin} | {row.family} | {row.count} | {row.median_rmse:.4f} | {row.better_than_sobol}/{row.count} |')
    lines += ['', '## 环境覆盖', '', '| 定义 | 距源中位数 | 原源内95%参照 | 超过比例 | 原低／中／高组样本数 |', '|---|---:|---:|---:|---|']
    for definition, v in env.items():
        counts = np.bincount(v['binid'], minlength=3)
        lines.append(f"| {definition} | {np.median(v['distance']):.4f} | {v['source_q95']:.4f} | {(v['distance'] > v['source_q95']).mean():.4f} | {counts.tolist()} |")
    lines += ['', '## 解释范围与核验', '', '独立的是此前未用于开发的地理队列；产品、四个年份和固定2021年作物掩膜仍共享，未证明历史实时发布可用性。未在本队列重做光学/气象信息置换，所以当前确认的是旧方法和权重分配的地域表现，不能声称原信息干预机制已完整复现。', '', '全部74方法、三种子均保留，原Sobol始终作为指定参照，不选择新区域最优分配作为方法。区间为县聚类描述性区间，未覆盖全部共同年份冲击、多重比较、模型/教师训练不确定性。R²、背景技能和绝对RMSE的对象不同，不能把不同区域的原始RMSE直接作为同条件排名。权重不是物理贡献。', '', '102新瓦片摘要独立重新聚合，6471县时段值及原8+GDD一致；源全样本表示库重建与原缓存一致；新表示两次编码一致；222旧/新模型重载推断均一致；输入、模型与所有冻结依赖哈希保持一致。']
    (OUT / '地域确认报告.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')
    for path, digest in design['sha256'].items():
        assert s.sha(path) == digest, path
    files = [OUT / name for name in ['model_predictions.npz', 'evaluated_models.csv', 'predictions.csv', 'metrics.csv', 'summary.csv', 'distribution.csv', 'paired_county_intervals.csv', 'year_sensitivity.csv', 'environment_distances.csv', 'environment_rules.json', '地域确认报告.md']]
    s.save(OUT / 'evaluation_verification.json', {'verified': True, 'fingerprint': fp, 'target_model_cases': 222, 'new_training': 0, 'samples': 538, 'counties': 175, 'all_target_predictions_reloaded': True, 'source_bank_checks': encode_checks, 'input_audit_sha256': s.sha(OUT / 'input_audit.json'), 'evaluation_design_sha256': s.sha(OUT / 'evaluation_design.json'), 'dataset_sha256': s.sha(WORK / 'dataset.npz'), 'model_sha256': {path: digest for path, digest in design['sha256'].items() if path.endswith('.pt')}, 'output_sha256': {str(path): s.sha(path) for path in files}, 'code_sha256': s.sha(__file__), 'dependencies_unchanged': True, 'historical_product_release_not_certified': True})
    print(headline.to_string(index=False), flush=True)
    print('INDEPENDENT GEOGRAPHY EVALUATION VERIFIED', round(time.time() - start, 1), flush=True)
if __name__ == '__main__':
    raise SystemExit('Use scripts/train_mainline.py for mainline fitting or the saved-result analysis scripts. This historical entry is retained for method provenance, not default execution.')
