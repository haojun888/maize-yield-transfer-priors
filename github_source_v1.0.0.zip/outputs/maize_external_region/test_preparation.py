import sys as _sys
from pathlib import Path as _Path
_release_root = _Path(__file__).resolve().parents[2]
_sys.path.insert(0, str(_release_root))
from release_support import configured_path as _configured_path, prepare_transfer as _prepare_transfer
import ast, json, pathlib, unittest
import numpy as np
import pandas as pd
OUT = pathlib.Path(__file__).resolve().parent
ROOT = OUT.parents[1]

def load_function(path, name):
    tree = ast.parse(path.read_text(encoding='utf-8-sig'))
    node = next((n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == name))
    namespace = {'np': np, 'pd': pd}
    exec(compile(ast.Module(body=[node], type_ignores=[]), str(path), 'exec'), namespace)
    return namespace[name]
aggregate = load_function(ROOT / 'outputs/maize_baseline/pipeline.py', 'aggregate_chunk')
weather = load_function(ROOT / 'outputs/maize_feature_increments/prepare.py', 'weather_bins')

class TemporalContract(unittest.TestCase):

    def test_county_and_inclusive_cutoff(self):
        w = pd.DataFrame({'adm_id': ['A', 'B'], 'year': [2020, 2020], 'start': pd.to_datetime(['2020-06-01'] * 2), 'cutoff': pd.to_datetime(['2020-06-10'] * 2)})
        frame = pd.DataFrame({'adm_id': ['A', 'A', 'A', 'B'], 'date': [20200601, 20200610, 20200611, 20200605], 'prec': [2.0, 3.0, 999.0, 7.0]})
        got = aggregate(frame, w, {'prec': 'sum'}).set_index(['adm_id', 'year', 'bin'])
        self.assertEqual(got.loc[('A', 2020, 0), 'prec_sum'], 5)
        self.assertEqual(got.loc[('B', 2020, 0), 'prec_sum'], 7)
        self.assertLessEqual(got.latest.max(), 20200610)

    def test_daily_gdd_and_future_exclusion(self):
        f = pd.DataFrame({'observed_date': pd.date_range('2020-05-01', periods=12), 'tmin': [0.0] * 12, 'tmax': [40.0] * 12, 'prec': [0.0] * 12})
        got = weather(f, pd.Timestamp('2020-04-21'), pd.Timestamp('2020-05-01'), pd.Timestamp('2020-05-12'), 3)
        np.testing.assert_array_equal(got[:, 0], [0, 100, 120])
        f.loc[11, 'tmax'] = 999
        early = weather(f, pd.Timestamp('2020-04-21'), pd.Timestamp('2020-05-01'), pd.Timestamp('2020-05-10'), 2)
        np.testing.assert_array_equal(early[:, 0], got[:2, 0])

    def test_missing_day_rejected(self):
        f = pd.DataFrame({'observed_date': pd.to_datetime(['2020-05-01', '2020-05-03']), 'tmin': [10.0, 10.0], 'tmax': [20.0, 20.0], 'prec': [0.0, 0.0]})
        with self.assertRaises(ValueError):
            weather(f, pd.Timestamp('2020-05-01'), pd.Timestamp('2020-05-01'), pd.Timestamp('2020-05-03'), 1)

    def test_frozen_cohort_calendar_tasks(self):
        d = json.loads((OUT / 'design.json').read_text())
        w = pd.read_csv(OUT / 'date_windows.csv', parse_dates=['start', 'cutoff', 'sos_date', 'eos_date'])
        m = pd.read_csv(OUT / 'target_cohort_manifest.csv', dtype={'state_fips': str})
        self.assertEqual(len(m), 538)
        self.assertEqual(m.adm_id.nunique(), 175)
        self.assertEqual(set(m.state_fips), {'21', '47'})
        self.assertEqual(set(m.year), {2020, 2021, 2022, 2023})
        self.assertFalse(m.duplicated(['adm_id', 'year']).any())
        self.assertTrue(((w.sos_date - w.start).dt.days == 90).all())
        self.assertTrue(((w.eos_date - w.cutoff).dt.days == 60).all())
        self.assertTrue((w.length == (w.cutoff - w.start).dt.days // 10 + 1).all())
        for task in d['tasks']:
            start = pd.Timestamp(task['start']).tz_localize(None).normalize()
            end = pd.Timestamp(task['end']).tz_localize(None).normalize()
            wy = w[w.year == start.year]
            self.assertTrue(((wy.start <= start) & (wy.cutoff >= end)).any())
            self.assertIn(task['tile'], [[10, 5], [11, 5]])
if __name__ == '__main__':
    raise SystemExit('Use scripts/train_mainline.py for mainline fitting or the saved-result analysis scripts. This historical entry is retained for method provenance, not default execution.')
