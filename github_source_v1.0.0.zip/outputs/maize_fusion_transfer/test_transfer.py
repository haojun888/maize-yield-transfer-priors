import sys as _sys
from pathlib import Path as _Path
_release_root = _Path(__file__).resolve().parents[2]
_sys.path.insert(0, str(_release_root))
from release_support import configured_path as _configured_path, prepare_transfer as _prepare_transfer
import unittest
import numpy as np
import torch
import transfer as t

class TransferChecks(unittest.TestCase):

    def test_boundaries_and_target_label_exclusion(self):
        years = np.tile(np.arange(2004, 2024), 4)
        counties = np.repeat(['US-17-001', 'US-19-001', 'US-39-001', 'US-31-001'], 20)
        y = np.arange(80, dtype=np.float32)
        for protocol in t.PROTOCOLS:
            split = t.make_split(years, counties, protocol)
            self.assertFalse(np.any(split['train'] & split['val']))
            self.assertTrue(np.all(years[split['fit']] <= 2019))
            self.assertTrue(np.all(years[split['teacher_fit']] <= 2013))
            self.assertTrue(np.all(years[split['prior']] <= 2016))
            backgrounds = t.backgrounds(y, years, counties, split, protocol)
            changed = y.copy()
            changed[~split['fit']] += 10000
            self.assertEqual(backgrounds, t.backgrounds(changed, years, counties, split, protocol))
            if protocol != 'T':
                self.assertTrue(set(counties[split['fit']]).isdisjoint(counties[split['space']]))
                self.assertEqual(backgrounds['final_fit']['county'], {})
                self.assertTrue(np.all(years[split['joint']] >= 2020))

    def test_final_fit_ignores_nontraining_targets(self):
        torch.manual_seed(42)
        head = torch.nn.Sequential(torch.nn.Linear(16, 32), torch.nn.ReLU(), torch.nn.Dropout(0.1), torch.nn.Linear(32, 1))
        rng = np.random.default_rng(42)
        bank = rng.normal(size=(12, 7, 16)).astype(np.float32)
        y = rng.normal(size=12).astype(np.float32)
        fit = np.arange(12) < 8
        prior = np.ones(7) / 7
        model, mean, std = t.fit_final(head, 'learned', prior, 0.25, bank, y, fit, 42, 2)
        y[~fit] += 1000
        other, mean2, std2 = t.fit_final(head, 'learned', prior, 0.25, bank, y, fit, 42, 2)
        a, _ = t.s.predict(model, bank, mean, std)
        b, _ = t.s.predict(other, bank, mean2, std2)
        np.testing.assert_allclose(a, b, rtol=0, atol=1e-06)
if __name__ == '__main__':
    raise SystemExit('Use scripts/train_mainline.py for mainline fitting or the saved-result analysis scripts. This historical entry is retained for method provenance, not default execution.')
