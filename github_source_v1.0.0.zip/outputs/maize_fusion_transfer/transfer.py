import sys as _sys
from pathlib import Path as _Path
_release_root = _Path(__file__).resolve().parents[2]
_sys.path.insert(0, str(_release_root))
from release_support import configured_path as _configured_path, prepare_transfer as _prepare_transfer
'Source-only temporal/spatial fusion experiment; preserve previous experiments.'
import functools
import hashlib
import json
import sys
import time
from pathlib import Path
import numpy as np
import pandas as pd
import torch
from torch import nn
OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
sys.path.insert(0, str(ROOT / 'outputs/maize_fusion_screen'))
import screen as s
PROTOCOLS = ['T', 'E_to_W', 'W_to_E']
METHODS = ['uniform', 'sobol_fixed', 'random_fixed', 'learned', 'capacity', 'guided_sobol', 'guided_random', 'guided_uniform']

def make_split(years, counties, protocol):
    split = s.e.make_split(years, counties, protocol)
    split['teacher_fit'] = split['fit'] & (years <= 2013)
    split['teacher_val'] = split['fit'] & (years >= 2014) & (years <= 2015)
    split['prior'] = split['fit'] & (years >= 2014) & (years <= 2016)
    return split

def backgrounds(y, years, counties, split, protocol):
    kind = 'mean' if protocol == 'T' else 'trend'
    scope = 'county' if protocol == 'T' else 'source'
    return {phase: s.e.fit_background(y, years, counties, mask, kind, scope) for phase, mask in [('teacher', split['teacher_fit']), ('selection', split['train']), ('final_fit', split['fit'])]}

def fit_final(template, mode, prior, strength, bank, residual, fit, seed, epochs):
    s.g.seed_all(seed + 992)
    model = s.Fusion(template, mode, prior).to(s.DEVICE)
    s.g.seed_all(seed + 991)
    mean = float(residual[fit].mean())
    std = float(residual[fit].std())
    ds = s.TensorDataset(torch.from_numpy(bank[fit]), torch.from_numpy(((residual[fit] - mean) / std).astype(np.float32)))
    loader = s.DataLoader(ds, batch_size=512, shuffle=True, generator=torch.Generator().manual_seed(seed + 991), num_workers=0)
    optimizer = torch.optim.Adam(model.parameters(), lr=0.001, weight_decay=0.0001)
    for _ in range(epochs):
        model.train()
        for xb, yb in loader:
            optimizer.zero_grad(set_to_none=True)
            pred, w = model(xb.to(s.DEVICE), True)
            loss = nn.functional.mse_loss(pred, yb.to(s.DEVICE)) + strength * s.kl_prior(w, model.prior)
            loss.backward()
            optimizer.step()
    return (model, mean, std)

def candidate_specs():
    specs = {name: (mode, family, 0.0) for name, mode, family in [('uniform', 'uniform', 'uniform'), ('sobol_fixed', 'fixed', 'sobol'), ('random_fixed', 'fixed', 'random'), ('learned', 'learned', 'uniform'), ('capacity', 'capacity', 'uniform')]}
    specs.update({f'guided_{family}_{strength:g}': ('learned', family, strength) for family in ['sobol', 'random', 'uniform'] for strength in s.STRENGTHS})
    return specs

def method_map(choices):
    mapping = {v: v for v in METHODS[:5]}
    mapping.update({f'guided_{family}': f'guided_{family}_{choices[family]:g}' for family in ['sobol', 'random', 'uniform']})
    return mapping

def prepare():
    return _prepare_transfer(sys.modules[__name__])

def context(variant, protocol, seed, fp):
    folder = OUT / f'{variant}__{protocol}_{seed}'
    folder.mkdir(exist_ok=True)
    d = np.load(s.CACHE / f'{variant}.npz')
    split = make_split(d['years'], d['counties'], protocol)
    groups, names = s.groups_for(variant)
    backgrounds_ = json.loads((OUT / f'background_{protocol}.json').read_text())
    bg = {k: s.e.background_predict(v, d['years'], d['counties']) for k, v in backgrounds_.items()}
    residual = {k: (d['y'] - v).astype(np.float32) for k, v in bg.items()}
    seq, soil, params = s.e.prepare_arrays(d['x'], d['static'], d['lengths'], split['teacher_fit'])
    complete = folder / 'teacher_complete.json'
    if not complete.exists():
        print('TEACHER START', variant, protocol, seed, flush=True)
        s.g.Teacher = functools.partial(s.Teacher, d['x'].shape[2], groups)
        teacher, bank, ym, ys, epoch, history = s.g.train_teacher(seq, soil, d['lengths'], residual['teacher'], split['teacher_fit'], split['teacher_val'], seed)
        torch.save({'state_dict': teacher.cpu().state_dict(), 'target_mean': ym, 'target_std': ys, 'epoch': epoch, 'width': d['x'].shape[2], 'groups': groups, 'fingerprint': fp}, folder / 'teacher.pt')
        teacher = teacher.to(s.DEVICE)
        np.save(folder / 'bank.npy', bank)
        s.save(folder / 'preprocessing.json', params)
        pd.DataFrame(history).to_csv(folder / 'teacher_history.csv', index=False)
        _, _, priors = s.estimate_prior(teacher, bank, split['prior'], seed, names)
        s.save(folder / 'priors.json', priors)
        s.save(complete, {'fingerprint': fp, 'sha256': {name: s.sha(folder / name) for name in ['teacher.pt', 'bank.npy', 'preprocessing.json', 'priors.json', 'teacher_history.csv']}})
    marker = json.loads(complete.read_text())
    assert marker['fingerprint'] == fp
    for name, value in marker['sha256'].items():
        assert s.sha(folder / name) == value
    ck = torch.load(folder / 'teacher.pt', weights_only=True, map_location='cpu')
    assert ck['fingerprint'] == fp
    teacher = s.Teacher(ck['width'], ck['groups']).to(s.DEVICE)
    teacher.load_state_dict(ck['state_dict'])
    teacher.eval()
    for p in teacher.parameters():
        p.requires_grad_(False)
    bank = np.load(folder / 'bank.npy')
    prior = json.loads((folder / 'priors.json').read_text())
    weights = {'sobol': prior['prior'], 'random': prior['shuffled'], 'uniform': np.ones(len(names)) / len(names)}
    return (folder, d, split, teacher, bank, bg, residual, weights, names)

def run():
    start = time.time()
    fp = prepare()
    rows = []
    specs = candidate_specs()
    for variant in s.INPUTS:
        for protocol in PROTOCOLS:
            for seed in s.SEEDS:
                folder, d, split, teacher, bank, bg, residual, weights, names = context(variant, protocol, seed, fp)
                for candidate, (mode, family, strength) in specs.items():
                    checkpoint = folder / f'selection_{candidate}.pt'
                    meta = folder / f'selection_{candidate}.json'
                    if not (checkpoint.exists() and meta.exists()):
                        model, ym, ys, epoch, history, score = s.train(teacher.head, mode, weights[family], strength, bank, residual['selection'], split['train'], split['val'], seed)
                        torch.save({'state_dict': model.cpu().state_dict(), 'mode': mode, 'prior': [float(w) for w in weights[family]], 'strength': strength, 'target_mean': ym, 'target_std': ys, 'epoch': epoch, 'fingerprint': fp}, checkpoint)
                        s.save(meta, {'input': variant, 'protocol': protocol, 'seed': seed, 'candidate': candidate, 'family': family, 'strength': strength, 'val_rmse': score, 'epoch': epoch, 'fingerprint': fp})
                        pd.DataFrame(history).to_csv(folder / f'selection_{candidate}_history.csv', index=False)
                        print('CANDIDATE', variant, protocol, seed, candidate, score, flush=True)
                    ck = torch.load(checkpoint, weights_only=True, map_location='cpu')
                    assert ck['fingerprint'] == fp
                    row = json.loads(meta.read_text())
                    assert row['fingerprint'] == fp
                    rows.append(row)
    candidates = pd.DataFrame(rows)
    assert len(candidates) == 126
    candidates.to_csv(OUT / 'validation_candidates.csv', index=False)
    choices = {}
    for variant in s.INPUTS:
        choices[variant] = {}
        for protocol in PROTOCOLS:
            choices[variant][protocol] = {}
            for family in ['sobol', 'random', 'uniform']:
                frame = candidates[(candidates.input == variant) & (candidates.protocol == protocol) & (candidates.family == family) & (candidates.strength > 0)]
                choices[variant][protocol][family] = float(frame.groupby('strength').val_rmse.mean().sort_values().index[0])
    s.save(OUT / 'selection_complete.json', {'fingerprint': fp, 'choices': choices, 'source_candidates': 126, 'target_predictions_started': False})
    frames = []
    wframes = []
    models = 0
    for variant in s.INPUTS:
        for protocol in PROTOCOLS:
            for seed in s.SEEDS:
                folder, d, split, teacher, bank, bg, residual, weights, names = context(variant, protocol, seed, fp)
                for method, candidate in method_map(choices[variant][protocol]).items():
                    mode, family, strength = specs[candidate]
                    chosen = json.loads((folder / f'selection_{candidate}.json').read_text())
                    epoch = chosen['epoch']
                    path = folder / f'final_{method}.pt'
                    if not path.exists():
                        model, ym, ys = fit_final(teacher.head, mode, weights[family], strength, bank, residual['final_fit'], split['fit'], seed, epoch)
                        torch.save({'state_dict': model.cpu().state_dict(), 'mode': mode, 'family': family, 'prior': [float(w) for w in weights[family]], 'strength': strength, 'target_mean': ym, 'target_std': ys, 'epoch': epoch, 'candidate': candidate, 'fingerprint': fp, 'parameters': sum((p.numel() for p in model.parameters()))}, path)
                        print('FINAL', variant, protocol, seed, method, epoch, flush=True)
                    ck = torch.load(path, weights_only=True, map_location='cpu')
                    assert ck['fingerprint'] == fp and ck['candidate'] == candidate
                    model = s.Fusion(teacher.head, mode, ck['prior']).to(s.DEVICE)
                    model.load_state_dict(ck['state_dict'])
                    models += 1
                    for scenario in ['time', 'space', 'joint']:
                        if scenario not in split:
                            continue
                        mask = split[scenario]
                        pred, w = s.predict(model, bank[mask], ck['target_mean'], ck['target_std'])
                        info = {'input': variant, 'protocol': protocol, 'scenario': scenario, 'seed': seed, 'variant': method, 'candidate': candidate, 'adm_id': d['counties'][mask], 'year': d['years'][mask]}
                        frames.append(pd.DataFrame({**info, 'observed_yield_t_ha': d['y'][mask], 'predicted_yield_t_ha': pred + bg['final_fit'][mask], 'background_t_ha': bg['final_fit'][mask]}))
                        wframes.append(pd.DataFrame({**info, **{name: w[:, j] for j, name in enumerate(names)}}))
    assert models == 72 and len(frames) == 120
    pd.concat(frames, ignore_index=True).to_csv(OUT / 'predictions.csv', index=False)
    pd.concat(wframes, ignore_index=True).to_csv(OUT / 'weights.csv', index=False)
    s.save(OUT / 'run_complete.json', {'fingerprint': fp, 'teachers': 9, 'source_candidates': 126, 'final_models': models, 'scenario_predictions': len(frames), 'runtime_seconds': time.time() - start})
    print('TRANSFER TRAINING COMPLETE', time.time() - start, flush=True)
if __name__ == '__main__':
    raise SystemExit('Use scripts/train_mainline.py for mainline fitting or the saved-result analysis scripts. This historical entry is retained for method provenance, not default execution.')
