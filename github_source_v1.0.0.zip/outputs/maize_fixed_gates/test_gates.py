import sys as _sys
from pathlib import Path as _Path
_release_root = _Path(__file__).resolve().parents[2]
_sys.path.insert(0, str(_release_root))
from release_support import configured_path as _configured_path, prepare_transfer as _prepare_transfer
import unittest
import numpy as np
import gates

class GateChecks(unittest.TestCase):

    def test_sobol_additive_model_known_indices(self):
        self.assertTrue(hasattr(gates, 'sobol_indices'), 'sobol_indices missing')
        rng = np.random.default_rng(2)
        a = rng.random((30000, 5))
        b = rng.random((30000, 5))
        f = lambda x: 2 * x[:, 0] + x[:, 1]
        mixed = []
        for j in range(5):
            c = a.copy()
            c[:, j] = b[:, j]
            mixed.append(f(c))
        s1, st = gates.sobol_indices(f(a), f(b), np.array(mixed))
        np.testing.assert_allclose(st[:2], [0.8, 0.2], atol=0.025)
        np.testing.assert_allclose(st[2:], 0.0, atol=1e-12)

    def test_weights_floor_and_zero_signal(self):
        self.assertTrue(hasattr(gates, 'prior_weights'), 'prior_weights missing')
        w = gates.prior_weights(np.array([2.0, 0.0, -1.0, 0.0, 0.0]))
        self.assertAlmostEqual(w.sum(), 1.0)
        self.assertTrue((w >= 0.01).all())
        np.testing.assert_allclose(gates.prior_weights(np.zeros(5)), np.ones(5) / 5)

    def test_shuffle_preserves_weight_distribution(self):
        self.assertTrue(hasattr(gates, 'shuffle_weights'), 'shuffle_weights missing')
        w = np.array([0.4, 0.3, 0.15, 0.1, 0.05])
        p, order = gates.shuffle_weights(w, 42)
        np.testing.assert_allclose(np.sort(p), np.sort(w))
        self.assertFalse(np.array_equal(order, np.arange(5)))
        np.testing.assert_allclose(p, w[order])
if __name__ == '__main__':
    raise SystemExit('Use scripts/train_mainline.py for mainline fitting or the saved-result analysis scripts. This historical entry is retained for method provenance, not default execution.')
