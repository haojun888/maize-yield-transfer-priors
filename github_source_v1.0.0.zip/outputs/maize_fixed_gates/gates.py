import sys as _sys
from pathlib import Path as _Path
_release_root = _Path(__file__).resolve().parents[2]
_sys.path.insert(0, str(_release_root))
from release_support import configured_path as _configured_path, prepare_transfer as _prepare_transfer
'Fixed-bank gate experiment; read design.md before interpreting sensitivities.'
import copy
import hashlib
import json
import sys
import time
from pathlib import Path
import numpy as np
import pandas as pd
import torch
from torch import nn
from torch.utils.data import TensorDataset, DataLoader
OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
sys.path.insert(0, str(ROOT / 'outputs/maize_anomaly_transfer'))
import experiment as e
from train import DEVICE, seed_all
GROUP_NAMES = ['thermal', 'water', 'radiation', 'canopy', 'soil']
GROUP_INDICES = [[0, 1, 2], [3, 4, 7], [5], [6]]
VARIANTS = ['uniform', 'sobol_fixed', 'sobol_shuffled', 'conditional_fixed', 'conditional_shuffled']

def sobol_indices(fa, fb, fab):
    fa = np.asarray(fa, dtype=float)
    fb = np.asarray(fb, dtype=float)
    fab = np.asarray(fab, dtype=float)
    variance = np.var(np.concatenate([fa, fb]), ddof=1)
    if variance < 1e-12:
        return (np.zeros(len(fab)), np.zeros(len(fab)))
    center = np.mean(np.concatenate([fa, fb]))
    s1 = np.mean((fb - center)[None, :] * (fab - fa[None, :]), axis=1) / variance
    st = np.mean((fab - fa[None, :]) ** 2, axis=1) / (2 * variance)
    return (s1, st)

def prior_weights(scores):
    scores = np.maximum(np.asarray(scores, dtype=float), 0.0)
    if not np.isfinite(scores).all():
        raise ValueError('Nonfinite prior')
    return 0.95 * scores / scores.sum() + 0.05 / len(scores) if scores.sum() > 1e-12 else np.ones(len(scores)) / len(scores)

def shuffle_weights(weights, seed):
    rng = np.random.default_rng(seed)
    order = np.arange(len(weights))
    if np.allclose(weights, weights[0]):
        return (weights.copy(), order)
    for _ in range(100):
        order = rng.permutation(len(weights))
        if not np.allclose(weights[order], weights):
            return (weights[order], order)
    raise ValueError('Could not generate non-equivalent shuffled prior')

class Teacher(nn.Module):

    def __init__(self):
        super().__init__()
        self.encoders = nn.ModuleList([nn.LSTM(2 * len(idx) + 1, 16, batch_first=True) for idx in GROUP_INDICES])
        self.soil = nn.Sequential(nn.Linear(2, 16), nn.Tanh(), nn.Linear(16, 16))
        self.head = nn.Sequential(nn.Linear(16, 32), nn.ReLU(), nn.Dropout(0.1), nn.Linear(32, 1))

    def encode(self, x, soil, lengths):
        vectors = []
        for encoder, idx in zip(self.encoders, GROUP_INDICES):
            features = torch.cat([x[:, :, idx], x[:, :, [i + 8 for i in idx]], x[:, :, 16:17]], dim=2)
            packed = nn.utils.rnn.pack_padded_sequence(features, lengths.cpu(), batch_first=True, enforce_sorted=False)
            _, (hidden, _) = encoder(packed)
            vectors.append(nn.functional.normalize(hidden[-1], dim=1, eps=1e-06))
        vectors.append(nn.functional.normalize(self.soil(soil), dim=1, eps=1e-06))
        return torch.stack(vectors, dim=1)

    def forward(self, x, soil, lengths):
        return self.head(self.encode(x, soil, lengths).mean(1)).squeeze(1)

def teacher_predict(model, seq, static, lengths, mask, ym, ys):
    model.eval()
    parts = []
    with torch.no_grad():
        for ids in np.array_split(np.flatnonzero(mask), max(1, int(np.ceil(mask.sum() / 512)))):
            parts.append(model(torch.from_numpy(seq[ids]).to(DEVICE), torch.from_numpy(static[ids]).to(DEVICE), torch.from_numpy(lengths[ids])).cpu().numpy() * ys + ym)
    return np.concatenate(parts)

def train_teacher(seq, static, lengths, residual, fit, val, seed):
    seed_all(seed)
    model = Teacher().to(DEVICE)
    ym = float(residual[fit].mean())
    ys = float(residual[fit].std())
    ds = TensorDataset(torch.from_numpy(seq[fit]), torch.from_numpy(static[fit]), torch.from_numpy(lengths[fit]), torch.from_numpy(((residual[fit] - ym) / ys).astype(np.float32)))
    loader = DataLoader(ds, batch_size=256, shuffle=True, generator=torch.Generator().manual_seed(seed), num_workers=0)
    optimizer = torch.optim.Adam(model.parameters(), lr=0.001, weight_decay=0.0001)
    best = float('inf')
    state = None
    stale = 0
    history = []
    epochbest = 1
    for epoch in range(1, 61):
        model.train()
        total = 0.0
        for xb, sb, lb, yb in loader:
            optimizer.zero_grad(set_to_none=True)
            loss = nn.functional.mse_loss(model(xb.to(DEVICE), sb.to(DEVICE), lb), yb.to(DEVICE))
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()
            total += float(loss.detach().cpu()) * len(xb)
        score = e.metrics(residual[val], teacher_predict(model, seq, static, lengths, val, ym, ys))['rmse_t_ha']
        history.append({'epoch': epoch, 'train_standardized_mse': total / len(ds), 'inner_val_rmse': score})
        if score < best - 1e-05:
            best = score
            state = copy.deepcopy(model.state_dict())
            stale = 0
            epochbest = epoch
        else:
            stale += 1
        if epoch == 1 or epoch % 10 == 0:
            print('Teacher', seed, epoch, score, flush=True)
        if stale >= 8:
            break
    model.load_state_dict(state)
    model.eval()
    for p in model.parameters():
        p.requires_grad_(False)
    bank = []
    with torch.no_grad():
        for ids in np.array_split(np.arange(len(seq)), max(1, int(np.ceil(len(seq) / 512)))):
            bank.append(model.encode(torch.from_numpy(seq[ids]).to(DEVICE), torch.from_numpy(static[ids]).to(DEVICE), torch.from_numpy(lengths[ids])).cpu().numpy())
    bank = np.concatenate(bank).astype(np.float32)
    np.testing.assert_allclose(np.linalg.norm(bank, axis=2), 1.0, rtol=0.0001, atol=0.0001)
    return (model, bank, ym, ys, epochbest, history)

def bank_head_predict(head, bank, weights, ym=0.0, ys=1.0):
    head.eval()
    parts = []
    w = torch.tensor(weights, dtype=torch.float32, device=DEVICE)
    with torch.no_grad():
        for chunk in np.array_split(bank, max(1, int(np.ceil(len(bank) / 512)))):
            z = torch.from_numpy(chunk).to(DEVICE)
            parts.append(head((z * w[None, :, None]).sum(1)).squeeze(1).cpu().numpy() * ys + ym)
    return np.concatenate(parts)

def estimate_priors(model, bank, prior_mask, cal_mask, counties, residual, ym, ys, seed):
    source = bank[prior_mask]
    cal = bank[cal_mask]
    engine = torch.quasirandom.SobolEngine(10, scramble=True, seed=seed + 51)
    u = engine.draw_base2(12).numpy()
    a = np.minimum((u[:, :5] * len(source)).astype(int), len(source) - 1)
    b = np.minimum((u[:, 5:] * len(source)).astype(int), len(source) - 1)

    def evaluate(indices):
        values = source[indices, np.arange(5)[None, :]]
        return bank_head_predict(model.head, values, np.ones(5) / 5)
    fa = evaluate(a)
    fb = evaluate(b)
    mixed = []
    for j in range(5):
        ab = a.copy()
        ab[:, j] = b[:, j]
        mixed.append(evaluate(ab))
    fab = np.array(mixed)
    s1, st = sobol_indices(fa, fb, fab)
    _, small = sobol_indices(fa[:2048], fb[:2048], fab[:, :2048])
    signed = []
    repeats = []
    rng = np.random.default_rng(seed + 152)
    qcount = counties[cal_mask]
    rcount = counties[prior_mask]
    codes = {c: i for i, c in enumerate(np.unique(rcount))}
    qc = torch.tensor([codes[c] for c in qcount], device=DEVICE)
    rc = torch.tensor([codes[c] for c in rcount], device=DEVICE)
    baseline = bank_head_predict(model.head, cal, np.ones(5) / 5, ym, ys)
    baseline_loss = float(np.mean((baseline - residual[cal_mask]) ** 2))
    for j in range(5):
        other = [k for k in range(5) if k != j]
        q = torch.from_numpy(cal[:, other].reshape(len(cal), -1)).to(DEVICE)
        r = torch.from_numpy(source[:, other].reshape(len(source), -1)).to(DEVICE)
        neighbors = []
        for start in range(0, len(cal), 256):
            distance = torch.cdist(q[start:start + 256], r)
            distance.masked_fill_(qc[start:start + 256, None] == rc[None, :], float('inf'))
            values, indices = torch.topk(distance, k=min(30, len(source) - 3), largest=False)
            assert torch.isfinite(values).all()
            neighbors.append(indices.cpu().numpy())
        neighbor = np.concatenate(neighbors)
        deltas = []
        for _ in range(5):
            donor = neighbor[np.arange(len(cal)), rng.integers(0, neighbor.shape[1], len(cal))]
            swapped = cal.copy()
            swapped[:, j] = source[donor, j]
            p = bank_head_predict(model.head, swapped, np.ones(5) / 5, ym, ys)
            deltas.append(float(np.mean((p - residual[cal_mask]) ** 2) - baseline_loss))
        signed.append(float(np.mean(deltas)))
        repeats.append(deltas)
    sobol = prior_weights(st)
    conditional = prior_weights(signed)
    random_sobol, order_s = shuffle_weights(sobol, seed + 700)
    random_cond, order_c = shuffle_weights(conditional, seed + 800)
    weights = {'uniform': np.ones(5) / 5, 'sobol_fixed': sobol, 'sobol_shuffled': random_sobol, 'conditional_fixed': conditional, 'conditional_shuffled': random_cond}
    details = {'groups': GROUP_NAMES, 'source_bank_rows': len(source), 'calibration_rows_2016': len(cal), 's1_4096': s1.tolist(), 'st_4096': st.tolist(), 'st_2048': small.tolist(), 'max_st_convergence_difference': float(np.max(np.abs(st - small))), 'conditional_mse_increase': signed, 'conditional_repeats': repeats, 'conditional_baseline_mse': baseline_loss, 'shuffle_sobol': order_s.tolist(), 'shuffle_conditional': order_c.tolist(), 'weights': {k: v.tolist() for k, v in weights.items()}, 'sobol_scope': 'Independent empirical whole-group latent bank combinations; not physical/correlated-input importance'}
    return (weights, details)

def train_head(template, bank, weights, residual, fit, val, seed, epochs=60):
    seed_all(seed + 991)
    head = copy.deepcopy(template).to(DEVICE)
    for p in head.parameters():
        p.requires_grad_(True)
    z = (bank * np.asarray(weights, dtype=np.float32)[None, :, None]).sum(1)
    ym = float(residual[fit].mean())
    ys = float(residual[fit].std())
    loader = DataLoader(TensorDataset(torch.from_numpy(z[fit]), torch.from_numpy(((residual[fit] - ym) / ys).astype(np.float32))), batch_size=512, shuffle=True, generator=torch.Generator().manual_seed(seed + 991), num_workers=0)
    optimizer = torch.optim.Adam(head.parameters(), lr=0.001, weight_decay=0.0001)
    history = []
    best = float('inf')
    state = None
    stale = 0
    bestepoch = epochs
    for epoch in range(1, epochs + 1):
        head.train()
        total = 0.0
        for xb, yb in loader:
            optimizer.zero_grad(set_to_none=True)
            loss = nn.functional.mse_loss(head(xb.to(DEVICE)).squeeze(1), yb.to(DEVICE))
            loss.backward()
            optimizer.step()
            total += float(loss.detach().cpu()) * len(xb)
        row = {'epoch': epoch, 'train_mse': total / int(fit.sum())}
        if val is not None:
            p = bank_head_predict(head, bank[val], weights, ym, ys)
            score = e.metrics(residual[val], p)['rmse_t_ha']
            row['val_rmse'] = score
            if score < best - 1e-05:
                best = score
                state = copy.deepcopy(head.state_dict())
                stale = 0
                bestepoch = epoch
            else:
                stale += 1
        history.append(row)
        if val is not None and stale >= 8:
            break
    if state is not None:
        head.load_state_dict(state)
    return (head, ym, ys, bestepoch, history)

def background_choices():
    choices = {}
    for protocol in ['T', 'E_to_W', 'W_to_E']:
        scores = {}
        for kind in ['raw', 'mean', 'trend'] if protocol == 'T' else ['raw', 'trend']:
            entries = json.loads((e.BASE / 'results.json').read_text())['selection'] if protocol == 'T' and kind == 'raw' else json.loads((e.OUT / f'{protocol}__{kind}' / 'selection.json').read_text())
            scores[kind] = float(np.mean([v['rmse_t_ha'] for v in entries if v['model'] == 'LSTM']))
        choices[protocol] = {'chosen': min(scores, key=scores.get), 'source_validation_scores': scores}
    return choices

def run():
    started = time.time()
    d = np.load(e.CACHE / 'dataset.npz')
    x, soil, lengths, y, years, counties = [d[k] for k in ['x', 'static', 'lengths', 'y', 'years', 'counties']]
    choices = background_choices()
    e.save_json(OUT / 'background_choices.json', choices)
    dependencies = [Path(__file__), Path(e.__file__), e.BASE / 'train.py', e.BASE / 'pipeline.py', e.CACHE / 'dataset.npz']
    fingerprint = hashlib.sha256((''.join((hashlib.sha256(p.read_bytes()).hexdigest() for p in dependencies)) + json.dumps(choices, sort_keys=True)).encode()).hexdigest()
    frames = []
    for protocol in ['T', 'E_to_W', 'W_to_E']:
        split = e.make_split(years, counties, protocol)
        source = split['fit']
        teacherfit = source & (years <= 2013)
        teacherval = source & (years >= 2014) & (years <= 2015)
        priormask = source & (years >= 2014) & (years <= 2016)
        calmask = source & (years == 2016)
        kind = choices[protocol]['chosen']
        scope = 'county' if protocol == 'T' else 'source'
        backgrounds = {phase: e.fit_background(y, years, counties, mask, kind, scope) for phase, mask in [('teacher', teacherfit), ('selection', split['train']), ('final_fit', split['fit'])]}
        bg = {k: e.background_predict(v, years, counties) for k, v in backgrounds.items()}
        residual = {k: (y - v).astype(np.float32) for k, v in bg.items()}
        seq, st, params = e.prepare_arrays(x, soil, lengths, teacherfit)
        evals = {k: v for k, v in split.items() if k in ['time', 'space', 'joint']}
        for seed in e.SEEDS:
            folder = OUT / f'{protocol}_{seed}'
            folder.mkdir(exist_ok=True)
            done = folder / 'complete.json'
            if done.exists():
                old = json.loads(done.read_text())
                if old['fingerprint'] != fingerprint:
                    raise ValueError('Case fingerprint changed; preserve existing results before rebuilding')
                frames.append(pd.read_csv(folder / 'predictions.csv'))
                continue
            print('Training frozen common teacher', protocol, seed, 'background', kind, flush=True)
            teacher, bank, tym, tys, tepoch, history = train_teacher(seq, st, lengths, residual['teacher'], teacherfit, teacherval, seed)
            assert not any((p.requires_grad for p in teacher.parameters()))
            torch.save({'state_dict': teacher.cpu().state_dict(), 'target_mean': tym, 'target_std': tys, 'epochs': tepoch, 'seed': seed}, folder / 'teacher.pt')
            teacher = teacher.to(DEVICE)
            e.save_json(folder / 'background.json', backgrounds)
            e.save_json(folder / 'preprocessing.json', params)
            pd.DataFrame(history).to_csv(folder / 'teacher_history.csv', index=False)
            weights, details = estimate_priors(teacher, bank, priormask, calmask, counties, residual['teacher'], tym, tys, seed)
            e.save_json(folder / 'priors.json', details)
            result = []
            selections = []
            hist = []
            for variant in VARIANTS:
                head, hm, hs, bestepoch, hist1 = train_head(teacher.head, bank, weights[variant], residual['selection'], split['train'], split['val'], seed)
                vp = bank_head_predict(head, bank[split['val']], weights[variant], hm, hs) + bg['selection'][split['val']]
                selections.append({'variant': variant, 'best_epoch': bestepoch, **e.metrics(y[split['val']], vp)})
                for row in hist1:
                    row.update({'variant': variant, 'phase': 'selection'})
                hist.extend(hist1)
                del head
                head, hm, hs, _, hist2 = train_head(teacher.head, bank, weights[variant], residual['final_fit'], split['fit'], None, seed, epochs=bestepoch)
                for row in hist2:
                    row.update({'variant': variant, 'phase': 'final_fit'})
                hist.extend(hist2)
                torch.save({'state_dict': head.cpu().state_dict(), 'target_mean': hm, 'target_std': hs, 'epochs': bestepoch, 'weights': weights[variant].tolist(), 'variant': variant}, folder / f'{variant}.pt')
                head = head.to(DEVICE)
                for scenario, mask in evals.items():
                    pred = bank_head_predict(head, bank[mask], weights[variant], hm, hs) + bg['final_fit'][mask]
                    result.append(pd.DataFrame({'protocol': protocol, 'scenario': scenario, 'background_kind': kind, 'variant': variant, 'seed': seed, 'adm_id': counties[mask], 'year': years[mask], 'observed_yield_t_ha': y[mask], 'predicted_yield_t_ha': pred}))
                del head
                print('Fixed gate saved', protocol, seed, variant, 'epochs', bestepoch, flush=True)
            output = pd.concat(result, ignore_index=True)
            output.to_csv(folder / 'predictions.csv', index=False)
            pd.DataFrame(hist).to_csv(folder / 'head_history.csv', index=False)
            e.save_json(folder / 'selection.json', selections)
            e.save_json(done, {'fingerprint': fingerprint, 'teacher_fit_rows': int(teacherfit.sum()), 'teacher_val_rows': int(teacherval.sum()), 'prior_bank_rows': int(priormask.sum()), 'calibration_rows': int(calmask.sum()), 'head_fit_rows': int(split['fit'].sum()), 'background_kind': kind})
            frames.append(output)
            del teacher, bank
    pred = pd.concat(frames, ignore_index=True)
    pred.to_csv(OUT / 'all_predictions.csv', index=False)
    rows = []
    for key, group in pred.groupby(['protocol', 'scenario', 'variant', 'seed']):
        rows.append({**dict(zip(['protocol', 'scenario', 'variant', 'seed'], key)), **e.metrics(group.observed_yield_t_ha.to_numpy(), group.predicted_yield_t_ha.to_numpy())})
    metrics = pd.DataFrame(rows)
    metrics.to_csv(OUT / 'metrics.csv', index=False)
    summary = metrics.groupby(['protocol', 'scenario', 'variant']).agg(n=('n', 'first'), rmse_mean=('rmse_t_ha', 'mean'), rmse_seed_sd=('rmse_t_ha', 'std'), r2_mean=('r2', 'mean'), mae_mean=('mae_t_ha', 'mean'), bias_mean=('bias_t_ha', 'mean')).reset_index()
    summary.to_csv(OUT / 'summary.csv', index=False)
    e.save_json(OUT / 'run_complete.json', {'fingerprint': fingerprint, 'runtime_seconds': time.time() - started, 'background_choices': choices, 'teacher_count': 9, 'fixed_head_count': 45, 'no_learnable_gate': True})
    print(summary.to_string(index=False), flush=True)
if __name__ == '__main__':
    raise SystemExit('Use scripts/train_mainline.py for mainline fitting or the saved-result analysis scripts. This historical entry is retained for method provenance, not default execution.')
