import sys as _sys
from pathlib import Path as _Path
_release_root = _Path(__file__).resolve().parents[2]
_sys.path.insert(0, str(_release_root))
from release_support import configured_path as _configured_path, prepare_transfer as _prepare_transfer
'Independent CPU recomputation of stored confirmation and budget predictions.'
import hashlib
import json
from pathlib import Path
import numpy as np
import pandas as pd
OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
BUDGET = ROOT / 'outputs/maize_new_prior_budget/independent_confirmation'

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))
checked = {}

def hashes(record, fields):
    for field in fields:
        for path, expected in record[field].items():
            digest = sha(path)
            assert digest == expected, path
            checked[path] = digest

def mask_for(z, rules, definition, state, group):
    distance = z[definition]
    rule = rules[definition]
    mask = np.ones(len(z['y']), bool) if state == 'pooled' else z['states'] == state
    if group == 'low':
        mask &= distance <= rule['low_max']
    elif group == 'middle':
        mask &= (distance > rule['low_max']) & (distance < rule['high_min'])
    elif group == 'high':
        mask &= distance >= rule['high_min']
    elif group == 'source_q95_above':
        mask &= distance > rule['source_q95']
    else:
        assert group == 'overall'
    return mask

def check_tables(directory, z, rules, kind):
    metric = pd.read_csv(directory / 'metrics.csv', dtype={'state_fips': str})
    summary = pd.read_csv(directory / 'summary.csv', dtype={'state_fips': str})
    pairs = pd.read_csv(directory / 'paired_county_intervals.csv', dtype={'state_fips': str, 'seed': str})
    methods = z['methods'].tolist()
    seeds = z['seeds'].tolist()
    y = z['y'].astype(np.float64)
    p = z['predictions'].astype(np.float64)
    error = (p - y) ** 2
    for row in metric.itertuples():
        mask = mask_for(z, rules, row.definition, row.state_fips, row.distance_bin)
        mi = methods.index(row.method)
        si = seeds.index(row.seed)
        assert int(mask.sum()) == row.n
        residual = p[si, mi, mask] - y[mask]
        mse = float(np.mean(residual ** 2))
        ref = 'sobol_fixed' if kind == 'confirmation' else row.reference
        delta = float((error[si, mi, mask] - error[si, methods.index(ref), mask]).mean())
        actual_delta = row.mse_minus_sobol if kind == 'confirmation' else row.mse_minus_reference
        np.testing.assert_allclose([row.rmse_t_ha, row.mse, row.mae_t_ha, row.bias_t_ha, actual_delta], [np.sqrt(mse), mse, np.mean(np.abs(residual)), np.mean(residual), delta], atol=1e-10, rtol=1e-10)
        skill = 1 - mse / np.mean((z['background'][mask] - y[mask]) ** 2)
        np.testing.assert_allclose(row.background_skill, skill, atol=1e-10)
    for row in summary.itertuples():
        mask = mask_for(z, rules, row.definition, row.state_fips, row.distance_bin)
        mse = error[:, methods.index(row.method), mask].mean(1)
        assert row.n == int(mask.sum())
        np.testing.assert_allclose([row.rmse_mean, row.mse_mean], [np.sqrt(mse).mean(), mse.mean()], atol=1e-10)
    for row in pairs.itertuples():
        mask = mask_for(z, rules, row.definition, row.state_fips, row.distance_bin)
        ref = 'sobol_fixed' if kind == 'confirmation' else row.reference
        values = error[:, methods.index(row.method), mask] - error[:, methods.index(ref), mask]
        if kind == 'confirmation':
            delta = values.mean(0)
            rngseed = 20261011
        else:
            delta = values.mean(0) if row.seed == 'seed_mean' else values[seeds.index(int(row.seed))]
            rngseed = 20261012
        unique, inverse = np.unique(z['counties'][mask], return_inverse=True)
        sums = np.bincount(inverse, weights=delta)
        count = np.bincount(inverse)
        draws = np.random.default_rng(rngseed).integers(0, len(unique), (2000, len(unique)))
        interval = np.quantile(sums[draws].sum(1) / count[draws].sum(1), [0.025, 0.975])
        if kind == 'confirmation':
            actual = [row.mse_minus_sobol, row.county_bootstrap_low, row.county_bootstrap_high]
        else:
            actual = [row.mse_method_minus_reference, row.county_ci_low, row.county_ci_high]
        np.testing.assert_allclose(actual, [delta.mean(), *interval], atol=1e-10)
    return {'metric_rows': len(metric), 'summary_rows': len(summary), 'paired_interval_rows': len(pairs)}

def run():
    hashes(read(OUT / 'model_protocol.json'), ['sha256'])
    hashes(read(OUT / 'evaluation_manifest.json'), ['sha256'])
    hashes(read(OUT / 'evaluation_verification.json'), ['model_sha256', 'output_sha256'])
    hashes(read(ROOT / 'outputs/maize_new_prior_budget/source_manifest.json'), ['sha256'])
    hashes(read(ROOT / 'outputs/maize_new_prior_budget/training_verification.json'), ['artifacts_sha256', 'model_sha256'])
    hashes(read(BUDGET / 'evaluation_manifest.json'), ['sha256', 'source_final_heads'])
    hashes(read(BUDGET / 'evaluation_verification.json'), ['output_sha256'])
    z = np.load(OUT / 'model_predictions.npz')
    raw = np.load(ROOT / 'work/maize_independent_confirmation/dataset.npz')
    for key in ['y', 'years', 'counties']:
        np.testing.assert_array_equal(z[key], raw[key])
    assert len(z['y']) == 342 and len(set(z['counties'])) == 120
    for name in ['maize_fusion_screen/gdd_evi.npz', 'maize_external_region/dataset.npz', 'maize_high_weather_transfer/dataset.npz']:
        old = np.load(ROOT / 'work' / name)
        assert not set(old['counties']) & set(z['counties'])
    rule = read(OUT / 'distance_rules.json')
    count = check_tables(OUT, z, rule, 'confirmation')
    pairs = pd.read_csv(OUT / 'paired_fixed_vs_learning.csv', dtype={'state_fips': str})
    error = (z['predictions'].astype(np.float64) - z['y'].astype(np.float64)) ** 2
    for row in pairs.itertuples():
        mask = mask_for(z, rule, row.definition, row.state_fips, row.distance_bin)
        delta = (error[:, z['methods'].tolist().index(row.method), mask] - error[:, z['methods'].tolist().index(row.reference), mask]).mean(0)
        unique, inverse = np.unique(z['counties'][mask], return_inverse=True)
        sums = np.bincount(inverse, weights=delta)
        counts = np.bincount(inverse)
        draws = np.random.default_rng(20261012).integers(0, len(unique), (2000, len(unique)))
        interval = np.quantile(sums[draws].sum(1) / counts[draws].sum(1), [0.025, 0.975])
        np.testing.assert_allclose([row.mse_method_minus_reference, row.county_ci_low, row.county_ci_high], [delta.mean(), *interval], atol=1e-10)
    years = pd.read_csv(OUT / 'year_sensitivity.csv', dtype={'state_fips': str})
    for row in years.itertuples():
        mask = mask_for(z, rule, row.definition, row.state_fips, row.distance_bin) & (z['years'] == row.year)
        mse = error[:, z['methods'].tolist().index(row.method), mask].mean(1)
        np.testing.assert_allclose(row.rmse_mean, np.sqrt(mse).mean(), atol=1e-10)
    budget = np.load(BUDGET / 'predictions_Independent342.npz')
    for key in ['y', 'years', 'counties', 'states', 'background', 'weather_only', 'weather_calendar']:
        np.testing.assert_array_equal(budget[key], z[key])
    for ref in ['source_permutation_fixed', 'sobol_square']:
        np.testing.assert_array_equal(budget['predictions'][:, budget['methods'].tolist().index(ref)], z['predictions'][:, z['methods'].tolist().index(ref)])
    budget_count = check_tables(BUDGET, budget, read(BUDGET / 'distance_rules.json'), 'budget')
    valid = np.arange(raw['x'].shape[1])[None, :] < raw['lengths'][:, None]
    ndvi = (np.isfinite(raw['x'][:, :, 6]) & valid).sum(1) / raw['lengths']
    evi = (np.isfinite(raw['x'][:, :, 9]) & valid).sum(1) / raw['lengths']
    quality = []
    sensitivity = []
    for state in ['pooled'] + sorted(set(z['states'])):
        for label in ['overall', 'high']:
            mask = mask_for(z, rule, 'weather_only', state, label)
            quality.append({'state_fips': state, 'distance_bin': label, 'n': int(mask.sum()), 'ndvi_valid_fraction': ndvi[mask].mean(), 'evi_valid_fraction': evi[mask].mean()})
            if state == 'pooled':
                continue
            for year in [2020, 2021, 2022, 2023]:
                subset = mask & (z['years'] == year)
                if not subset.any():
                    continue
                sq = (budget['predictions'][:, :, subset].astype(float) - budget['y'][subset]) ** 2
                for method in budget['methods'].tolist()[2:]:
                    ref = method.split('__')[0]
                    sensitivity.append({'state_fips': state, 'year': year, 'distance_bin': label, 'method': method, 'reference': ref, 'n': int(subset.sum()), 'evi_valid_fraction': evi[subset].mean(), 'mse_method_minus_reference': (sq[:, budget['methods'].tolist().index(method)] - sq[:, budget['methods'].tolist().index(ref)]).mean()})
    pd.DataFrame(quality).to_csv(OUT / 'optical_observation_coverage.csv', index=False)
    pd.DataFrame(sensitivity).to_csv(BUDGET / 'state_year_paired_sensitivity.csv', index=False)
    comparisons = pd.read_csv(OUT / 'paired_strong_vs_fixed.csv', dtype={'state_fips': str})
    for cohort, frame in comparisons.groupby('cohort'):
        path = OUT / 'model_predictions.npz' if cohort == 'SCOKMS' else ROOT / f'outputs/maize_fixed_prior_extension/predictions_{cohort}.npz'
        fixed = np.load(path)
        strong = np.load(ROOT / f'outputs/maize_main_strong_baselines/predictions_{cohort}.npz')
        temporary = {k: strong[k] for k in ['y', 'years', 'counties', 'weather_only', 'weather_calendar']}
        temporary['states'] = np.array([str(c).split('-')[1] for c in strong['counties']])
        for row in frame.itertuples():
            mask = mask_for(temporary, rule, row.definition, row.state_fips, row.distance_bin)
            truth = strong['y'][mask].astype(float)
            fsq = (fixed['predictions'][:, fixed['methods'].tolist().index(row.fixed_method), mask].astype(float) - truth) ** 2
            bsq = (strong['predictions'][:, strong['methods'].tolist().index(row.baseline), mask].astype(float) - truth) ** 2
            delta = (bsq - fsq).mean(0)
            unique, inverse = np.unique(strong['counties'][mask], return_inverse=True)
            sums = np.bincount(inverse, weights=delta)
            counts = np.bincount(inverse)
            draws = np.random.default_rng(20261012).integers(0, len(unique), (2000, len(unique)))
            interval = np.quantile(sums[draws].sum(1) / counts[draws].sum(1), [0.025, 0.975])
            np.testing.assert_allclose([row.mse_baseline_minus_fixed, row.county_ci_low, row.county_ci_high], [delta.mean(), *interval], atol=1e-10)
    result = {'verified': True, 'no_training_or_inference': True, 'fresh_unique_hash_checks': len(checked), 'confirmation': count, 'fixed_vs_learning_intervals': len(pairs), 'year_rows': len(years), 'new_budget': budget_count, 'new_budget_references_exact': True, 'strong_comparison_intervals': len(comparisons), 'no_source_or_previous_target_overlap': True, 'script_sha256': sha(__file__), 'checked_files_sha256': checked, 'new_auxiliary_sha256': {str(OUT / 'optical_observation_coverage.csv'): sha(OUT / 'optical_observation_coverage.csv'), str(BUDGET / 'state_year_paired_sensitivity.csv'): sha(BUDGET / 'state_year_paired_sensitivity.csv')}}
    (OUT / 'independent_result_audit.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps({k: v for k, v in result.items() if k not in ['checked_files_sha256', 'new_auxiliary_sha256']}, ensure_ascii=False))
if __name__ == '__main__':
    raise SystemExit('Use scripts/train_mainline.py for mainline fitting or the saved-result analysis scripts. This historical entry is retained for method provenance, not default execution.')
