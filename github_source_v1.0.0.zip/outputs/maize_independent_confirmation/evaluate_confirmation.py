import sys as _sys
from pathlib import Path as _Path
_release_root = _Path(__file__).resolve().parents[2]
_sys.path.insert(0, str(_release_root))
from release_support import configured_path as _configured_path, prepare_transfer as _prepare_transfer
'First frozen evaluation of all three remaining covariate-eligible states.'
import sys
import time
from pathlib import Path
import numpy as np
import pandas as pd
import torch
import confirmation as q
OUT, ROOT, WORK = (q.OUT, q.ROOT, q.WORK)
x, h, s, t = (q.x, q.h, q.s, q.t)
sha, read, save = (q.sha, q.read, q.save)

def check_screen_distance(saved, current, low, high):
    saved = np.asarray(saved)
    current = np.asarray(current)
    np.testing.assert_allclose(saved, current, atol=2e-06, rtol=2e-06)
    np.testing.assert_array_equal(saved >= high, current >= high)
    np.testing.assert_array_equal(saved <= low, current <= low)

def lock_evaluation():
    model = read(OUT / 'model_protocol.json')
    for path, digest in model['sha256'].items():
        assert sha(path) == digest, path
    assert read(OUT / 'independent_input_verification.json')['verified']
    files = [Path(__file__), OUT / 'verify_confirmation.py', OUT / 'test_evaluation.py', WORK / 'dataset.npz', OUT / 'date_windows.csv', OUT / 'target_cohort_manifest.csv', OUT / 'verification.json', OUT / 'independent_input_verification.json', OUT / 'design.json', OUT / 'selection_manifest.json', OUT / 'model_protocol.json']
    record = {'methods': q.METHODS, 'seeds': x.SEEDS, 'model_protocol_sha256': sha(OUT / 'model_protocol.json'), 'sha256': {str(p): sha(p) for p in files}, 'no_new_training': True, 'no_target_fitting': True, 'first_predictions_for_these_states': True, 'whole_cohort_retained': True, 'model_choice_not_target_based': True}
    file = OUT / 'evaluation_manifest.json'
    if file.exists():
        assert read(file) == record
    else:
        save(file, record)
    return record

def run():
    start = time.time()
    manifest = lock_evaluation()
    data = np.load(WORK / 'dataset.npz')
    cohort = pd.read_csv(OUT / 'target_cohort_manifest.csv', dtype={'adm_id': str, 'state_fips': str})
    windows = pd.read_csv(OUT / 'date_windows.csv', parse_dates=['start', 'cutoff', 'sos_date', 'eos_date'], dtype={'adm_id': str})
    np.testing.assert_array_equal(data['counties'], cohort.adm_id)
    np.testing.assert_array_equal(data['years'], cohort.year)
    np.testing.assert_allclose(data['y'], cohort['yield'], atol=2e-06)
    assert len(cohort) == 342 and set(cohort.state_fips) == {'45', '40', '28'}
    h.OUT = OUT
    h.METHODS = q.METHODS
    h.PRIMARY = q.METHODS
    environment = h.descriptors(data, windows)
    screening = pd.read_csv(OUT / 'weather_distances.csv', dtype={'adm_id': str, 'state_fips': str})
    screening = screening[screening.state_fips.isin(['45', '40', '28'])].sort_values(['adm_id', 'year'])
    np.testing.assert_array_equal(screening.adm_id, data['counties'])
    np.testing.assert_array_equal(screening.year, data['years'])
    rule = environment['weather_only']
    check_screen_distance(screening.weather_distance, rule['distance'], rule['low_max'], rule['high_min'])
    cached_weather = np.load(ROOT / 'work/maize_high_weather_transfer/screen_weather.npz')
    lookup = {(c, int(y)): j for j, (c, y) in enumerate(zip(cached_weather['counties'], cached_weather['years']))}
    source_rows = [lookup[c, int(y)] for c, y in zip(data['counties'], data['years'])]
    columns = [0, 1, 2, 3, 4, 5, 7]
    np.testing.assert_array_equal(data['x'][:, :, columns], cached_weather['x'][source_rows, :data['x'].shape[1]][:, :, columns])
    save(OUT / 'screen_distance_precision.json', {'verified': True, 'weather_inputs_exact': True, 'groups_exact': True, 'maximum_distance_roundoff': float(np.max(np.abs(screening.weather_distance.to_numpy() - rule['distance']))), 'input_cache_sha256': sha(ROOT / 'work/maize_high_weather_transfer/screen_weather.npz'), 'thresholds_unchanged': True, 'no_target_predictions_before_correction': True})
    assert (environment['weather_only']['bins'] == 2).sum() == 241
    background = s.e.background_predict(read(t.OUT / 'background_E_to_W.json')['final_fit'], data['years'], data['counties'])
    sys.path.insert(0, str(x.i.GAIN))
    import controls as c
    all_predictions = []
    all_weights = []
    models = {}
    bank_checks = []
    for seed in x.SEEDS:
        original, split, teacher, bank, residual, teacher_ck = x.source_context(seed)
        params = read(t.OUT / f'gdd_evi__E_to_W_{seed}/preprocessing.json')
        target = h.encode(teacher, data, params)
        np.testing.assert_allclose(target, h.encode(teacher, data, params), atol=2e-06, rtol=2e-06)
        np.save(WORK / f'bank_E_{seed}.npy', target)
        values = []
        weights = []
        for method, (path, mode, prior, ck) in q.specifications(seed).items():
            model = c.factory(teacher.head, mode, prior).to(s.DEVICE)
            model.load_state_dict(ck['state_dict'])
            assert sum((p.numel() for p in model.parameters())) == ck['parameters']
            value, w = s.predict(model, target, ck['target_mean'], ck['target_std'])
            again = c.factory(teacher.head, mode, prior).to(s.DEVICE)
            again.load_state_dict(torch.load(path, map_location='cpu', weights_only=True)['state_dict'])
            repeated, rw = s.predict(again, target, ck['target_mean'], ck['target_std'])
            np.testing.assert_allclose(value, repeated, atol=2e-06, rtol=2e-06)
            np.testing.assert_allclose(w, rw, atol=2e-06)
            values.append(value + background)
            weights.append(w)
            models[str(path)] = sha(path)
        all_predictions.append(values)
        all_weights.append(weights)
        bank_checks.append({'seed': seed, 'target_bank_sha256': sha(WORK / f'bank_E_{seed}.npy')})
        print('FIRST_CONFIRMATION_MODELS_VERIFIED', seed, len(values), len(data['y']), flush=True)
    predictions = np.array(all_predictions, dtype=np.float32)
    weights = np.array(all_weights, dtype=np.float32)
    assert predictions.shape == (3, 8, 342) and np.isfinite(predictions).all()
    np.savez_compressed(OUT / 'model_predictions.npz', predictions=predictions, weights=weights, methods=np.array(q.METHODS), seeds=np.array(x.SEEDS), y=data['y'], years=data['years'], counties=data['counties'], states=cohort.state_fips.to_numpy(dtype=str), background=background, weather_only=environment['weather_only']['distance'], weather_calendar=environment['weather_calendar']['distance'], weather_bins=environment['weather_only']['bins'], calendar_bins=environment['weather_calendar']['bins'])
    summary = h.summarize(data, cohort, predictions, background, environment)
    for path, digest in manifest['sha256'].items():
        assert sha(path) == digest, path
    for path, digest in read(OUT / 'model_protocol.json')['sha256'].items():
        assert sha(path) == digest, path
    files = [p for p in OUT.iterdir() if p.is_file() and p.suffix in {'.npz', '.csv'}]
    files.append(OUT / 'distance_rules.json')
    save(OUT / 'evaluation_verification.json', {'verified': True, 'samples': 342, 'counties': 120, 'weather_high_samples': 241, 'weather_high_counties': 102, 'states': ['45', '40', '28'], 'target_model_cases': 24, 'new_training': 0, 'source_bank_checks': bank_checks, 'model_sha256': models, 'output_sha256': {str(p): sha(p) for p in files}, 'evaluation_manifest_sha256': sha(OUT / 'evaluation_manifest.json'), 'dependencies_unchanged': True, 'no_target_fitting': True, 'runtime_seconds': time.time() - start})
    headline = summary[(summary.definition == 'weather_only') & summary.distance_bin.isin(['overall', 'high'])]
    print(headline.to_string(index=False), flush=True)
    print('INDEPENDENT_CONFIRMATION_EVALUATION_COMPLETE', round(time.time() - start, 1), flush=True)
if __name__ == '__main__':
    raise SystemExit('Use scripts/train_mainline.py for mainline fitting or the saved-result analysis scripts. This historical entry is retained for method provenance, not default execution.')
