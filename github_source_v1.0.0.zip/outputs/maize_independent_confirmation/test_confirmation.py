import sys as _sys
from pathlib import Path as _Path
_release_root = _Path(__file__).resolve().parents[2]
_sys.path.insert(0, str(_release_root))
from release_support import configured_path as _configured_path, prepare_transfer as _prepare_transfer
import unittest
import pandas as pd
from confirmation import remaining_states

class ConfirmationRules(unittest.TestCase):

    def test_all_unpredicted_eligible_states_retained(self):
        states = pd.DataFrame({'state_fips': ['48', '13', '45', '40', '28', '37'], 'eligible': [True, True, True, True, True, False], 'distance_median': [2.35, 0.945, 0.943, 0.881, 0.493, 0.444], 'high_n': [201, 169, 95, 64, 82, 137]})
        self.assertEqual(remaining_states(states, {'48', '13'}), ['45', '40', '28'])
        shuffled = states.sample(frac=1, random_state=42)
        self.assertEqual(remaining_states(shuffled, {'48', '13'}), ['45', '40', '28'])
        self.assertEqual(remaining_states(states, set(states.state_fips)), [])
if __name__ == '__main__':
    raise SystemExit('Use scripts/train_mainline.py for mainline fitting or the saved-result analysis scripts. This historical entry is retained for method provenance, not default execution.')
