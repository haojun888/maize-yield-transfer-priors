import sys as _sys
from pathlib import Path as _Path
_release_root = _Path(__file__).resolve().parents[2]
_sys.path.insert(0, str(_release_root))
from release_support import configured_path as _configured_path, prepare_transfer as _prepare_transfer
'Paired fixed-prior versus strong-baseline checks from already saved arrays.'
import json
from pathlib import Path
import numpy as np
import pandas as pd
OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]

def run():
    rules = json.loads((ROOT / 'outputs/maize_fixed_prior_extension/distance_rules.json').read_text(encoding='utf-8'))
    rows = []
    headlines = []
    for cohort in ['W_space', 'W_joint', 'KYTN', 'TXGA', 'SCOKMS']:
        path = OUT / 'model_predictions.npz' if cohort == 'SCOKMS' else ROOT / f'outputs/maize_fixed_prior_extension/predictions_{cohort}.npz'
        fixed = np.load(path)
        strong = np.load(ROOT / f'outputs/maize_main_strong_baselines/predictions_{cohort}.npz')
        for key in ['y', 'years', 'counties']:
            np.testing.assert_array_equal(fixed[key], strong[key])
        states = np.array([str(c).split('-')[1] for c in fixed['counties']])
        y = fixed['y'].astype(np.float64)
        for definition, rule in rules.items():
            for state in ['pooled'] + sorted(set(states)):
                sm = np.ones(len(y), bool) if state == 'pooled' else states == state
                for label, mask in [('overall', sm), ('high', sm & (strong[definition] >= rule['high_min']))]:
                    if not mask.any():
                        continue
                    ferror = (fixed['predictions'][:, :, mask].astype(np.float64) - y[mask]) ** 2
                    berror = (strong['predictions'][:, :, mask].astype(np.float64) - y[mask]) ** 2
                    for methods, errors in [(fixed['methods'].tolist(), ferror), (strong['methods'].tolist(), berror)]:
                        for mi, method in enumerate(methods):
                            if method not in ['uniform', 'sobol_fixed', 'learned', 'guided_sobol', 'source_permutation_fixed', 'sobol_sqrt', 'sobol_square', 'sobol_uniform_half', 'RF_stats', 'HGB_stats', 'LSTM32_reused']:
                                continue
                            headlines.append({'cohort': cohort, 'definition': definition, 'state_fips': state, 'distance_bin': label, 'method': method, 'n': int(mask.sum()), 'rmse_mean': np.sqrt(errors[:, mi].mean(1)).mean()})
                    unique, inverse = np.unique(fixed['counties'][mask], return_inverse=True)
                    count = np.bincount(inverse)
                    draw = np.random.default_rng(20261012).integers(0, len(unique), (2000, len(unique)))
                    for method in ['sobol_fixed', 'source_permutation_fixed', 'sobol_square']:
                        for baseline in strong['methods'].tolist():
                            delta = (berror[:, strong['methods'].tolist().index(baseline)] - ferror[:, fixed['methods'].tolist().index(method)]).mean(0)
                            sums = np.bincount(inverse, weights=delta)
                            boot = sums[draw].sum(1) / count[draw].sum(1)
                            low, high = np.quantile(boot, [0.025, 0.975])
                            rows.append({'cohort': cohort, 'definition': definition, 'state_fips': state, 'distance_bin': label, 'fixed_method': method, 'baseline': baseline, 'n': int(mask.sum()), 'counties': len(unique), 'mse_baseline_minus_fixed': delta.mean(), 'county_ci_low': low, 'county_ci_high': high})
    pd.DataFrame(rows).to_csv(OUT / 'paired_strong_vs_fixed.csv', index=False)
    pd.DataFrame(headlines).to_csv(OUT / 'integrated_rmse.csv', index=False)
    table = pd.DataFrame(rows)
    print(table[(table.definition == 'weather_only') & (table.state_fips == 'pooled') & (table.distance_bin == 'high') & (table.baseline == 'HGB_stats')].to_string(index=False))
if __name__ == '__main__':
    raise SystemExit('Use scripts/train_mainline.py for mainline fitting or the saved-result analysis scripts. This historical entry is retained for method provenance, not default execution.')
