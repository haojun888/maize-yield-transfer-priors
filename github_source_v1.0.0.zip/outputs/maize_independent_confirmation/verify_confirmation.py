import sys as _sys
from pathlib import Path as _Path
_release_root = _Path(__file__).resolve().parents[2]
_sys.path.insert(0, str(_release_root))
from release_support import configured_path as _configured_path, prepare_transfer as _prepare_transfer
'Reuse full independent tile-to-input audit, adapting only declared cohort rule.'
import ast
import hashlib
import json
import pathlib
import zipfile
import numpy as np
import pandas as pd
OUT = pathlib.Path(__file__).resolve().parent
ROOT = OUT.parents[1]
WORK = ROOT / 'work/maize_independent_confirmation'
PARENT = ROOT / 'outputs/maize_high_weather_transfer'

def sha(p):
    return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()

def run():
    protocol = json.loads((OUT / 'model_protocol.json').read_text(encoding='utf-8'))
    for path, digest in protocol['sha256'].items():
        assert sha(path) == digest, path
    original = PARENT / 'verify_inputs.py'
    assert sha(original) == protocol['sha256'][str(original)]
    text = original.read_text(encoding='utf-8')
    text = text.replace('.read_text()', ".read_text(encoding='utf-8')")
    assert text.count('eligible.head(2).state_fips.tolist()') == 1
    text = text.replace('eligible.head(2).state_fips.tolist()', "eligible[~eligible.state_fips.isin(['48','13'])].state_fips.tolist()")
    text = text.replace("codefiles=['prepare.py','resume_prepare.py','verify_inputs.py','test_preparation.py']", "codefiles=['confirmation.py','verify_confirmation.py','evaluate_confirmation.py','test_confirmation.py']")
    text = text.replace("'acquisition_sensor_correction.json'", "'sensor_policy.json'")
    tree = ast.parse(text)
    audit = next((node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == 'run'))
    namespace = dict(globals())
    exec(compile(ast.Module(body=[audit], type_ignores=[]), str(original), 'exec'), namespace)
    namespace['run']()
    result = json.loads((OUT / 'independent_input_verification.json').read_text(encoding='utf-8'))
    result.update({'original_audit_sha256': sha(original), 'all_remaining_eligible_states': True, 'no_new_state_selection_or_thresholds': True, 'states': ['45', '40', '28']})
    assert result['samples'] == 342 and result['counties'] == 120 and (result['high_samples'] == 241) and (result['high_counties'] == 102)
    (OUT / 'independent_input_verification.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    print('INDEPENDENT_CONFIRMATION_INPUTS_VERIFIED', flush=True)
if __name__ == '__main__':
    raise SystemExit('Use scripts/train_mainline.py for mainline fitting or the saved-result analysis scripts. This historical entry is retained for method provenance, not default execution.')
