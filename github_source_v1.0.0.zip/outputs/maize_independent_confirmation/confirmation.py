import sys as _sys
from pathlib import Path as _Path
_release_root = _Path(__file__).resolve().parents[2]
_sys.path.insert(0, str(_release_root))
from release_support import configured_path as _configured_path, prepare_transfer as _prepare_transfer
'All remaining covariate-eligible states, with source models locked first.'
import importlib.util
import json
import sys
from pathlib import Path
import numpy as np
import pandas as pd
import torch
OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
WORK = ROOT / 'work/maize_independent_confirmation'
PARENT = ROOT / 'outputs/maize_high_weather_transfer'
sys.path.insert(0, str(ROOT / 'outputs/maize_fixed_prior_extension'))
import extension as x
h = x.h
s = x.s
t = x.t
sha, read, save = (x.sha, x.read, x.save)
METHODS = ['uniform', 'sobol_fixed', 'learned', 'guided_sobol'] + x.NEW

def remaining_states(states, predicted):
    eligible = states[states.eligible & ~states.state_fips.isin(predicted)]
    return eligible.sort_values(['distance_median', 'high_n', 'state_fips'], ascending=[False, False, True]).state_fips.tolist()

def specifications(seed):
    result = {}
    for method in METHODS:
        folder = x.OUT / str(seed) if method in x.NEW else t.OUT / f'gdd_evi__E_to_W_{seed}'
        path = folder / f'final_{method}.pt'
        ck = torch.load(path, map_location='cpu', weights_only=True)
        if method == 'guided_sobol':
            assert ck['strength'] == 0.25
        result[method] = (path, ck['mode'], np.array(ck['prior']), ck)
    return result

def lock_models():
    x.lock()
    training = read(x.OUT / 'training_verification.json')
    for file, digest in training['model_sha256'].items():
        assert sha(file) == digest
    hashes = {str(Path(__file__)): sha(__file__), str(OUT / 'test_confirmation.py'): sha(OUT / 'test_confirmation.py'), str(ROOT / 'outputs/主线补强协议_2026-10-12.md'): sha(ROOT / 'outputs/主线补强协议_2026-10-12.md')}
    rows = []
    for seed in x.SEEDS:
        for method, (path, mode, prior, ck) in specifications(seed).items():
            hashes[str(path)] = sha(path)
            rows.append({'seed': seed, 'method': method, 'checkpoint': str(path), 'prior': prior.tolist(), 'mode': mode, 'epoch': ck['epoch'], 'parameters': ck['parameters']})
        folder = t.OUT / f'gdd_evi__E_to_W_{seed}'
        for name in ['teacher.pt', 'bank.npy', 'preprocessing.json', 'priors.json', 'teacher_complete.json']:
            hashes[str(folder / name)] = sha(folder / name)
    for file in ['screening_states.csv', 'screening_distances.csv', 'screen_windows.csv', 'selection.json', 'design.json', 'prepare.py', 'verify_inputs.py']:
        hashes[str(PARENT / file)] = sha(PARENT / file)
    hashes[str(t.OUT / 'background_E_to_W.json')] = sha(t.OUT / 'background_E_to_W.json')
    record = {'methods': METHODS, 'seeds': x.SEEDS, 'models': rows, 'sha256': hashes, 'new_training': 0, 'no_target_fitting': True, 'locked_before_selected_outcomes_and_EVI': True, 'primary_distance': 'weather_only', 'comparison': 'all eight methods retained, no target model selection'}
    file = OUT / 'model_protocol.json'
    if file.exists():
        assert read(file) == record
    else:
        save(file, record)
    return record

def prepare():
    lock_models()
    WORK.mkdir(exist_ok=True, parents=True)
    spec = importlib.util.spec_from_file_location('frozen_screen_preparation', PARENT / 'prepare.py')
    p = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(p)
    p.OUT = OUT
    p.WORK = WORK
    states = pd.read_csv(PARENT / 'screening_states.csv', dtype={'state_fips': str})
    previous = set(read(PARENT / 'selection.json')['selected_states'])
    chosen = remaining_states(states, previous)
    assert chosen == ['45', '40', '28']
    design = read(PARENT / 'design.json')
    design.update({'policy_version': 2, 'maximum_states': None, 'excluded_state_fips': sorted(set(design['excluded_state_fips']) | previous), 'selection_rule': 'all previously covariate-eligible states not predicted in earlier cohort; no further ranking exclusion', 'previously_predicted_states': sorted(previous), 'selected_states': chosen, 'model_protocol_sha256': sha(OUT / 'model_protocol.json'), 'no_target_training': True})
    for file in [Path(__file__), OUT / 'test_confirmation.py', ROOT / 'outputs/主线补强协议_2026-10-12.md', PARENT / 'screening_states.csv', PARENT / 'screening_distances.csv', PARENT / 'screen_windows.csv', PARENT / 'selection.json']:
        design['dependencies'][str(file.relative_to(ROOT))] = sha(file)
    for file in ['design.json', 'screening_policy.json']:
        if (OUT / file).exists():
            assert read(OUT / file) == design
        else:
            save(OUT / file, design)
    for source, target in [('screening_states.csv', 'state_screening.csv'), ('screening_distances.csv', 'weather_distances.csv')]:
        sourcefile = PARENT / source
        targetfile = OUT / target
        if targetfile.exists():
            assert sha(targetfile) == sha(sourcefile)
        else:
            targetfile.write_bytes(sourcefile.read_bytes())
    selection = {'selected_states': chosen, 'policy_sha256': sha(OUT / 'design.json'), 'screening_sha256': sha(OUT / 'state_screening.csv'), 'distances_sha256': sha(OUT / 'weather_distances.csv'), 'reference_n': 6007, 'selection_outcome_blind': True, 'prediction_access': False, 'all_remaining_eligible_retained': True, 'model_protocol_sha256': sha(OUT / 'model_protocol.json')}
    file = OUT / 'selection_manifest.json'
    if file.exists():
        assert read(file) == selection
    else:
        save(file, selection)
    metadata = pd.read_csv(PARENT / 'screen_windows.csv', dtype={'state_fips': str})
    metadata = metadata[metadata.state_fips.isin(chosen)].sort_values(['adm_id', 'year']).reset_index(drop=True)
    assert len(metadata) == 342 and metadata.adm_id.nunique() == 120 and ('yield' not in metadata)
    metadata.to_csv(OUT / 'selected_metadata_before_outcome.csv', index=False)
    outcome = pd.read_csv(ROOT / 'outputs/maize_data_audit/candidate_labels_2004_2023.csv', usecols=['adm_id', 'harvest_year', 'yield']).rename(columns={'harvest_year': 'year'})
    selected = metadata.merge(outcome, on=['adm_id', 'year'], validate='one_to_one')
    assert (selected['yield'] > 0).all()
    for file in ['target_cohort_manifest.csv', 'date_windows.csv']:
        selected.to_csv(OUT / file, index=False)
    for name in ['start', 'cutoff', 'sos_date', 'eos_date']:
        selected[name] = pd.to_datetime(selected[name])
    inventory = p.inventory

    def terra_only(w):
        items = [item for item in inventory(w) if item['id'].startswith('MOD13Q1.')]
        assert items and all((item['id'].startswith('MOD13Q1.') for item in items))
        print('TERRA_TASKS', len(items), flush=True)
        return items
    p.inventory = terra_only
    save(OUT / 'sensor_policy.json', {'sensor': 'Terra MOD13Q1 only', 'same_QA_and_coverage_as_original': True, 'excluded_Aqua_before_acquisition': True, 'model_protocol_sha256': sha(OUT / 'model_protocol.json')})
    print('CONFIRMATION_COHORT_LOCKED', chosen, len(selected), 'high', 241, flush=True)
    if (OUT / 'verification.json').exists():
        verified = read(OUT / 'verification.json')
        assert verified['verified'] and sha(WORK / 'dataset.npz') == verified['dataset_sha256']
        print('DATASET_ALREADY_VERIFIED_NO_REEXTRACTION', flush=True)
        return
    p.acquire(selected, design)
    for path, digest in read(OUT / 'model_protocol.json')['sha256'].items():
        assert sha(path) == digest
if __name__ == '__main__':
    raise SystemExit('Use scripts/train_mainline.py for mainline fitting or the saved-result analysis scripts. This historical entry is retained for method provenance, not default execution.')
