import sys as _sys
from pathlib import Path as _Path
_release_root = _Path(__file__).resolve().parents[2]
_sys.path.insert(0, str(_release_root))
from release_support import configured_path as _configured_path, prepare_transfer as _prepare_transfer
import unittest
import numpy as np
from evaluate_confirmation import check_screen_distance

class DistancePrecision(unittest.TestCase):

    def test_roundoff_allowed_but_group_change_rejected(self):
        saved = np.array([0.2270127, 0.4, 0.6])
        current = saved + np.array([7e-07, -6e-07, 1e-07])
        check_screen_distance(saved, current, 0.28327, 0.45688)
        with self.assertRaises(AssertionError):
            check_screen_distance(np.array([0.4568799]), np.array([0.4568801]), 0.28327, 0.45688)
        with self.assertRaises(AssertionError):
            check_screen_distance(saved, current + 0.01, 0.28327, 0.45688)
if __name__ == '__main__':
    raise SystemExit('Use scripts/train_mainline.py for mainline fitting or the saved-result analysis scripts. This historical entry is retained for method provenance, not default execution.')
