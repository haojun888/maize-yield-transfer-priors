import sys as _sys
from pathlib import Path as _Path
_release_root = _Path(__file__).resolve().parents[2]
_sys.path.insert(0, str(_release_root))
from release_support import configured_path as _configured_path, prepare_transfer as _prepare_transfer
'Protocol B: source-selected statistical RF/HGB and exactly matched reused LSTM.'
import os
os.environ['OMP_NUM_THREADS'] = '1'
os.environ['MKL_NUM_THREADS'] = '2'
os.environ['OPENBLAS_NUM_THREADS'] = '2'
os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
import sys, json, hashlib, time, warnings
sys.dont_write_bytecode = True
from pathlib import Path
import numpy as np
import pandas as pd
import joblib
import torch
from sklearn.ensemble import RandomForestRegressor, HistGradientBoostingRegressor
from contextlib import nullcontext
OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
WORK = ROOT / 'work/maize_main_strong_baselines'
OLD = ROOT / 'outputs/maize_evi_models/gdd_plus_evi__E_to_W'
sys.path.insert(0, str(ROOT / 'outputs/maize_baseline'))
import train as tr
from pipeline import prepare_arrays
sys.path.insert(0, str(ROOT / 'outputs/maize_anomaly_transfer'))
import experiment as ex
SEEDS = [42, 2026, 3407]
METHODS = ['RF_stats', 'HGB_stats', 'LSTM32_reused']
torch.set_num_threads(1)

def sha(p):
    h = hashlib.sha256()
    with Path(p).open('rb') as f:
        for block in iter(lambda: f.read(4194304), b''):
            h.update(block)
    return h.hexdigest()

def read(p):
    return json.loads(Path(p).read_text(encoding='utf-8'))

def save(p, x):
    Path(p).write_text(json.dumps(x, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

def source():
    d = np.load(ROOT / 'work/maize_fusion_screen/gdd_evi.npz')
    split = np.load(ROOT / 'outputs/maize_fusion_transfer/split_E_to_W.npz')
    bg = read(ROOT / 'outputs/maize_fusion_transfer/background_E_to_W.json')
    return (d, split, bg)

def statistics(x, static, lengths):
    """Eight statistics per channel use finite observations only inside valid length.
    Slope is value per dekad index, preserving gaps; count/length is observation fraction.
    All-missing summaries and slopes with <2 observations remain missing for source imputation.
    """
    x = np.asarray(x, dtype=np.float64)
    lengths = np.asarray(lengths)
    assert x.ndim == 3 and len(lengths) == len(x) and np.all((lengths > 0) & (lengths <= x.shape[1]))
    valid = np.arange(x.shape[1])[None, :] < lengths[:, None]
    mask = np.isfinite(x) & valid[:, :, None]
    a = np.where(mask, x, np.nan)
    count = mask.sum(1)
    den = np.maximum(count, 1)
    total = np.where(mask, x, 0).sum(1)
    mean = total / den
    var = np.where(mask, (x - mean[:, None, :]) ** 2, 0).sum(1) / den
    with warnings.catch_warnings():
        warnings.simplefilter('ignore', RuntimeWarning)
        low = np.nanmin(a, axis=1)
        high = np.nanmax(a, axis=1)
    last = np.full_like(mean, np.nan)
    for feature in range(x.shape[2]):
        idx = np.where(mask[:, :, feature], np.arange(x.shape[1])[None, :], -1).max(1)
        ids = np.flatnonzero(idx >= 0)
        last[ids, feature] = x[ids, idx[ids], feature]
    times = np.arange(x.shape[1], dtype=float)[None, :, None]
    tm = np.where(mask, times, 0).sum(1) / den
    td = times - tm[:, None, :]
    numer = np.where(mask, td * (x - mean[:, None, :]), 0).sum(1)
    divisor = np.where(mask, td ** 2, 0).sum(1)
    slope = np.divide(numer, divisor, out=np.full_like(mean, np.nan), where=divisor > 0)
    mean[count == 0] = np.nan
    var[count == 0] = np.nan
    total[count == 0] = np.nan
    summaries = np.stack([mean, np.sqrt(var), low, high, total, last, slope, count / lengths[:, None]], axis=2)
    return np.concatenate([summaries.reshape(len(x), -1), lengths[:, None], np.asarray(static)], axis=1)

def fit_imputer(table, mask):
    with warnings.catch_warnings():
        warnings.simplefilter('ignore', RuntimeWarning)
        med = np.nanmedian(table[mask], axis=0)
    med = np.where(np.isfinite(med), med, 0.0)
    return med

def fill(table, median):
    return np.where(np.isfinite(table), table, median)

def sequence(d, p):
    x = d['x']
    lengths = d['lengths']
    valid = np.arange(x.shape[1])[None, :] < lengths[:, None]
    observed = np.isfinite(x) & valid[:, :, None]
    normalized = (np.where(observed, x, np.array(p['median'])) - np.array(p['mean'])) / np.array(p['scale'])
    normalized[~valid] = 0
    seq = np.concatenate([normalized, observed.astype(float), valid[:, :, None].astype(float)], 2).astype(np.float32)
    st = (np.where(np.isfinite(d['static']), d['static'], p['static_median']) - p['static_mean']) / p['static_scale']
    return (seq, st.astype(np.float32))

def check_reuse(d, split, bg):
    olddata = np.load(ROOT / 'work/maize_evi_models/gdd_plus_evi.npz')
    for k in d.files:
        np.testing.assert_array_equal(d[k], olddata[k])
    oldsplit = ex.make_split(d['years'], d['counties'], 'E_to_W')
    for k in oldsplit:
        np.testing.assert_array_equal(split[k], oldsplit[k])
    oldbg = read(OLD / 'background.json')
    assert all((bg[k] == oldbg[k] for k in ['selection', 'final_fit']))
    params = read(OLD / 'preprocessing.json')
    for phase, key in [('selection', 'train'), ('final_fit', 'fit')]:
        seq, st, computed = prepare_arrays(d['x'], d['static'], d['lengths'], split[key])
        assert computed == params[phase]
        a, b = sequence(d, params[phase])
        np.testing.assert_allclose(a, seq, atol=2e-06)
        np.testing.assert_allclose(b, st, atol=2e-06)
    selection = read(OLD / 'selection.json')
    complete = read(OLD / 'complete.json')
    assert complete['background_kind'] == 'trend' and complete['models'] == 6
    for seed in SEEDS:
        ck = torch.load(OLD / f'lstm_{seed}.pt', map_location='cpu', weights_only=True)
        row = next((v for v in selection if v.get('model') == 'LSTM' and v.get('seed') == seed))
        assert ck['seed'] == seed and ck['epochs'] == row['best_epoch'] <= 60 and (ck['dynamic_dim'] == 21) and (ck['static_dim'] == 2)
        target = d['y'] - ex.background_predict(bg['final_fit'], d['years'], d['counties'])
        target = target.astype(np.float32)
        assert ck['target_mean'] == float(target[split['fit']].mean()) and ck['target_std'] == float(target[split['fit']].std())
        model = tr.LSTM(21, 2)
        model.load_state_dict(ck['state_dict'])
        assert model.lstm.hidden_size == 32
    return {'LSTM': 'exact full-array, split, source trend, preprocessing and checkpoint match; reused without training', 'RF': 'old fixed-length flattening, 300 trees leaf 5/20 differs from prescribed statistics and 400 trees; new train', 'HGB': 'no matching existing model; new train', 'lstm_epochs': {str(z): next((v['best_epoch'] for v in selection if v.get('model') == 'LSTM' and v.get('seed') == z)) for z in SEEDS}}

def forest(leaf, seed):
    return RandomForestRegressor(n_estimators=400, min_samples_leaf=leaf, random_state=seed, n_jobs=1)

def boost(leaf, l2, seed):
    return HistGradientBoostingRegressor(max_iter=200, learning_rate=0.05, max_leaf_nodes=leaf, l2_regularization=l2, early_stopping=False, random_state=seed)

def train():
    start = time.time()
    OUT.mkdir(exist_ok=True)
    WORK.mkdir(exist_ok=True, parents=True)
    d, split, bg = source()
    reuse = check_reuse(d, split, bg)
    deps = [Path(__file__), OUT / 'test_baselines.py', ROOT / 'outputs/主线补强协议_2026-10-12.md', ROOT / 'work/maize_fusion_screen/gdd_evi.npz', ROOT / 'work/maize_evi_models/gdd_plus_evi.npz', ROOT / 'outputs/maize_fusion_transfer/split_E_to_W.npz', ROOT / 'outputs/maize_fusion_transfer/background_E_to_W.json', ROOT / 'outputs/maize_baseline/train.py', ROOT / 'outputs/maize_baseline/pipeline.py', ROOT / 'outputs/maize_anomaly_transfer/experiment.py']
    deps += [OLD / k for k in ['background.json', 'preprocessing.json', 'selection.json', 'complete.json', 'selection_history.csv', 'final_history.csv']] + [OLD / f'lstm_{z}.pt' for z in SEEDS]
    hashes = {str(p): sha(p) for p in deps}
    manifest = {'sha256': hashes, 'reuse': reuse, 'seeds': SEEDS, 'methods': METHODS, 'source_rows': {k: int(split[k].sum()) for k in ['train', 'val', 'fit']}, 'targets_used_for_selection': False, 'target_outcomes_previously_known': True, 'statistics_order': ['mean', 'std_population', 'min', 'max', 'sum', 'last_finite', 'slope_per_dekad_index', 'observed_fraction'], 'dimensions': 83, 'CPU_threads_max': 2, 'RF_jobs': 1, 'OMP_and_Torch_threads': 1, 'runtime_note': 'MKL threadpool query unavailable; RF threading pipe denied by sandbox; single-thread RF with OMP limit 2', 'RF_other_parameters': 'sklearn defaults: max_features=1.0, unlimited depth', 'HGB_early_stopping': False}
    if (OUT / 'source_manifest.json').exists():
        assert read(OUT / 'source_manifest.json') == manifest
    else:
        save(OUT / 'source_manifest.json', manifest)
    table = statistics(d['x'], d['static'], d['lengths'])
    med = fit_imputer(table, split['train'])
    fmed = fit_imputer(table, split['fit'])
    save(OUT / 'statistical_preprocessing.json', {'selection_median': med.tolist(), 'final_fit_median': fmed.tolist(), 'all_missing_fallback': 0.0})
    a = fill(table, med)
    fa = fill(table, fmed)
    residual = {k: (d['y'] - ex.background_predict(bg[k], d['years'], d['counties'])).astype(np.float32) for k in ['selection', 'final_fit']}
    rows = []
    modelhash = {}
    for seed in SEEDS:
        file = OUT / f'selection_{seed}.json'
        if file.exists():
            chosen = read(file)
        else:
            progress = OUT / f'candidate_progress_{seed}.json'
            candidates = read(progress) if progress.exists() else []
            for method, configs in [('RF_stats', [{'leaf': v} for v in [2, 5, 10]]), ('HGB_stats', [{'leaf': v, 'l2': l} for v in [15, 31] for l in [0.0, 1.0]])]:
                for conf in configs:
                    if any((r['method'] == method and all((r[k] == v for k, v in conf.items())) for r in candidates)):
                        continue
                    model = forest(conf['leaf'], seed) if method == 'RF_stats' else boost(conf['leaf'], conf['l2'], seed)
                    with nullcontext():
                        model.fit(a[split['train']], residual['selection'][split['train']])
                        p = model.predict(a[split['val']])
                    rmse = float(np.sqrt(np.mean((p - residual['selection'][split['val']]) ** 2)))
                    candidates.append({'method': method, 'seed': seed, **conf, 'val_rmse_t_ha': rmse})
                    save(progress, candidates)
                    print('SOURCE_CANDIDATE', candidates[-1], flush=True)
            chosen = {'candidates': candidates, 'selected': {m: min([r for r in candidates if r['method'] == m], key=lambda r: r['val_rmse_t_ha']) for m in METHODS[:2]}}
            save(file, chosen)
        rows.extend(chosen['candidates'])
        for method, conf in chosen['selected'].items():
            file = OUT / f'final_{method}_{seed}.joblib'
            if not file.exists():
                model = forest(conf['leaf'], seed) if method == 'RF_stats' else boost(conf['leaf'], conf['l2'], seed)
                with nullcontext():
                    model.fit(fa[split['fit']], residual['final_fit'][split['fit']])
                joblib.dump(model, file, compress=3)
            modelhash[str(file)] = sha(file)
            print('SOURCE_FINAL', seed, method, conf, flush=True)
        modelhash[str(OLD / f'lstm_{seed}.pt')] = sha(OLD / f'lstm_{seed}.pt')
    for r in read(OLD / 'selection.json'):
        if r['model'] == 'LSTM':
            rows.append({'method': METHODS[2], 'seed': r['seed'], 'epoch': r['best_epoch'], 'val_rmse_t_ha': r['rmse_t_ha'], 'reused': True})
    pd.DataFrame(rows).to_csv(OUT / 'validation_candidates.csv', index=False)
    for p, h in hashes.items():
        assert sha(p) == h
    files = [OUT / 'statistical_preprocessing.json', OUT / 'validation_candidates.csv'] + [OUT / f'selection_{z}.json' for z in SEEDS]
    record = {'verified': True, 'models_sha256': modelhash, 'source_dependencies_sha256': hashes, 'artifacts_sha256': {str(p): sha(p) for p in files}, 'source_frozen_before_target_prediction': True, 'new_RF_final': 3, 'new_HGB_final': 3, 'reused_LSTM': 3, 'LSTM_new_training': 0, 'runtime_seconds': time.time() - start}
    if (OUT / 'source_freeze.json').exists():
        old = read(OUT / 'source_freeze.json')
        assert old['models_sha256'] == modelhash
    else:
        save(OUT / 'source_freeze.json', record)
    print('SOURCE_FROZEN', time.time() - start, flush=True)

def verify_source():
    lock = read(OUT / 'source_freeze.json')
    assert lock['verified']
    for collection in ['models_sha256', 'source_dependencies_sha256', 'artifacts_sha256']:
        for p, h in lock[collection].items():
            assert sha(p) == h, p
    return lock

def target_prediction(d):
    med = np.array(read(OUT / 'statistical_preprocessing.json')['final_fit_median'])
    a = fill(statistics(d['x'], d['static'], d['lengths']), med)
    seq, st = sequence(d, read(OLD / 'preprocessing.json')['final_fit'])
    bg = ex.background_predict(source()[2]['final_fit'], d['years'], d['counties'])
    predictions = []
    for seed in SEEDS:
        ps = []
        for method in METHODS[:2]:
            model = joblib.load(OUT / f'final_{method}_{seed}.joblib')
            with nullcontext():
                value = model.predict(a)
            ps.append(value + bg)
        ck = torch.load(OLD / f'lstm_{seed}.pt', weights_only=True, map_location='cpu')
        model = tr.LSTM(21, 2).to(tr.DEVICE)
        model.load_state_dict(ck['state_dict'])
        value = tr.predict(model, seq, st, d['lengths'], np.ones(len(bg), dtype=bool), ck['target_mean'], ck['target_std'])
        ps.append(value + bg)
        predictions.append(ps)
    return (np.array(predictions, dtype=np.float64), bg)

def evaluate(include_new=False):
    start = time.time()
    lock = verify_source()
    datasets = []
    d, split, bg = source()
    for name, key in [('W_space', 'space'), ('W_joint', 'joint')]:
        raw = {k: d[k][split[key]] for k in d.files}
        old = np.load(ROOT / f'outputs/maize_fixed_prior_extension/predictions_{name}.npz')
        datasets.append((name, raw, old, {str(ROOT / f'outputs/maize_fixed_prior_extension/predictions_{name}.npz'): sha(ROOT / f'outputs/maize_fixed_prior_extension/predictions_{name}.npz')}))
    for name, folder in [('KYTN', 'maize_external_region'), ('TXGA', 'maize_high_weather_transfer')]:
        path = ROOT / f'work/{folder}/dataset.npz'
        raw = np.load(path)
        old = np.load(ROOT / f'outputs/maize_fixed_prior_extension/predictions_{name}.npz')
        datasets.append((name, raw, old, {str(path): sha(path)}))
    if include_new:
        path = ROOT / 'work/maize_independent_confirmation/dataset.npz'
        oldpath = ROOT / 'outputs/maize_independent_confirmation/model_predictions.npz'
        assert path.exists() and oldpath.exists(), 'New data and frozen reference predictions not ready'
        datasets.append(('SCOKMS', np.load(path), np.load(oldpath), {str(path): sha(path), str(oldpath): sha(oldpath)}))
    rules = read(ROOT / 'outputs/maize_fixed_prior_extension/distance_rules.json')
    metricrows = []
    paired = []
    verified = []
    for name, raw, old, targethash in datasets:
        path = OUT / f'predictions_{name}.npz'
        if path.exists():
            saved = np.load(path)
            pred = saved['predictions']
            background = saved['background']
        else:
            save(OUT / f'target_lock_{name}.json', {'source_freeze_sha256': sha(OUT / 'source_freeze.json'), 'target_sha256': targethash, 'target_predictions_started': False})
            for k in ['y', 'years', 'counties']:
                np.testing.assert_array_equal(raw[k], old[k])
            pred, background = target_prediction(raw)
            repeat, rb = target_prediction(raw)
            np.testing.assert_allclose(pred, repeat, atol=2e-06, rtol=2e-06)
            np.testing.assert_allclose(background, old['background'], atol=2e-08)
            arrays = {k: raw[k] for k in ['y', 'years', 'counties']}
            for definition, key in [('weather_only', 'weather_distance'), ('weather_calendar', 'calendar_distance')]:
                if definition in old.files:
                    arrays[definition] = old[definition]
                elif key in old.files:
                    arrays[definition] = old[key]
                else:
                    df = pd.read_csv(ROOT / 'outputs/maize_independent_confirmation/evaluation_distances.csv', dtype={'adm_id': str})
                    frame = df[df.definition == definition].sort_values('row')
                    np.testing.assert_array_equal(frame.adm_id, raw['counties'])
                    np.testing.assert_array_equal(frame.year, raw['years'])
                    arrays[definition] = frame.distance.to_numpy()
            np.savez_compressed(path, predictions=pred, background=background, methods=np.array(METHODS), seeds=np.array(SEEDS), **arrays)
            saved = np.load(path)
        for k in ['y', 'years', 'counties']:
            np.testing.assert_array_equal(raw[k], saved[k])
        y = raw['y'].astype(float)
        states = np.array([c.split('-')[1] for c in raw['counties']])
        county = raw['counties']
        for definition in rules:
            dist = saved[definition]
            rule = rules[definition]
            bins = np.where(~np.isfinite(dist), -1, np.where(dist <= rule['low_max'], 0, np.where(dist >= rule['high_min'], 2, 1)))
            for state in ['pooled'] + sorted(set(states)):
                mask = np.ones(len(y), bool) if state == 'pooled' else states == state
                for label, group in [('overall', mask), ('low', mask & (bins == 0)), ('middle', mask & (bins == 1)), ('high', mask & (bins == 2)), ('source_q95_above', mask & (dist > rule['source_q95']))]:
                    if not group.any():
                        continue
                    ref = old['predictions'][:, old['methods'].tolist().index('sobol_fixed')][:, group]
                    errors = (pred[:, :, group] - y[group]) ** 2
                    referrors = (ref - y[group]) ** 2
                    for mi, method in enumerate(METHODS):
                        for si, seed in enumerate(SEEDS):
                            values = pred[si, mi, group]
                            mse = float(errors[si, mi].mean())
                            metricrows.append({'cohort': name, 'definition': definition, 'state_fips': state, 'group': label, 'method': method, 'seed': seed, **tr.metrics(y[group], values), 'mse': mse, 'mse_minus_sobol': float((errors[si, mi] - referrors[si]).mean()), 'background_skill': 1 - mse / np.mean((background[group] - y[group]) ** 2)})
                        gain = (errors[:, mi] - referrors).mean(0)
                        unique, inverse = np.unique(county[group], return_inverse=True)
                        counts = np.bincount(inverse)
                        sums = np.bincount(inverse, weights=gain)
                        draws = np.random.default_rng(20261012).integers(0, len(unique), (2000, len(unique)))
                        boot = sums[draws].sum(1) / counts[draws].sum(1)
                        lo, hi = np.quantile(boot, [0.025, 0.975])
                        paired.append({'cohort': name, 'definition': definition, 'state_fips': state, 'group': label, 'method': method, 'n': int(group.sum()), 'counties': len(unique), 'mse_minus_sobol': float(gain.mean()), 'county_bootstrap_low': float(lo), 'county_bootstrap_high': float(hi)})
        for p, h in targethash.items():
            assert sha(p) == h
        verified.append({'cohort': name, 'n': len(y), 'counties': len(set(county)), 'prediction_sha256': sha(path), 'all_cases_finite': bool(np.isfinite(pred).all())})
        assert np.isfinite(pred).all() and pred.shape == (3, 3, len(y))
        print('COHORT_VERIFIED', name, len(y), flush=True)
    metric = pd.DataFrame(metricrows)
    metric.to_csv(OUT / 'metrics.csv', index=False)
    summary = metric.groupby(['cohort', 'definition', 'state_fips', 'group', 'method'], sort=False).agg(n=('n', 'first'), rmse_mean=('rmse_t_ha', 'mean'), rmse_seed_sd=('rmse_t_ha', 'std'), r2_mean=('r2', 'mean'), mse_mean=('mse', 'mean'), mse_minus_sobol=('mse_minus_sobol', 'mean'), background_skill=('background_skill', 'mean')).reset_index()
    summary.to_csv(OUT / 'summary.csv', index=False)
    pd.DataFrame(paired).to_csv(OUT / 'paired_county_intervals.csv', index=False)
    headline = summary[(summary.definition == 'weather_only') & (summary.state_fips == 'pooled') & summary.group.isin(['overall', 'high'])]
    lines = ['# 同输入、同源域强基线', '', '完整10动态特征和2土壤变量、相同窗口、源趋势残差与04–16/17–19/04–19协议。LSTM已通过数组、划分、背景和预处理精确核对，复用旧单LSTM32三个种子（源选轮30、34、27）；RF/HGB按预定统计特征新训，只按源验证选参数。RF采用完整统计特征，400树，无深度限制；HGB 200轮，禁用内部早停。', '', '|队列|组|模型|n|RMSE t/ha|MSE−Sobol|背景技能|', '|---|---|---|---:|---:|---:|---:|']
    for r in headline.itertuples():
        lines.append(f'|{r.cohort}|{r.group}|{r.method}|{r.n}|{r.rmse_mean:.4f}|{r.mse_minus_sobol:+.4f}|{r.background_skill:.4f}|')
    lines += ['', '各种子独立评分后平均；县配对区间按相同病例平均种子误差差并进行县级重采样，正值表示Sobol误差更低。天气主、天气加日历辅助、每州完整/高/中/低和源95%阈上全部保留。比较的是完整预测流程，统计汇总、原序列LSTM与分组融合在信息压缩和容量上不同，不能称参数量或压缩严格匹配。旧目标结果在设计前已知，此新增强基线不构成新的盲确认；新州独立的是地域且沿用既有年份/数据产品。单LSTM没有复训，旧文件仅只读。']
    (OUT / '结果报告.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')
    verify_source()
    files = [OUT / n for n in ['metrics.csv', 'summary.csv', 'paired_county_intervals.csv', '结果报告.md']]
    save(OUT / 'evaluation_verification.json', {'verified': True, 'cohorts': verified, 'source_freeze_sha256': sha(OUT / 'source_freeze.json'), 'no_target_fitting': True, 'source_and_models_unchanged': True, 'output_sha256': {str(p): sha(p) for p in files}, 'new_confirmation_included': include_new, 'runtime_seconds': time.time() - start})
    print(headline.to_string(index=False), flush=True)
if __name__ == '__main__':
    raise SystemExit('Use scripts/train_mainline.py for mainline fitting or the saved-result analysis scripts. This historical entry is retained for method provenance, not default execution.')
