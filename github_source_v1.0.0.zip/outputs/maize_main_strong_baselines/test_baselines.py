import sys as _sys
from pathlib import Path as _Path
_release_root = _Path(__file__).resolve().parents[2]
_sys.path.insert(0, str(_release_root))
from release_support import configured_path as _configured_path, prepare_transfer as _prepare_transfer
import unittest
import numpy as np
import baselines as b

class StatisticsTests(unittest.TestCase):

    def test_variable_length_and_padding(self):
        x = np.array([[[1.0], [np.nan], [5.0], [999.0]], [[2.0], [2.0], [2.0], [2.0]]])
        got = b.statistics(x, np.zeros((2, 2)), np.array([3, 4]))
        np.testing.assert_allclose(got[0, :8], [3.0, 2.0, 1.0, 5.0, 6.0, 5.0, 2.0, 2 / 3])
        x[0, 3, 0] = -100000
        np.testing.assert_allclose(got, b.statistics(x, np.zeros((2, 2)), [3, 4]))
        self.assertEqual(got.shape, (2, 11))

    def test_all_missing_and_single_slope(self):
        x = np.array([[[np.nan], [np.nan]], [[4.0], [np.nan]]])
        got = b.statistics(x, np.zeros((2, 2)), [2, 2])
        self.assertTrue(np.isnan(got[0, :7]).all())
        self.assertEqual(got[0, 7], 0.0)
        self.assertTrue(np.isnan(got[1, 6]))
        self.assertEqual(got[1, 7], 0.5)

    def test_source_imputation_no_target_leak(self):
        a = np.array([[1.0, np.nan], [3.0, np.nan], [1000.0, 999.0]])
        np.testing.assert_array_equal(b.fit_imputer(a, np.array([True, True, False])), [2.0, 0.0])
        a[-1] = [-99999.0, -99999.0]
        np.testing.assert_array_equal(b.fit_imputer(a, np.array([True, True, False])), [2.0, 0.0])

    def test_slope_keeps_observation_gap(self):
        x = np.array([[[0.0], [np.nan], [4.0]]])
        out = b.statistics(x, np.zeros((1, 2)), [3])
        self.assertEqual(out[0, 6], 2.0)
if __name__ == '__main__':
    raise SystemExit('Use scripts/train_mainline.py for mainline fitting or the saved-result analysis scripts. This historical entry is retained for method provenance, not default execution.')
