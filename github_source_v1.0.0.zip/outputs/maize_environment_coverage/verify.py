import sys as _sys
from pathlib import Path as _Path
_release_root = _Path(__file__).resolve().parents[2]
_sys.path.insert(0, str(_release_root))
from release_support import configured_path as _configured_path, prepare_transfer as _prepare_transfer
'Reproduce diagnostics and independently check distances and error arithmetic.'
import json
import shutil
import zipfile
import numpy as np
import pandas as pd
import torch
import coverage_analysis as c
s = c.s

def run():
    original = c.OUT
    marker = json.loads((original / 'run_complete.json').read_text(encoding='utf-8'))
    for path, value in marker['source_sha256'].items():
        assert s.sha(path) == value
    for name, value in marker['outputs_sha256'].items():
        assert s.sha(original / name) == value
    d = np.load(s.CACHE / 'gdd_evi.npz')
    window = pd.read_csv(c.ROOT / 'outputs/maize_baseline/date_windows.csv', parse_dates=['sos_date', 'eos_date', 'start', 'cutoff'], dtype={'adm_id': str})
    with zipfile.ZipFile(_configured_path('external_e22e1afd74')) as archive:
        name = 'cybench-data/maize/US/crop_calendar_maize_US.csv'
        info = archive.getinfo(name)
        with archive.open(name) as f:
            calendar = pd.read_csv(f).set_index('adm_id')
    np.testing.assert_array_equal(window.sos_date.dt.dayofyear, calendar.loc[window.adm_id, 'sos'].astype(int))
    np.testing.assert_array_equal(window.eos_date.dt.dayofyear, calendar.loc[window.adm_id, 'eos'].astype(int))
    assert ((window.cutoff - window.eos_date).dt.days == -60).all()
    feature = pd.read_csv(original / 'environment_features.csv')
    matrix = feature[c.NAMES].to_numpy()
    np.testing.assert_allclose(matrix, c.environment(d, window), rtol=1e-07, atol=1e-07)
    assert len(feature) == len(d['y']) and np.isfinite(matrix).all()
    saved_distance = pd.read_csv(original / 'distances.csv')
    rng = np.random.default_rng(9317)
    checked = 0
    for definition, (cols, groups) in c.DEFS.items():
        for phase, end in c.PHASES.items():
            fit = d['years'] <= end
            z, params = c.standardize(matrix[:, cols], fit, groups)
            stored = json.loads((original / 'standardization.json').read_text(encoding='utf-8'))[f'{definition}__{phase}']
            for key in params:
                np.testing.assert_allclose(params[key], stored[key], rtol=1e-10, atol=1e-10)
            for protocol in ['E_to_W', 'W_to_E']:
                split = c.t.make_split(d['years'], d['counties'], protocol)
                reference = np.flatnonzero(split['teacher_fit'] if phase == 'teacher_2013' else split['fit'])
                for scenario in ['space', 'joint']:
                    frame = saved_distance[(saved_distance.definition == definition) & (saved_distance.phase == phase) & (saved_distance.protocol == protocol) & (saved_distance.scenario == scenario)]
                    np.testing.assert_array_equal(frame.row.to_numpy(), np.flatnonzero(split[scenario]))
                    np.testing.assert_array_equal(frame.adm_id.to_numpy(), d['counties'][frame.row.to_numpy()])
                    for row in frame.iloc[rng.choice(len(frame), 32, replace=False)].itertuples(index=False):
                        distance = np.sqrt(((z[reference].astype(float) - z[row.row].astype(float)) ** 2).sum(1))
                        expected = np.partition(distance, 4)[:5].mean()
                        np.testing.assert_allclose(row.distance, expected, rtol=0.0002, atol=4e-05)
                        checked += 1
    decomposition = pd.read_csv(original / 'bias_decomposition.csv')
    np.testing.assert_allclose(decomposition.mse, decomposition.bias_squared + decomposition.centered_mse, atol=1e-08)
    pred = pd.read_csv(c.t.OUT / 'predictions.csv')
    pred = pred[pred.input == 'gdd_evi']
    conditional = pd.read_csv(original / 'conditional_metrics.csv')
    metric_checks = 0
    for (definition, phase, protocol, scenario), dist in saved_distance.groupby(['definition', 'phase', 'protocol', 'scenario']):
        rank = dist.distance.rank(method='average', pct=True).to_numpy()
        binid = np.minimum((rank * 3).astype(int), 2)
        for method in c.METHODS:
            frame = pred[(pred.protocol == protocol) & (pred.scenario == scenario) & (pred.variant == method)]
            values = frame.pivot(index=['adm_id', 'year'], columns='seed', values='predicted_yield_t_ha')
            index = pd.MultiIndex.from_arrays([dist.adm_id, dist.year])
            ids = dist.row.to_numpy()
            error = values.reindex(index).reindex(columns=s.SEEDS).to_numpy() - d['y'][ids, None]
            if definition == 'weather_calendar' and phase == 'fusion_2019':
                actual = np.array([c.decompose(error[:, j]) for j in range(3)]).mean(0)
                old = decomposition[(decomposition.protocol == protocol) & (decomposition.scenario == scenario) & (decomposition.method == method)].iloc[0]
                np.testing.assert_allclose([old.mse, old.bias_squared, old.centered_mse], actual, atol=1e-08)
            for b in range(3):
                row = conditional[(conditional.definition == definition) & (conditional.phase == phase) & (conditional.protocol == protocol) & (conditional.scenario == scenario) & (conditional.method == method) & (conditional.distance_bin == ['low', 'middle', 'high'][b])].iloc[0]
                mask = binid == b
                expected = float(np.sqrt((error[mask] ** 2).mean(0)).mean())
                np.testing.assert_allclose(row.rmse_mean, expected, atol=1e-08)
                assert row.n == mask.sum()
                metric_checks += 1
    replicate = c.WORK / 'reproduction'
    replicate.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(original / 'design.md', replicate / 'design.md')
    original_work = c.WORK
    c.OUT = replicate
    c.WORK = replicate / 'cache'
    c.run()
    c.OUT = original
    c.WORK = original_work
    reproduced = []
    for name, value in marker['outputs_sha256'].items():
        assert s.sha(replicate / name) == value, f'Reproduction differs: {name}'
        reproduced.append(name)
    s.save(original / 'verification.json', {'verified': True, 'distance_cpu_spot_checks': checked, 'conditional_metric_checks': metric_checks, 'reproduced_files': reproduced, 'crop_calendar_zip_member': 'cybench-data/maize/US/crop_calendar_maize_US.csv', 'crop_calendar_crc32': f'{info.CRC:08x}', 'analysis_marker_sha256': s.sha(original / 'run_complete.json'), 'verification_code_sha256': s.sha(__file__)})
    print('DIAGNOSTICS VERIFIED', checked, metric_checks, len(reproduced))
if __name__ == '__main__':
    raise SystemExit('Use scripts/train_mainline.py for mainline fitting or the saved-result analysis scripts. This historical entry is retained for method provenance, not default execution.')
