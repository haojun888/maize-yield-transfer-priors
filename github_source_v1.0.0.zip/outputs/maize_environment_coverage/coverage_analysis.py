import sys as _sys
from pathlib import Path as _Path
_release_root = _Path(__file__).resolve().parents[2]
_sys.path.insert(0, str(_release_root))
from release_support import configured_path as _configured_path, prepare_transfer as _prepare_transfer
'Post-hoc environment coverage diagnostics; no fitting or target-based selection.'
import hashlib
import json
import sys
from pathlib import Path
import numpy as np
import pandas as pd
import torch
OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
WORK = ROOT / 'work/maize_environment_coverage'
sys.path.insert(0, str(ROOT / 'outputs/maize_fusion_transfer'))
import transfer as t
s = t.s
NAMES = ['temperature', 'gdd', 'precipitation', 'water_balance', 'soil_moisture', 'radiation', 'sos_doy', 'observed_growing_days']
DEFS = {'weather_calendar': (list(range(8)), [0, 0, 1, 1, 1, 2, 3, 3]), 'weather_only': ([0, 2, 3, 4, 5], [0, 1, 1, 1, 2])}
PHASES = {'teacher_2013': 2013, 'fusion_2019': 2019}
METHODS = ['uniform', 'sobol_fixed', 'random_fixed', 'learned', 'guided_sobol']

def standardize(x, fit, groups):
    mean = np.nanmean(x[fit], axis=0)
    scale = np.nanstd(x[fit], axis=0)
    scale = np.where(scale < 1e-08, 1, scale)
    counts = np.array([groups.count(g) for g in groups])
    z = ((x - mean) / scale / np.sqrt(counts)).astype(np.float32)
    return (z, {'mean': mean.tolist(), 'scale': scale.tolist(), 'group_sizes': counts.tolist()})

def match_years(east, west, years, rng):
    a = []
    b = []
    for year in sorted(set(years[east]) & set(years[west])):
        e = east[years[east] == year]
        w = west[years[west] == year]
        n = min(len(e), len(w))
        a.extend(rng.choice(e, n, replace=False))
        b.extend(rng.choice(w, n, replace=False))
    return (np.array(a, dtype=int), np.array(b, dtype=int))

def neighbor_distance(query, reference, qcounties=None, rcounties=None, k=5):
    assert np.isfinite(query).all() and np.isfinite(reference).all() and (len(reference) >= k)
    ref = torch.as_tensor(reference, dtype=torch.float32, device=s.DEVICE)
    parts = []
    if qcounties is not None:
        codes = {c: i for i, c in enumerate(np.unique(np.concatenate([qcounties, rcounties])))}
        rc = torch.tensor([codes[c] for c in rcounties], device=s.DEVICE)
    with torch.no_grad():
        for start in range(0, len(query), 512):
            q = torch.as_tensor(query[start:start + 512], dtype=torch.float32, device=s.DEVICE)
            distances = torch.cdist(q, ref)
            if qcounties is not None:
                qc = torch.tensor([codes[c] for c in qcounties[start:start + 512]], device=s.DEVICE)
                distances.masked_fill_(qc[:, None] == rc[None, :], float('inf'))
            nearest = distances.topk(k, largest=False).values
            assert torch.isfinite(nearest).all()
            parts.append(nearest.mean(1).cpu().numpy())
    return np.concatenate(parts)

def decompose(error):
    bias = float(error.mean())
    mse = float(np.mean(error ** 2))
    return (mse, bias * bias, float(np.mean((error - bias) ** 2)))

def rho(a, b):
    keep = np.isfinite(a) & np.isfinite(b)
    a = np.asarray(a)[keep]
    b = np.asarray(b)[keep]
    if len(a) < 3 or np.ptp(a) < 1e-10 or np.ptp(b) < 1e-10:
        return np.nan
    a = pd.Series(a).rank().to_numpy()
    b = pd.Series(b).rank().to_numpy()
    a = a - a.mean()
    b = b - b.mean()
    return float(np.sum(a * b) / np.sqrt(np.sum(a * a) * np.sum(b * b)))

def environment(d, windows):
    x = d['x']
    lengths = d['lengths']
    bins = np.arange(x.shape[1])[None, :]
    np.testing.assert_array_equal(windows.adm_id, d['counties'])
    np.testing.assert_array_equal(windows.year, d['years'])
    assert ((windows.sos_date - windows.start).dt.days == 90).all()
    span = (windows.cutoff - windows.start).dt.days.to_numpy() + 1
    days = np.clip(span[:, None] - 10 * bins, 0, 10)
    selected = (bins >= 9) & (bins < lengths[:, None])
    days = np.where(selected, days, 0)
    growing = (windows.cutoff - windows.sos_date).dt.days.to_numpy() + 1
    np.testing.assert_array_equal(days.sum(1), growing)

    def average(j):
        observed = np.isfinite(x[:, :, j]) & selected
        weight = np.where(observed, days, 0)
        result = (np.where(observed, x[:, :, j], 0) * weight).sum(1) / np.maximum(weight.sum(1), 1)
        result[weight.sum(1) < 0.8 * growing] = np.nan
        return result

    def total(j):
        observed = np.isfinite(x[:, :, j]) | ~selected
        result = np.where(selected, x[:, :, j], 0).sum(1)
        result[~observed.all(1)] = np.nan
        return result
    return np.stack([average(2), x[np.arange(len(x)), lengths - 1, 8], total(3), total(4), average(7), average(5), windows.sos_date.dt.dayofyear.to_numpy(), growing], axis=1).astype(float)

def pair_diversity(z, ids, counties, rng):
    a = rng.choice(ids, 50000)
    b = rng.choice(ids, 50000)
    keep = counties[a] != counties[b]
    distance = np.sqrt(((z[a[keep]] - z[b[keep]]) ** 2).sum(1))
    return (float(distance.mean()), float(np.quantile(distance, 0.9)))

def support(z, reference, target, counties, rng):
    calibration = rng.choice(reference, min(2000, len(reference)), replace=False)
    inner = neighbor_distance(z[calibration], z[reference], counties[calibration], counties[reference])
    threshold = float(np.quantile(inner, 0.95))
    distance = neighbor_distance(z[target], z[reference])
    return (distance, threshold)

def error_arrays(pred, d, protocol, scenario, ids):
    index = pd.MultiIndex.from_arrays([d['counties'][ids], d['years'][ids]], names=['adm_id', 'year'])
    errors = {}
    subset = pred[(pred.protocol == protocol) & (pred.scenario == scenario)]
    for method in METHODS:
        frame = subset[subset.variant == method]
        values = frame.pivot(index=['adm_id', 'year'], columns='seed', values='predicted_yield_t_ha').reindex(index).reindex(columns=s.SEEDS)
        assert np.isfinite(values.to_numpy()).all()
        errors[method] = values.to_numpy() - d['y'][ids, None]
    return errors

def bootstrap_bins(errors, binid, counties, rng):
    groups = np.unique(counties)
    lookup = {v: i for i, v in enumerate(groups)}
    code = np.array([lookup[v] for v in counties])
    counts = np.zeros((len(groups), 3))
    sse = {m: np.zeros((len(groups), 3, 3)) for m in ['uniform', 'sobol_fixed']}
    for b in range(3):
        mask = binid == b
        np.add.at(counts[:, b], code[mask], 1)
        for m in sse:
            np.add.at(sse[m][:, b], code[mask], errors[m][mask] ** 2)
    draws = []
    for _ in range(1000):
        ids = rng.integers(0, len(groups), len(groups))
        n = counts[ids].sum(0)
        if np.any(n == 0):
            continue
        u = np.sqrt(sse['uniform'][ids].sum(0) / n[:, None]).mean(1)
        f = np.sqrt(sse['sobol_fixed'][ids].sum(0) / n[:, None]).mean(1)
        gain = u - f
        draws.append([*gain, gain[2] - gain[0]])
    draws = np.array(draws)
    return np.quantile(draws, [0.025, 0.975], axis=0)

def run():
    WORK.mkdir(parents=True, exist_ok=True)
    v = json.loads((t.OUT / 'verification.json').read_text(encoding='utf-8'))
    assert v['verified']
    for name in ['predictions.csv', 'summary.csv']:
        assert s.sha(t.OUT / name) == v['outputs_sha256'][name]
    for path, value in json.loads((t.OUT / 'manifest.json').read_text(encoding='utf-8'))['sha256'].items():
        assert s.sha(path) == value
    d = np.load(s.CACHE / 'gdd_evi.npz')
    windows = pd.read_csv(ROOT / 'outputs/maize_baseline/date_windows.csv', parse_dates=['sos_date', 'eos_date', 'start', 'cutoff'], dtype={'adm_id': str})
    features = environment(d, windows)
    np.save(WORK / 'environment.npy', features)
    frame = pd.DataFrame(features, columns=NAMES)
    frame.insert(0, 'year', d['years'])
    frame.insert(0, 'adm_id', d['counties'])
    frame.to_csv(OUT / 'environment_features.csv', index=False)
    east = np.isin([c.split('-')[1] for c in d['counties']], list(s.e.EAST))
    years = d['years']
    counties = d['counties']
    pred = pd.read_csv(t.OUT / 'predictions.csv', dtype={'adm_id': str})
    pred = pred[pred.input == 'gdd_evi']
    rng = np.random.default_rng(20261009)
    diversity = []
    coverage = []
    balanced = []
    conditional = []
    associations = []
    bootstrap = []
    distance_rows = []
    decomposition = []
    standardization = {}
    for protocol in ['E_to_W', 'W_to_E']:
        split = t.make_split(years, counties, protocol)
        for scenario in ['space', 'joint']:
            ids = np.flatnonzero(split[scenario])
            errors = error_arrays(pred, d, protocol, scenario, ids)
            for method, error in errors.items():
                parts = np.array([decompose(error[:, j]) for j in range(3)]).mean(0)
                decomposition.append({'protocol': protocol, 'scenario': scenario, 'method': method, 'mse': parts[0], 'bias_squared': parts[1], 'centered_mse': parts[2]})
    for definition, (cols, groups) in DEFS.items():
        complete = np.isfinite(features[:, cols]).all(1)
        for phase, end in PHASES.items():
            fit = (years <= end) & complete
            z, params = standardize(features[:, cols], fit, groups)
            standardization[f'{definition}__{phase}'] = params
            e = np.flatnonzero(fit & east)
            w = np.flatnonzero(fit & ~east)
            for region, ids in [('East', e), ('West', w)]:
                mean, p90 = pair_diversity(z, ids, counties, rng)
                diversity.append({'definition': definition, 'phase': phase, 'sampling': 'full', 'repeat': 0, 'region': region, 'n': len(ids), 'counties': len(np.unique(counties[ids])), 'pair_distance_mean': mean, 'pair_distance_p90': p90})
            for protocol, reference in [('E_to_W', e), ('W_to_E', w)]:
                split = t.make_split(years, counties, protocol)
                for scenario in ['space', 'joint']:
                    target = np.flatnonzero(split[scenario] & complete)
                    distance, threshold = support(z, reference, target, counties, rng)
                    info = {'definition': definition, 'phase': phase, 'protocol': protocol, 'scenario': scenario}
                    coverage.append({**info, 'source_n': len(reference), 'target_n': len(target), 'excluded_target_n': int(split[scenario].sum() - len(target)), 'source_q95': threshold, 'target_distance_median': float(np.median(distance)), 'target_distance_p90': float(np.quantile(distance, 0.9)), 'above_source_q95_fraction': float((distance > threshold).mean())})
                    distance_rows.append(pd.DataFrame({**info, 'row': target, 'adm_id': counties[target], 'year': years[target], 'distance': distance, 'source_q95': threshold}))
                    errors = error_arrays(pred, d, protocol, scenario, target)
                    gain = (errors['uniform'] ** 2 - errors['sobol_fixed'] ** 2).mean(1)
                    associations.append({**info, 'n': len(target), 'rho_distance_uniform_abs_error': rho(distance, np.abs(errors['uniform']).mean(1)), 'rho_distance_fixed_abs_error': rho(distance, np.abs(errors['sobol_fixed']).mean(1)), 'rho_distance_sobol_mse_gain': rho(distance, gain)})
                    percentile = pd.Series(distance).rank(method='average', pct=True).to_numpy()
                    binid = np.minimum((percentile * 3).astype(int), 2)
                    gains = []
                    for b in range(3):
                        mask = binid == b
                        values = {}
                        for method, error in errors.items():
                            rmse = np.sqrt((error[mask] ** 2).mean(0))
                            values[method] = float(rmse.mean())
                            conditional.append({**info, 'distance_bin': ['low', 'middle', 'high'][b], 'method': method, 'n': int(mask.sum()), 'distance_mean': float(distance[mask].mean()), 'rmse_mean': float(rmse.mean()), 'bias_mean': float(error[mask].mean()), 'yield_sd': float(d['y'][target[mask]].std()), 'normalized_rmse': float(rmse.mean() / d['y'][target[mask]].std())})
                        gains.append(values['uniform'] - values['sobol_fixed'])
                    if definition == 'weather_calendar' and phase == 'fusion_2019':
                        ci = bootstrap_bins(errors, binid, counties[target], rng)
                        for j, label in enumerate(['low', 'middle', 'high', 'high_minus_low']):
                            point = gains[j] if j < 3 else gains[2] - gains[0]
                            bootstrap.append({**info, 'comparison': label, 'rmse_gain_uniform_minus_fixed': point, 'county_bootstrap_low': ci[0, j], 'county_bootstrap_high': ci[1, j]})
                    np.savez_compressed(WORK / f'{definition}__{phase}__{protocol}__{scenario}.npz', target_rows=target, distance=distance, binid=binid, source_q95=threshold)
            for repeat in range(20):
                a, b = match_years(e, w, years, rng)
                for region, ids in [('East', a), ('West', b)]:
                    mean, p90 = pair_diversity(z, ids, counties, rng)
                    diversity.append({'definition': definition, 'phase': phase, 'sampling': 'year_sample_matched', 'repeat': repeat, 'region': region, 'n': len(ids), 'counties': len(np.unique(counties[ids])), 'pair_distance_mean': mean, 'pair_distance_p90': p90})
                for protocol, reference, target in [('E_to_W', a, w), ('W_to_E', b, e)]:
                    distance, threshold = support(z, reference, target, counties, rng)
                    balanced.append({'definition': definition, 'phase': phase, 'repeat': repeat, 'protocol': protocol, 'source_n': len(reference), 'target_n': len(target), 'source_q95': threshold, 'target_distance_median': float(np.median(distance)), 'target_distance_p90': float(np.quantile(distance, 0.9)), 'above_source_q95_fraction': float((distance > threshold).mean())})
                ec = np.unique(counties[e])
                wc = np.unique(counties[w])
                n = min(len(ec), len(wc))
                for region, ids, available in [('East', e, ec), ('West', w, wc)]:
                    chosen = rng.choice(available, n, replace=False)
                    got = ids[np.isin(counties[ids], chosen)]
                    mean, p90 = pair_diversity(z, got, counties, rng)
                    diversity.append({'definition': definition, 'phase': phase, 'sampling': 'county_matched', 'repeat': repeat, 'region': region, 'n': len(got), 'counties': n, 'pair_distance_mean': mean, 'pair_distance_p90': p90})
                if repeat in [0, 9, 19]:
                    print('COVERAGE BALANCED', definition, phase, repeat + 1, flush=True)
    outputs = {'diversity.csv': pd.DataFrame(diversity), 'coverage.csv': pd.DataFrame(coverage), 'balanced_coverage.csv': pd.DataFrame(balanced), 'conditional_metrics.csv': pd.DataFrame(conditional), 'error_associations.csv': pd.DataFrame(associations), 'conditional_gain_bootstrap.csv': pd.DataFrame(bootstrap), 'distances.csv': pd.concat(distance_rows, ignore_index=True), 'bias_decomposition.csv': pd.DataFrame(decomposition)}
    for name, table in outputs.items():
        table.to_csv(OUT / name, index=False)
    s.save(OUT / 'standardization.json', standardization)
    sources = [Path(__file__), OUT / 'design.md', s.CACHE / 'gdd_evi.npz', ROOT / 'outputs/maize_baseline/date_windows.csv', t.OUT / 'verification.json', t.OUT / 'manifest.json', t.OUT / 'predictions.csv']
    s.save(OUT / 'run_complete.json', {'no_training': True, 'matched_repetitions': 20, 'neighbor_k': 5, 'calibration_max': 2000, 'descriptors': NAMES, 'source_sha256': {str(p): s.sha(p) for p in sources}, 'outputs_sha256': {name: s.sha(OUT / name) for name in ['environment_features.csv', 'standardization.json', *outputs]}, 'complete_descriptor_counts': {name: int(np.isfinite(features[:, cols]).all(1).sum()) for name, (cols, _) in DEFS.items()}})
    print('ENVIRONMENT DIAGNOSTICS COMPLETE', flush=True)
if __name__ == '__main__':
    raise SystemExit('Use scripts/train_mainline.py for mainline fitting or the saved-result analysis scripts. This historical entry is retained for method provenance, not default execution.')
