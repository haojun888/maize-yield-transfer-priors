import sys as _sys
from pathlib import Path as _Path
_release_root = _Path(__file__).resolve().parents[2]
_sys.path.insert(0, str(_release_root))
from release_support import configured_path as _configured_path, prepare_transfer as _prepare_transfer
import unittest
import numpy as np
import coverage_analysis as c

class CoverageChecks(unittest.TestCase):

    def test_neighbors_exclude_same_county(self):
        z = np.array([[0.0], [0.1], [10.0], [10.1]], dtype=np.float32)
        counties = np.array(['a', 'a', 'b', 'b'])
        got = c.neighbor_distance(z[:1], z, counties[:1], counties, k=1)
        self.assertAlmostEqual(float(got[0]), 10.0, places=4)
        got = c.neighbor_distance(z[:1], z, k=1)
        self.assertAlmostEqual(float(got[0]), 0.0, places=4)

    def test_year_matching_and_common_scaling(self):
        years = np.array([2004] * 5 + [2005] * 7)
        east = np.array([True, True, False, False, False, True, True, True, False, False, False, False])
        a, b = c.match_years(np.flatnonzero(east), np.flatnonzero(~east), years, np.random.default_rng(42))
        for year in np.unique(years):
            self.assertEqual(sum(years[a] == year), sum(years[b] == year))
        x = np.arange(24, dtype=float).reshape(12, 2)
        fit = np.arange(12) < 8
        z, params = c.standardize(x, fit, [0, 1])
        x[~fit] += 100000
        _, other = c.standardize(x, fit, [0, 1])
        self.assertEqual(params, other)

    def test_bias_decomposition(self):
        error = np.array([1.0, 2.0, 3.0])
        mse, bias2, centered = c.decompose(error)
        self.assertAlmostEqual(mse, bias2 + centered)
if __name__ == '__main__':
    raise SystemExit('Use scripts/train_mainline.py for mainline fitting or the saved-result analysis scripts. This historical entry is retained for method provenance, not default execution.')
