import sys as _sys
from pathlib import Path as _Path
_release_root = _Path(__file__).resolve().parents[2]
_sys.path.insert(0, str(_release_root))
from release_support import configured_path as _configured_path, prepare_transfer as _prepare_transfer
'Approved year-stratified whole-bank-block intervention; never edit old runs.'
import argparse
import hashlib
import json
import sys
import time
from pathlib import Path
import numpy as np
import pandas as pd
import torch
OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
CACHE = ROOT / 'work/maize_group_interventions'
GAIN = ROOT / 'outputs/maize_gain_sources'
sys.path.insert(0, str(ROOT / 'outputs/maize_fusion_transfer'))
import transfer as t
s = t.s
ARMS = ['optical', 'weather', 'independent', 'paired']
METHODS = ['sobol_fixed'] + [f'random_{j:02d}' for j in range(20)]
SEEDS = [42, 2026, 3407]
OPTICAL = [3, 5]
WEATHER = [0, 1, 2, 4]

def donor_map(years, rows, seed):
    rows = np.asarray(rows, dtype=np.int64)
    donors = rows.copy()
    rng = np.random.default_rng(seed)
    for year in np.unique(years[rows]):
        local = np.flatnonzero(years[rows] == year)
        if len(local) < 2:
            raise ValueError('Year stratum has no alternative donor')
        while True:
            permuted = rng.permutation(rows[local])
            if np.all(permuted != rows[local]):
                donors[local] = permuted
                break
    return donors

def intervene(bank, rows, optical_donors, weather_donors, arm):
    if arm not in ARMS:
        raise ValueError(arm)
    result = bank.copy()
    if arm in ['optical', 'independent', 'paired']:
        for j in OPTICAL:
            result[rows, j] = bank[optical_donors, j]
    if arm in ['weather', 'independent', 'paired']:
        donors = optical_donors if arm == 'paired' else weather_donors
        for j in WEATHER:
            result[rows, j] = bank[donors, j]
    return result

def mapping_seed(rep, scope, block):
    return 20261010 + rep * 10000 + {'train': 10, 'val': 20, 'fit': 30, 'joint': 40}[scope] + block

def read_json(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))

def prepare():
    CACHE.mkdir(parents=True, exist_ok=True)
    path = OUT / 'manifest.json'
    if path.exists():
        manifest = read_json(path)
        for file, digest in manifest['sha256'].items():
            assert s.sha(file) == digest, file
        return manifest
    gv = read_json(GAIN / 'verification.json')
    tv = read_json(t.OUT / 'verification.json')
    assert gv['verified'] and tv['verified']
    dependencies = {}
    for verification in [gv, tv]:
        for file, digest in verification['model_sha256'].items():
            assert s.sha(file) == digest, file
            dependencies[file] = digest
    for folder, verification, key in [(GAIN, gv, 'output_sha256'), (t.OUT, tv, 'outputs_sha256')]:
        for name, digest in verification[key].items():
            file = str(folder / name)
            assert s.sha(file) == digest, file
            dependencies[file] = digest
    gm = read_json(GAIN / 'manifest.json')
    for file, digest in gm['sha256'].items():
        assert s.sha(file) == digest, file
        dependencies[file] = digest
    files = [Path(__file__), OUT / 'design.md', OUT / 'test_interventions.py', GAIN / 'verification.json', t.OUT / 'verification.json', ROOT / 'work/maize_environment_coverage/weather_calendar__fusion_2019__E_to_W__joint.npz']
    for file in files:
        dependencies[str(file)] = s.sha(file)
    fingerprint = hashlib.sha256(json.dumps(dependencies, sort_keys=True).encode()).hexdigest()
    manifest = {'fingerprint': fingerprint, 'sha256': dependencies, 'protocol': 'E_to_W', 'scenario': 'joint', 'seeds': SEEDS, 'arms': ARMS, 'methods': METHODS, 'target_repeats': 20, 'refit_repeats': 3, 'selection_models': 756, 'final_models': 756, 'orders': gm['orders'], 'target_tuning': False, 'primary': 'original frozen high environment distance bin', 'scope': 'year-stratified county-to-block alignment in frozen bank'}
    s.save(path, manifest)
    return manifest

def load_context(seed):
    folder = t.OUT / f'gdd_evi__E_to_W_{seed}'
    marker = read_json(folder / 'teacher_complete.json')
    for name, digest in marker['sha256'].items():
        assert s.sha(folder / name) == digest, name
    data = np.load(s.CACHE / 'gdd_evi.npz')
    split = np.load(t.OUT / 'split_E_to_W.npz')
    bank = np.load(folder / 'bank.npy')
    ck = torch.load(folder / 'teacher.pt', weights_only=True, map_location='cpu')
    teacher = s.Teacher(ck['width'], ck['groups']).to(s.DEVICE)
    teacher.load_state_dict(ck['state_dict'])
    teacher.eval()
    for parameter in teacher.parameters():
        parameter.requires_grad_(False)
    models = read_json(t.OUT / 'background_E_to_W.json')
    bg = {phase: s.e.background_predict(model, data['years'], data['counties']) for phase, model in models.items()}
    residual = {phase: (data['y'] - values).astype(np.float32) for phase, values in bg.items()}
    prior = np.array(read_json(folder / 'priors.json')['prior'])
    return (data, split, teacher, bank, bg, residual, prior)

def priors(prior, manifest):
    return [prior] + [prior[order] for order in manifest['orders']]

def maps(data, rows, rep, scope):
    path = CACHE / f'donors_{scope}_{rep:02d}.npz'
    expected = {block: donor_map(data['years'], rows, mapping_seed(rep, scope, j)) for j, block in enumerate(['optical', 'weather'])}
    if path.exists():
        saved = np.load(path)
        np.testing.assert_array_equal(saved['rows'], rows)
        for block in expected:
            np.testing.assert_array_equal(saved[block], expected[block])
    else:
        np.savez_compressed(path, rows=rows, **expected)
    return (expected['optical'], expected['weather'])

def changed_bank(data, split, bank, rep, arm, scopes):
    result = bank.copy()
    for scope in scopes:
        rows = np.flatnonzero(split[scope])
        optical, weather = maps(data, rows, rep, scope)
        result = intervene(result, rows, optical, weather, arm)
    return result

def old_checkpoint(seed, method):
    if method == 'sobol_fixed':
        return t.OUT / f'gdd_evi__E_to_W_{seed}/final_sobol_fixed.pt'
    return GAIN / f'E_to_W_{seed}/final_{method}.pt'

def baseline(manifest):
    path = OUT / 'baseline_predictions.npz'
    if path.exists():
        return
    saved = pd.read_csv(GAIN / 'all_predictions.csv', dtype={'adm_id': str})
    predictions = []
    for seed in SEEDS:
        data, split, teacher, bank, bg, residual, prior = load_context(seed)
        rows = np.flatnonzero(split['joint'])
        values = []
        for method, expected_prior in zip(METHODS, priors(prior, manifest)):
            ck = torch.load(old_checkpoint(seed, method), weights_only=True, map_location='cpu')
            model = s.Fusion(teacher.head, 'fixed', expected_prior).to(s.DEVICE)
            model.load_state_dict(ck['state_dict'])
            np.testing.assert_allclose(model.prior.cpu().numpy(), expected_prior, atol=1e-07)
            prediction, _ = s.predict(model, bank[rows], ck['target_mean'], ck['target_std'])
            prediction = prediction + bg['final_fit'][rows]
            frame = saved[(saved.protocol == 'E_to_W') & (saved.scenario == 'joint') & (saved.seed == seed) & (saved.variant == method)]
            np.testing.assert_array_equal(frame.adm_id.to_numpy(), data['counties'][rows])
            np.testing.assert_array_equal(frame.year.to_numpy(), data['years'][rows])
            np.testing.assert_allclose(frame.predicted_yield_t_ha, prediction, atol=2e-06, rtol=2e-06)
            values.append(prediction)
        predictions.append(values)
    distance = np.load(ROOT / 'work/maize_environment_coverage/weather_calendar__fusion_2019__E_to_W__joint.npz')
    np.testing.assert_array_equal(rows, distance['target_rows'])
    np.savez_compressed(path, predictions=np.array(predictions, dtype=np.float32), rows=rows, years=data['years'][rows], counties=data['counties'][rows], y=data['y'][rows], bins=distance['binid'], background=bg['final_fit'][rows])
    s.save(OUT / 'baseline_verification.json', {'verified': True, 'reloaded_existing_models': 63, 'matches_existing_predictions': True})

def target_probe(manifest):
    start = time.time()
    for seed in SEEDS:
        data, split, teacher, bank, bg, residual, prior = load_context(seed)
        rows = np.flatnonzero(split['joint'])
        for method, expected_prior in zip(METHODS, priors(prior, manifest)):
            destination = CACHE / f'probe_{seed}_{method}.npz'
            if destination.exists():
                assert str(np.load(destination)['fingerprint']) == manifest['fingerprint']
                continue
            ck = torch.load(old_checkpoint(seed, method), weights_only=True, map_location='cpu')
            model = s.Fusion(teacher.head, 'fixed', expected_prior).to(s.DEVICE)
            model.load_state_dict(ck['state_dict'])
            predictions = np.empty((20, 4, len(rows)), dtype=np.float32)
            for rep in range(20):
                optical, weather = maps(data, rows, rep, 'joint')
                for j, arm in enumerate(ARMS):
                    changed = intervene(bank, rows, optical, weather, arm)
                    prediction, _ = s.predict(model, changed[rows], ck['target_mean'], ck['target_std'])
                    predictions[rep, j] = prediction + bg['final_fit'][rows]
            np.savez_compressed(destination, predictions=predictions, fingerprint=manifest['fingerprint'])
        print('PROBE COMPLETE', seed, round(time.time() - start, 1), flush=True)
    s.save(OUT / 'probe_complete.json', {'fingerprint': manifest['fingerprint'], 'target_prediction_cases': 5040, 'new_training': 0})

def refit(manifest):
    start = time.time()
    candidate_rows = []
    for seed in SEEDS:
        data, split, teacher, bank, bg, residual, prior = load_context(seed)
        for rep in range(3):
            for arm in ARMS:
                changed = changed_bank(data, split, bank, rep, arm, ['train', 'val'])
                folder = OUT / f'{seed}_{rep}_{arm}'
                folder.mkdir(exist_ok=True)
                for method, expected_prior in zip(METHODS, priors(prior, manifest)):
                    path = folder / f'selection_{method}.pt'
                    meta_path = folder / f'selection_{method}.json'
                    if not (path.exists() and meta_path.exists()):
                        model, ym, ys, epoch, history, score = s.train(teacher.head, 'fixed', expected_prior, 0.0, changed, residual['selection'], split['train'], split['val'], seed)
                        torch.save({'state_dict': model.cpu().state_dict(), 'prior': expected_prior.tolist(), 'target_mean': ym, 'target_std': ys, 'epoch': epoch, 'fingerprint': manifest['fingerprint'], 'parameters': 577}, path)
                        s.save(meta_path, {'seed': seed, 'rep': rep, 'arm': arm, 'method': method, 'epoch': epoch, 'val_rmse': score, 'fingerprint': manifest['fingerprint']})
                        pd.DataFrame(history).to_csv(folder / f'selection_{method}_history.csv', index=False)
                    meta = read_json(meta_path)
                    assert meta['fingerprint'] == manifest['fingerprint']
                    candidate_rows.append(meta)
                print('SELECTION', seed, rep, arm, len(candidate_rows), round(time.time() - start, 1), flush=True)
    assert len(candidate_rows) == 756
    pd.DataFrame(candidate_rows).to_csv(OUT / 'validation_candidates.csv', index=False)
    s.save(OUT / 'selection_complete.json', {'fingerprint': manifest['fingerprint'], 'selection_models': 756, 'refit_target_predictions_started': False, 'prior_probe_was_preplanned_and_has_no_selection_role': True})
    count = 0
    for seed in SEEDS:
        data, split, teacher, bank, bg, residual, prior = load_context(seed)
        rows = np.flatnonzero(split['joint'])
        for rep in range(3):
            for arm in ARMS:
                changed = changed_bank(data, split, bank, rep, arm, ['fit', 'joint'])
                folder = OUT / f'{seed}_{rep}_{arm}'
                predictions = []
                for method, expected_prior in zip(METHODS, priors(prior, manifest)):
                    meta = read_json(folder / f'selection_{method}.json')
                    path = folder / f'final_{method}.pt'
                    if not path.exists():
                        model, ym, ys = t.fit_final(teacher.head, 'fixed', expected_prior, 0.0, changed, residual['final_fit'], split['fit'], seed, meta['epoch'])
                        torch.save({'state_dict': model.cpu().state_dict(), 'prior': expected_prior.tolist(), 'target_mean': ym, 'target_std': ys, 'epoch': meta['epoch'], 'fingerprint': manifest['fingerprint'], 'parameters': 577}, path)
                    ck = torch.load(path, weights_only=True, map_location='cpu')
                    assert ck['fingerprint'] == manifest['fingerprint'] and ck['epoch'] == meta['epoch']
                    model = s.Fusion(teacher.head, 'fixed', expected_prior).to(s.DEVICE)
                    model.load_state_dict(ck['state_dict'])
                    prediction, _ = s.predict(model, changed[rows], ck['target_mean'], ck['target_std'])
                    predictions.append(prediction + bg['final_fit'][rows])
                    count += 1
                np.savez_compressed(CACHE / f'refit_{seed}_{rep}_{arm}.npz', predictions=np.array(predictions, dtype=np.float32), fingerprint=manifest['fingerprint'])
                print('FINAL', seed, rep, arm, count, round(time.time() - start, 1), flush=True)
    assert count == 756
    s.save(OUT / 'run_complete.json', {'fingerprint': manifest['fingerprint'], 'selection_models': 756, 'final_models': 756, 'reused_teachers': 3, 'runtime_seconds': time.time() - start})
if __name__ == '__main__':
    raise SystemExit('Use scripts/train_mainline.py for mainline fitting or the saved-result analysis scripts. This historical entry is retained for method provenance, not default execution.')
