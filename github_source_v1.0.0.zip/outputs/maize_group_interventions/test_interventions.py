import sys as _sys
from pathlib import Path as _Path
_release_root = _Path(__file__).resolve().parents[2]
_sys.path.insert(0, str(_release_root))
from release_support import configured_path as _configured_path, prepare_transfer as _prepare_transfer
'Catch cross-split donors, broken optical/weather blocks and in-place edits.'
import importlib.util
import unittest
import numpy as np

class InterventionContract(unittest.TestCase):

    def test_year_split_isolation_and_block_integrity(self):
        self.assertIsNotNone(importlib.util.find_spec('interventions'), 'The approved block intervention is not implemented')
        from interventions import donor_map, intervene
        years = np.repeat([2004, 2005, 2020, 2021], 8)
        rows = np.arange(16)
        p = donor_map(years, rows, 123)
        q = donor_map(years, rows, 456)
        np.testing.assert_array_equal(np.sort(p), rows)
        np.testing.assert_array_equal(years[p], years[rows])
        self.assertTrue(np.all(p != rows))
        self.assertFalse(np.array_equal(p, q))
        bank = np.arange(32 * 7 * 2).reshape(32, 7, 2).astype(np.float32)
        original = bank.copy()
        for arm in ['optical', 'weather', 'independent', 'paired']:
            changed = intervene(bank, rows, p, q, arm)
            np.testing.assert_array_equal(changed[16:], original[16:])
            np.testing.assert_array_equal(changed[:, 6], original[:, 6])
            for j in [3, 5]:
                donor = p if arm in ['optical', 'independent', 'paired'] else rows
                np.testing.assert_array_equal(changed[rows, j], original[donor, j])
            for j in [0, 1, 2, 4]:
                donor = p if arm == 'paired' else q if arm in ['weather', 'independent'] else rows
                np.testing.assert_array_equal(changed[rows, j], original[donor, j])
        np.testing.assert_array_equal(bank, original)
        np.testing.assert_array_equal(p, donor_map(years, rows, 123))
if __name__ == '__main__':
    raise SystemExit('Use scripts/train_mainline.py for mainline fitting or the saved-result analysis scripts. This historical entry is retained for method provenance, not default execution.')
