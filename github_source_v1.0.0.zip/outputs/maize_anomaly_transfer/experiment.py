import sys as _sys
from pathlib import Path as _Path
_release_root = _Path(__file__).resolve().parents[2]
_sys.path.insert(0, str(_release_root))
from release_support import configured_path as _configured_path, prepare_transfer as _prepare_transfer
'Source-only background and transfer experiments; see protocol.md.'
import argparse
import hashlib
import json
import os
import sys
import time
from pathlib import Path
import joblib
import numpy as np
import pandas as pd
import torch
from sklearn.ensemble import RandomForestRegressor
OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
BASE = ROOT / 'outputs/maize_baseline'
sys.path.insert(0, str(BASE))
from pipeline import CACHE, prepare_arrays
from train import metrics, linear_coefficients, fit_lstm, predict, SEEDS
from summarize import reference_skill
EAST = {'17', '18', '26', '39', '55'}
WEST = {'19', '20', '27', '29', '31', '38', '46'}
RF_JOBS = int(os.environ.get('MAIZE_RF_JOBS', '1'))

def make_split(years, counties, protocol):
    states = np.array([c.split('-')[1] for c in counties])
    if protocol == 'T':
        source = np.ones(len(years), dtype=bool)
        target = np.zeros(len(years), dtype=bool)
    else:
        source = np.isin(states, list(EAST if protocol == 'E_to_W' else WEST))
        target = np.isin(states, list(WEST if protocol == 'E_to_W' else EAST))
        assert set(counties[source]).isdisjoint(set(counties[target]))
    result = {'train': source & (years <= 2016), 'val': source & (years >= 2017) & (years <= 2019), 'fit': source & (years <= 2019)}
    if protocol == 'T':
        result['time'] = years >= 2020
    else:
        result.update({'space': target & (years <= 2019), 'joint': target & (years >= 2020)})
    assert not (result['train'] & result['val']).any()
    for name in ['time', 'space', 'joint']:
        if name in result:
            assert not (result['fit'] & result[name]).any()
    return result

def fit_background(y, years, counties, fit_mask, kind, scope):
    if not fit_mask.any():
        raise ValueError('Empty background training set')
    if kind == 'raw':
        return {'kind': 'raw', 'scope': scope, 'global': [0.0, 0.0], 'county': {}}
    coefficient = linear_coefficients(years[fit_mask] - 2000, y[fit_mask]) if kind == 'trend' else [0.0, float(np.mean(y[fit_mask], dtype=np.float64))]
    lookup = {}
    if scope == 'county':
        for county in np.unique(counties[fit_mask]):
            chosen = fit_mask & (counties == county)
            if kind == 'mean':
                coef = [0.0, float(np.mean(y[chosen], dtype=np.float64))]
            elif chosen.sum() >= 3:
                coef = linear_coefficients(years[chosen] - 2000, y[chosen])
            else:
                coef = coefficient
            lookup[str(county)] = [float(v) for v in coef]
    return {'kind': kind, 'scope': scope, 'global': [float(v) for v in coefficient], 'county': lookup, 'fit_rows': int(fit_mask.sum()), 'fit_year_min': int(years[fit_mask].min()), 'fit_year_max': int(years[fit_mask].max())}

def background_predict(background, years, counties):
    return np.array([coef[0] * (int(year) - 2000) + coef[1] for year, county in zip(years, counties) for coef in [background['county'].get(str(county), background['global'])]], dtype=np.float64)

def save_json(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False), encoding='utf-8')

def prediction_frames(protocol, kind, model, seed, predictions, evals, y, years, counties, background, meanref, trendref):
    frames = []
    for scenario, mask in evals.items():
        p = predictions[scenario]
        frames.append(pd.DataFrame({'protocol': protocol, 'scenario': scenario, 'training_target': kind, 'model': model, 'seed': seed, 'adm_id': counties[mask], 'year': years[mask], 'observed_yield_t_ha': y[mask], 'predicted_yield_t_ha': p, 'background_t_ha': background[mask], 'mean_reference_t_ha': meanref[mask], 'trend_reference_t_ha': trendref[mask]}))
    return frames

def run_case(protocol, kind, data, split, fingerprint):
    folder = OUT / f'{protocol}__{kind}'
    folder.mkdir(exist_ok=True)
    done = folder / 'complete.json'
    if done.exists():
        state = json.loads(done.read_text(encoding='utf-8'))
        if state.get('fingerprint') == fingerprint:
            print('Verified cache reuse', folder.name, flush=True)
            return pd.read_csv(folder / 'predictions.csv')
        raise ValueError(f'Existing case {folder.name} does not match code/data fingerprint; preserve it before rerunning')
    x, static, lengths, y, years, counties = data
    evals = {k: v for k, v in split.items() if k in ['time', 'space', 'joint']}
    scope = 'county' if protocol == 'T' else 'source'
    selection_bg = fit_background(y, years, counties, split['train'], kind, scope)
    final_bg = fit_background(y, years, counties, split['fit'], kind, scope)
    bsel = background_predict(selection_bg, years, counties)
    bfinal = background_predict(final_bg, years, counties)
    yrsel = (y - bsel).astype(np.float32)
    yrfinal = (y - bfinal).astype(np.float32)
    refs = {k: background_predict(fit_background(y, years, counties, split['fit'], k, scope), years, counties) for k in ['mean', 'trend']}
    seq, st, selection_params = prepare_arrays(x, static, lengths, split['train'])
    fs, fst, final_params = prepare_arrays(x, static, lengths, split['fit'])
    table = np.concatenate([seq.reshape(len(y), -1), st], axis=1)
    ftable = np.concatenate([fs.reshape(len(y), -1), fst], axis=1)
    save_json(folder / 'background.json', {'selection': selection_bg, 'final_fit': final_bg})
    save_json(folder / 'preprocessing.json', {'selection': selection_params, 'final_fit': final_params})
    frames = []
    selection = []
    histories = []
    for name, ref in refs.items():
        frames.extend(prediction_frames(protocol, kind, 'background_' + name, -1, {k: ref[m] for k, m in evals.items()}, evals, y, years, counties, bfinal, refs['mean'], refs['trend']))
    if protocol == 'T' and kind == 'raw':
        original = pd.read_csv(BASE / 'test_predictions.csv')
        for name in ['RF', 'LSTM']:
            for seed in SEEDS:
                p = original[(original.model == name) & (original.seed == seed)].set_index(['adm_id', 'year']).predicted_yield_t_ha
                mask = evals['time']
                keys = pd.MultiIndex.from_arrays([counties[mask], years[mask]])
                values = p.reindex(keys).to_numpy()
                assert np.isfinite(values).all()
                frames.extend(prediction_frames(protocol, kind, name, seed, {'time': values}, evals, y, years, counties, bfinal, refs['mean'], refs['trend']))
        save_json(folder / 'model_reuse.json', {'source': str(BASE), 'reason': 'Unchanged raw temporal baseline; no refit or retuning'})
    elif protocol != 'T' and kind == 'mean':
        raw = pd.read_csv(OUT / f'{protocol}__raw' / 'predictions.csv')
        for name in ['RF', 'LSTM']:
            for seed in SEEDS:
                predictions = {}
                for scenario, mask in evals.items():
                    p = raw[(raw.model == name) & (raw.seed == seed) & (raw.scenario == scenario)].set_index(['adm_id', 'year']).predicted_yield_t_ha
                    predictions[scenario] = p.reindex(pd.MultiIndex.from_arrays([counties[mask], years[mask]])).to_numpy()
                frames.extend(prediction_frames(protocol, kind, name, seed, predictions, evals, y, years, counties, bfinal, refs['mean'], refs['trend']))
        save_json(folder / 'model_reuse.json', {'source': str(OUT / f'{protocol}__raw'), 'reason': 'Constant source-mean target centering is an algebraic equivalence control, not another fitted model'})
    else:
        for leaf in [5, 20]:
            rf = RandomForestRegressor(n_estimators=300, max_depth=20, max_features=0.75, min_samples_leaf=leaf, n_jobs=RF_JOBS, random_state=42)
            rf.fit(table[split['train']], yrsel[split['train']])
            p = rf.predict(table[split['val']]) + bsel[split['val']]
            score = {'model': 'RF', 'min_samples_leaf': leaf, **metrics(y[split['val']], p)}
            selection.append(score)
            del rf
            print(folder.name, 'RF validation', score, flush=True)
        leaf = min(selection, key=lambda r: r['rmse_t_ha'])['min_samples_leaf']
        for seed in SEEDS:
            rf = RandomForestRegressor(n_estimators=300, max_depth=20, max_features=0.75, min_samples_leaf=leaf, n_jobs=RF_JOBS, random_state=seed)
            rf.fit(ftable[split['fit']], yrfinal[split['fit']])
            preds = {k: rf.predict(ftable[m]) + bfinal[m] for k, m in evals.items()}
            frames.extend(prediction_frames(protocol, kind, 'RF', seed, preds, evals, y, years, counties, bfinal, refs['mean'], refs['trend']))
            joblib.dump(rf, folder / f'rf_{seed}.joblib', compress=3)
            del rf
            print(folder.name, 'RF saved', seed, flush=True)
        for seed in SEEDS:
            model, ym, ys, bestepoch, history = fit_lstm(seq, st, lengths, yrsel, split['train'], split['val'], seed)
            p = predict(model, seq, st, lengths, split['val'], ym, ys) + bsel[split['val']]
            selection.append({'model': 'LSTM', 'seed': seed, 'best_epoch': bestepoch, **metrics(y[split['val']], p)})
            for row in history:
                row.update({'stage': 'selection', 'training_target': kind})
            histories.extend(history)
            del model
            model, ym, ys, _, history = fit_lstm(fs, fst, lengths, yrfinal, split['fit'], None, seed, epochs=bestepoch)
            for row in history:
                row.update({'stage': 'final_fit', 'training_target': kind})
            histories.extend(history)
            preds = {k: predict(model, fs, fst, lengths, m, ym, ys) + bfinal[m] for k, m in evals.items()}
            frames.extend(prediction_frames(protocol, kind, 'LSTM', seed, preds, evals, y, years, counties, bfinal, refs['mean'], refs['trend']))
            torch.save({'state_dict': model.cpu().state_dict(), 'dynamic_dim': fs.shape[-1], 'static_dim': fst.shape[-1], 'target_mean': ym, 'target_std': ys, 'seed': seed, 'epochs': bestepoch, 'training_target': kind}, folder / f'lstm_{seed}.pt')
            del model
            pd.DataFrame(histories).to_csv(folder / 'history.csv', index=False)
            print(folder.name, 'LSTM saved', seed, flush=True)
    result = pd.concat(frames, ignore_index=True)
    assert not result.duplicated(['scenario', 'model', 'seed', 'adm_id', 'year']).any()
    result.to_csv(folder / 'predictions.csv', index=False)
    save_json(folder / 'selection.json', selection)
    save_json(done, {'fingerprint': fingerprint, 'protocol': protocol, 'training_target': kind, 'scope': scope, 'seeds': SEEDS, 'n_train': int(split['train'].sum()), 'n_val': int(split['val'].sum()), 'n_final_fit': int(split['fit'].sum()), 'evaluations': {k: int(m.sum()) for k, m in evals.items()}})
    return result

def summarize(frames):
    pred = pd.concat(frames, ignore_index=True)
    pred.to_csv(OUT / 'all_predictions.csv', index=False)
    rows = []
    grouping = ['protocol', 'scenario', 'training_target', 'model', 'seed']
    for key, df in pred.groupby(grouping):
        meta = dict(zip(grouping, key))
        y = df.observed_yield_t_ha.to_numpy()
        p = df.predicted_yield_t_ha.to_numpy()
        score = {**meta, 'period': 'pooled', **metrics(y, p), 'skill_vs_mean': reference_skill(y, p, df.mean_reference_t_ha.to_numpy()), 'skill_vs_trend': reference_skill(y, p, df.trend_reference_t_ha.to_numpy())}
        rows.append(score)
        for year, annual in df.groupby('year'):
            rows.append({**meta, 'period': str(year), **metrics(annual.observed_yield_t_ha.to_numpy(), annual.predicted_yield_t_ha.to_numpy())})
    scores = pd.DataFrame(rows)
    scores.to_csv(OUT / 'metrics.csv', index=False)
    pooled = scores[scores.period == 'pooled']
    summary = pooled.groupby(grouping[:-1]).agg(n=('n', 'first'), r2_mean=('r2', 'mean'), r2_seed_sd=('r2', 'std'), rmse_mean=('rmse_t_ha', 'mean'), rmse_seed_sd=('rmse_t_ha', 'std'), mae_mean=('mae_t_ha', 'mean'), bias_mean=('bias_t_ha', 'mean'), skill_vs_mean=('skill_vs_mean', 'mean'), skill_vs_trend=('skill_vs_trend', 'mean')).reset_index()
    summary.to_csv(OUT / 'summary.csv', index=False)
    print(summary.to_string(index=False), flush=True)

def run():
    start = time.time()
    d = np.load(CACHE / 'dataset.npz')
    data = tuple((d[k] for k in ['x', 'static', 'lengths', 'y', 'years', 'counties']))
    x, static, lengths, y, years, counties = data
    fingerprint = hashlib.sha256((hashlib.sha256((CACHE / 'dataset.npz').read_bytes()).hexdigest() + hashlib.sha256(Path(__file__).read_bytes()).hexdigest() + hashlib.sha256((BASE / 'train.py').read_bytes()).hexdigest() + hashlib.sha256((BASE / 'pipeline.py').read_bytes()).hexdigest()).encode()).hexdigest()
    frames = []
    for protocol in ['T', 'E_to_W', 'W_to_E']:
        split = make_split(years, counties, protocol)
        roles = pd.DataFrame({'adm_id': counties, 'year': years, **split})
        roles.to_csv(OUT / f'{protocol}_split_manifest.csv', index=False)
        print('Frozen split', protocol, {k: int(v.sum()) for k, v in split.items()}, flush=True)
        for kind in ['raw', 'mean', 'trend']:
            frames.append(run_case(protocol, kind, data, split, fingerprint))
    summarize(frames)
    save_json(OUT / 'run_complete.json', {'fingerprint': fingerprint, 'seconds_this_run': time.time() - start, 'seeds': SEEDS, 'protocols': ['T', 'E_to_W', 'W_to_E'], 'model_case_count': 9, 'no_target_label_fitting': True})
if __name__ == '__main__':
    raise SystemExit('Use scripts/train_mainline.py for mainline fitting or the saved-result analysis scripts. This historical entry is retained for method provenance, not default execution.')
