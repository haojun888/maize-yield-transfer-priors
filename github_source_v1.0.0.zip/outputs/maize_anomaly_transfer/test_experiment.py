import sys as _sys
from pathlib import Path as _Path
_release_root = _Path(__file__).resolve().parents[2]
_sys.path.insert(0, str(_release_root))
from release_support import configured_path as _configured_path, prepare_transfer as _prepare_transfer
import unittest
import numpy as np
import experiment

class IsolationTests(unittest.TestCase):

    def test_target_labels_do_not_change_background(self):
        self.assertTrue(hasattr(experiment, 'fit_background'), 'fit_background missing')
        y = np.array([4.0, 6.0, 8.0, 999.0, 999.0])
        years = np.array([2004, 2005, 2006, 2007, 2007])
        counties = np.array(['A', 'A', 'A', 'A', 'B'])
        fit = np.array([True, True, True, False, False])
        for scope in ['county', 'source']:
            for kind in ['mean', 'trend']:
                b = experiment.fit_background(y, years, counties, fit, kind, scope)
                changed = y.copy()
                changed[~fit] = -100000.0
                c = experiment.fit_background(changed, years, counties, fit, kind, scope)
                np.testing.assert_allclose(experiment.background_predict(b, years, counties), experiment.background_predict(c, years, counties))
                if kind == 'trend':
                    self.assertAlmostEqual(experiment.background_predict(b, years, counties)[-1], 10.0)

    def test_disjoint_regions_and_future_period(self):
        self.assertTrue(hasattr(experiment, 'make_split'), 'make_split missing')
        years = np.array([2016, 2018, 2021, 2010, 2021])
        counties = np.array(['US-17-001', 'US-17-001', 'US-17-001', 'US-19-001', 'US-19-001'])
        split = experiment.make_split(years, counties, 'E_to_W')
        np.testing.assert_array_equal(split['train'], [True, False, False, False, False])
        np.testing.assert_array_equal(split['val'], [False, True, False, False, False])
        np.testing.assert_array_equal(split['space'], [False, False, False, True, False])
        np.testing.assert_array_equal(split['joint'], [False, False, False, False, True])
        self.assertFalse(set(counties[split['fit']]) & set(counties[split['space'] | split['joint']]))

    def test_background_only_fit_rows(self):
        self.assertTrue(hasattr(experiment, 'fit_background'), 'fit_background missing')
        y = np.array([2.0, 4.0, 1000.0])
        yr = np.array([2004, 2005, 2006])
        county = np.array(['A', 'A', 'A'])
        fit = np.array([True, True, False])
        b = experiment.fit_background(y, yr, county, fit, 'mean', 'source')
        np.testing.assert_allclose(experiment.background_predict(b, yr, county), [3.0, 3.0, 3.0])
if __name__ == '__main__':
    raise SystemExit('Use scripts/train_mainline.py for mainline fitting or the saved-result analysis scripts. This historical entry is retained for method provenance, not default execution.')
