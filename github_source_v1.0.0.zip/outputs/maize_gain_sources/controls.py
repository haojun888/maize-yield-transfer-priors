import sys as _sys
from pathlib import Path as _Path
_release_root = _Path(__file__).resolve().parents[2]
_sys.path.insert(0, str(_release_root))
from release_support import configured_path as _configured_path, prepare_transfer as _prepare_transfer
'Random fixed distributions and same-start flexibility/capacity controls.'
import hashlib
import json
import sys
import time
from pathlib import Path
import numpy as np
import pandas as pd
import torch
from torch import nn
OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
sys.path.insert(0, str(ROOT / 'outputs/maize_fusion_transfer'))
import transfer as t
s = t.s
BaseFusion = s.Fusion
PROTOCOLS = ['E_to_W', 'W_to_E']
NEW_MODES = ['global_sobol_init', 'dynamic_sobol_init', 'capacity_sobol_fixed']

class ControlFusion(BaseFusion):

    def __init__(self, template, mode, prior):
        underlying = {'global_sobol_init': 'fixed', 'dynamic_sobol_init': 'learned', 'capacity_sobol_fixed': 'capacity'}[mode]
        super().__init__(template, underlying, prior)
        self.mode = mode
        if mode == 'global_sobol_init':
            self.logits = nn.Parameter(self.prior.log().clone())

    def forward(self, bank, return_weights=False):
        if self.mode == 'global_sobol_init':
            weights = self.logits.softmax(0)[None, :].expand(len(bank), -1)
        elif self.mode == 'dynamic_sobol_init':
            weights = (self.gate(bank.flatten(1)) + self.prior.log()).softmax(1)
        else:
            weights = self.prior[None, :].expand(len(bank), -1)
        value = self.head((bank * weights[:, :, None]).sum(1)).squeeze(1)
        return (value, weights) if return_weights else value

def factory(template, mode, prior):
    return ControlFusion(template, mode, prior) if mode in NEW_MODES else BaseFusion(template, mode, prior)
s.Fusion = factory

def permutation_orders():
    rng = np.random.default_rng(20261009)
    orders = []
    seen = {tuple(range(7))}
    while len(orders) < 20:
        order = tuple((int(i) for i in rng.permutation(7)))
        if order not in seen:
            seen.add(order)
            orders.append(list(order))
    return orders

def specs(prior):
    prior = np.asarray(prior, dtype=float)
    tasks = {f'random_{j:02d}': ('fixed', prior[order], order) for j, order in enumerate(permutation_orders())}
    tasks.update({mode: (mode, prior, None) for mode in NEW_MODES})
    return tasks

def prepare():
    manifest = OUT / 'manifest.json'
    if manifest.exists():
        old = json.loads(manifest.read_text(encoding='utf-8'))
        for path, value in old['sha256'].items():
            if not Path(path).exists() or s.sha(path) != value:
                raise ValueError(f'Frozen dependency changed: {path}')
        return (old['fingerprint'], old['parent_fingerprint'])
    parent = json.loads((t.OUT / 'verification.json').read_text(encoding='utf-8'))
    assert parent['verified']
    for path, value in parent['model_sha256'].items():
        assert s.sha(path) == value
    for name in ['predictions.csv', 'weights.csv', 'summary.csv']:
        assert s.sha(t.OUT / name) == parent['outputs_sha256'][name]
    paths = [Path(__file__), OUT / 'design.md', Path(t.__file__), Path(s.__file__), Path(s.g.__file__), Path(s.e.__file__), s.e.BASE / 'pipeline.py', s.e.BASE / 'train.py', s.CACHE / 'gdd_evi.npz', t.OUT / 'verification.json', t.OUT / 'manifest.json', t.OUT / 'predictions.csv', ROOT / 'outputs/maize_environment_coverage/run_complete.json', ROOT / 'outputs/maize_environment_coverage/verification.json']
    for protocol in PROTOCOLS:
        paths += [t.OUT / f'background_{protocol}.json', t.OUT / f'split_{protocol}.npz']
        for scenario in ['space', 'joint']:
            paths.append(ROOT / f'work/maize_environment_coverage/weather_calendar__fusion_2019__{protocol}__{scenario}.npz')
        for seed in s.SEEDS:
            folder = t.OUT / f'gdd_evi__{protocol}_{seed}'
            paths += [folder / name for name in ['teacher.pt', 'bank.npy', 'preprocessing.json', 'priors.json', 'teacher_complete.json']]
    hashes = {str(p): s.sha(p) for p in paths}
    fp = hashlib.sha256(json.dumps(hashes, sort_keys=True).encode()).hexdigest()
    s.save(manifest, {'fingerprint': fp, 'parent_fingerprint': parent['fingerprint'], 'sha256': hashes, 'orders': permutation_orders(), 'random_vectors_per_case': 20, 'new_modes': NEW_MODES, 'new_selection_models': 138, 'new_final_models': 138, 'new_test_scenarios': 276, 'protocols': PROTOCOLS, 'seeds': s.SEEDS, 'random_target_selection': False})
    return (fp, parent['fingerprint'])

def context(protocol, seed, parent_fp):
    folder = t.OUT / f'gdd_evi__{protocol}_{seed}'
    assert all(((folder / name).exists() for name in ['teacher_complete.json', 'teacher.pt', 'bank.npy', 'priors.json', 'preprocessing.json', 'teacher_history.csv']))
    return t.context('gdd_evi', protocol, seed, parent_fp)

def initial_check(teacher, bank, prior):
    inputs = torch.from_numpy(bank[:128]).to(s.DEVICE)
    baseline = BaseFusion(teacher.head, 'fixed', prior).to(s.DEVICE).eval()
    rows = []
    with torch.no_grad():
        expected = baseline(inputs)
        for mode in NEW_MODES:
            model = ControlFusion(teacher.head, mode, prior).to(s.DEVICE).eval()
            value, w = model(inputs, True)
            torch.testing.assert_close(value, expected, rtol=1e-05, atol=2e-06)
            rows.append({'mode': mode, 'parameters': sum((p.numel() for p in model.parameters())), 'max_initial_output_difference': float((value - expected).abs().max())})
    return rows

def run():
    start = time.time()
    fp, parent_fp = prepare()
    rows = []
    for protocol in PROTOCOLS:
        for seed in s.SEEDS:
            source, d, split, teacher, bank, bg, residual, weights, names = context(protocol, seed, parent_fp)
            folder = OUT / f'{protocol}_{seed}'
            folder.mkdir(exist_ok=True)
            s.save(folder / 'initial_check.json', initial_check(teacher, bank, weights['sobol']))
            for method, (mode, prior, order) in specs(weights['sobol']).items():
                path = folder / f'selection_{method}.pt'
                meta = folder / f'selection_{method}.json'
                if not (path.exists() and meta.exists()):
                    model, ym, ys, epoch, history, score = s.train(teacher.head, mode, prior, 0.0, bank, residual['selection'], split['train'], split['val'], seed)
                    torch.save({'state_dict': model.cpu().state_dict(), 'mode': mode, 'prior': [float(w) for w in prior], 'target_mean': ym, 'target_std': ys, 'epoch': epoch, 'order': order, 'fingerprint': fp, 'parameters': sum((p.numel() for p in model.parameters()))}, path)
                    s.save(meta, {'protocol': protocol, 'seed': seed, 'method': method, 'mode': mode, 'val_rmse': score, 'epoch': epoch, 'fingerprint': fp})
                    pd.DataFrame(history).to_csv(folder / f'selection_{method}_history.csv', index=False)
                    print('CANDIDATE', protocol, seed, method, score, epoch, flush=True)
                ck = torch.load(path, weights_only=True, map_location='cpu')
                assert ck['fingerprint'] == fp
                rows.append(json.loads(meta.read_text(encoding='utf-8')))
    assert len(rows) == 138
    pd.DataFrame(rows).to_csv(OUT / 'validation_candidates.csv', index=False)
    s.save(OUT / 'selection_complete.json', {'fingerprint': fp, 'candidate_models': 138, 'target_predictions_started': False, 'random_vectors_selected_on_target': False})
    frames = []
    weightframes = []
    count = 0
    for protocol in PROTOCOLS:
        for seed in s.SEEDS:
            source, d, split, teacher, bank, bg, residual, weights, names = context(protocol, seed, parent_fp)
            folder = OUT / f'{protocol}_{seed}'
            for method, (mode, prior, order) in specs(weights['sobol']).items():
                meta = json.loads((folder / f'selection_{method}.json').read_text(encoding='utf-8'))
                epoch = meta['epoch']
                path = folder / f'final_{method}.pt'
                if not path.exists():
                    model, ym, ys = t.fit_final(teacher.head, mode, prior, 0.0, bank, residual['final_fit'], split['fit'], seed, epoch)
                    torch.save({'state_dict': model.cpu().state_dict(), 'mode': mode, 'prior': [float(w) for w in prior], 'target_mean': ym, 'target_std': ys, 'epoch': epoch, 'order': order, 'fingerprint': fp, 'parameters': sum((p.numel() for p in model.parameters()))}, path)
                    print('FINAL', protocol, seed, method, epoch, flush=True)
                ck = torch.load(path, weights_only=True, map_location='cpu')
                assert ck['fingerprint'] == fp and ck['epoch'] == epoch
                model = factory(teacher.head, mode, ck['prior']).to(s.DEVICE)
                model.load_state_dict(ck['state_dict'])
                count += 1
                for scenario in ['space', 'joint']:
                    mask = split[scenario]
                    values, w = s.predict(model, bank[mask], ck['target_mean'], ck['target_std'])
                    info = {'protocol': protocol, 'scenario': scenario, 'seed': seed, 'variant': method, 'adm_id': d['counties'][mask], 'year': d['years'][mask]}
                    frames.append(pd.DataFrame({**info, 'observed_yield_t_ha': d['y'][mask], 'predicted_yield_t_ha': values + bg['final_fit'][mask]}))
                    if method in NEW_MODES:
                        weightframes.append(pd.DataFrame({**info, **{name: w[:, j] for j, name in enumerate(names)}}))
    assert count == 138 and len(frames) == 276
    pd.concat(frames, ignore_index=True).to_csv(OUT / 'new_predictions.csv', index=False)
    pd.concat(weightframes, ignore_index=True).to_csv(OUT / 'new_weights.csv', index=False)
    s.save(OUT / 'run_complete.json', {'fingerprint': fp, 'new_selection_models': 138, 'new_final_models': count, 'new_scenario_predictions': len(frames), 'reused_teachers': 6, 'runtime_seconds': time.time() - start})
    print('GAIN SOURCE TRAINING COMPLETE', time.time() - start, flush=True)
if __name__ == '__main__':
    raise SystemExit('Use scripts/train_mainline.py for mainline fitting or the saved-result analysis scripts. This historical entry is retained for method provenance, not default execution.')
