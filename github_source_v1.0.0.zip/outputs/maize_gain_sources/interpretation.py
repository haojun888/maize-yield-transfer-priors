import sys as _sys
from pathlib import Path as _Path
_release_root = _Path(__file__).resolve().parents[2]
_sys.path.insert(0, str(_release_root))
from release_support import configured_path as _configured_path, prepare_transfer as _prepare_transfer
'Source-bound interpretation of the completed gain controls, without fitting.'
import json
import pandas as pd
import controls as c
s = c.s

def run():
    out = c.OUT
    v = json.loads((out / 'verification.json').read_text(encoding='utf-8'))
    assert v['verified']
    for name, value in v['output_sha256'].items():
        assert s.sha(out / name) == value
    summary = pd.read_csv(out / 'summary.csv')
    random = pd.read_csv(out / 'random_distribution.csv')
    drift = pd.read_csv(out / 'weight_drift.csv')
    labels = {'sobol_fixed': 'Sobol固定', 'global_sobol_init': '同起点全局解冻', 'dynamic_sobol_init': '同起点样本解冻', 'capacity_sobol_fixed': '容量匹配固定Sobol', 'uniform': '等权'}
    cases = [('E_to_W', 'space'), ('E_to_W', 'joint'), ('W_to_E', 'space'), ('W_to_E', 'joint')]
    lines = ['# 收益来源：对照实验解读（2026-10-09）', '', '本轮将先验内容、权重是否冻结、参数量尽量分开比较。仍是共享冻结表示、原先源验证和既有留出下的开发对照，不是生态或物理因果证明。', '', '## 结果', '', '三种子平均RMSE，单位t/ha；越低越好。', '', '| 方法 | 东→西空间 | 东→西联合 | 西→东空间 | 西→东联合 |', '|---|---:|---:|---:|---:|']
    for method, label in labels.items():
        values = [summary[(summary.protocol == p) & (summary.scenario == sc) & (summary.variant == method)].iloc[0].rmse_mean for p, sc in cases]
        lines.append('| ' + label + ' | ' + ' | '.join((f'{value:.4f}' for value in values)) + ' |')
    lines += ['', '## 先验信息是否有效', '', '每组随机固定与Sobol固定保持相同权重数值及集中程度，只改变特征组对应；每个分配独立用源验证选择轮数。全部20组目标结果保留，没有在目标侧挑选最佳随机向量。', '', '| 场景/距离 | Sobol固定 | 20组随机中位数 | 优于Sobol的随机数 |', '|---|---:|---:|---:|']
    for protocol, scenario, b in [('E_to_W', 'space', 'overall'), ('E_to_W', 'space', 'high'), ('E_to_W', 'joint', 'overall'), ('E_to_W', 'joint', 'high'), ('W_to_E', 'space', 'overall'), ('W_to_E', 'joint', 'overall')]:
        row = random[(random.protocol == protocol) & (random.scenario == scenario) & (random.distance_bin == b)].iloc[0]
        lines.append(f'| {protocol}/{scenario}/{b} | {row.sobol_rmse:.4f} | {row.random_median:.4f} | {int(row.random_better_count)}/20 |')
    lines += ['', '东→西联合整体及高环境距离组，Sobol均优于19/20随机分配；这是本轮最清楚的先验对应关系信息证据。东→西纯空间高距离组，Sobol处在随机分布中间，不能把该组对等权的收益归为Sobol独有。该20组分布是经验对照，不是正式置乱检验p值。', '', '## 冻结权重是否有作用', '', '全局解冻只增加7个参数，样本解冻和容量匹配固定参数数目相近。所有新对照eval初始预测与小头Sobol固定一致；不含持续KL约束。', '', '| 东→西场景 | 全局解冻−固定 RMSE | 样本解冻−固定 RMSE | 样本解冻−容量匹配固定 RMSE |', '|---|---:|---:|---:|']
    for scenario in ['space', 'joint']:
        frame = summary[(summary.protocol == 'E_to_W') & (summary.scenario == scenario)].set_index('variant')
        differences = [frame.loc['global_sobol_init', 'rmse_mean'] - frame.loc['sobol_fixed', 'rmse_mean'], frame.loc['dynamic_sobol_init', 'rmse_mean'] - frame.loc['sobol_fixed', 'rmse_mean'], frame.loc['dynamic_sobol_init', 'rmse_mean'] - frame.loc['capacity_sobol_fixed', 'rmse_mean']]
        lines.append('| ' + scenario + ' | ' + ' | '.join((f'{value:+.4f}' for value in differences)) + ' |')
    lines += ['', '正值表示解冻更差。即使控制起点和近似参数量，东→西仍表现为固定优于解冻，支持在当前训练协议下限制源域权重调整具有迁移价值。预测头也与权重共同训练，各模型选出的轮数不同；不能单凭此对照认定全部差异由权重漂移单独导致。', '', '## 参数量是否解释收益', '', '东→西容量匹配固定比小头固定更差，因此参数更多并没有带来其优势；容量匹配固定仍优于同容量样本解冻，说明仅用参数数目也解释不了差异。西→东则相反：解冻或扩大预测头相对Sobol小头固定有所改善；在三个同起点新对照中，联合留出容量匹配固定最低。固定约束不是普适收益，西→东空间等权仍优于所有Sobol起点新对照。', '', '## 权重变化的辅助证据', '', '东→西全局解冻对原先验的平均L1变化约0.231，样本解冻约0.75；西→东全局解冻约0.039，样本解冻约0.56。固定容量控制的权重没有改变，数值约1e-8的差异来自浮点表示。样本标准差用float64计算，避免常量float32权重产生伪波动。', '', '## 研究判断', '', '现有证据支持条件性的先验价值：在东→西联合时空、尤其环境支持较弱的目标样本中，Sobol对应关系比多数随机对应更有利，保留该先验也比自由调整更稳。纯空间高环境距离组的一部分收益可能来自一般非等权固定组合，而非Sobol特有信息。下一步应针对联合高距离组检验哪些特征组提供稳定信息，并保留随机映射和参数/起点控制。', '', '不能直接从高光学权重推断光学组解释了全部收益，因为两方向先验都偏重光学，却存在相反的性能变化。建议下一轮对光学和气象组的对应关系做预定干预或有控制的消融，再检验结果，而不是仅依据权重大小归因。', '', '模型与场景重载核验均通过，详见verification.json及结果报告.md。区间为县聚类描述性比较，未处理所有共同年份冲击或多重比较。']
    (out / '收益来源解读.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')
    s.save(out / 'interpretation_verification.json', {'verified_model_results_sha256': s.sha(out / 'verification.json'), 'interpretation_sha256': s.sha(out / '收益来源解读.md'), 'interpretation_code_sha256': s.sha(__file__)})
if __name__ == '__main__':
    raise SystemExit('Use scripts/train_mainline.py for mainline fitting or the saved-result analysis scripts. This historical entry is retained for method provenance, not default execution.')
