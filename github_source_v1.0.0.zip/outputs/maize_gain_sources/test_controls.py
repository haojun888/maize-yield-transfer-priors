import sys as _sys
from pathlib import Path as _Path
_release_root = _Path(__file__).resolve().parents[2]
_sys.path.insert(0, str(_release_root))
from release_support import configured_path as _configured_path, prepare_transfer as _prepare_transfer
import unittest
import numpy as np
import torch
import controls as c

class ControlChecks(unittest.TestCase):

    def test_same_initial_function_and_parameter_controls(self):
        torch.manual_seed(42)
        head = torch.nn.Sequential(torch.nn.Linear(16, 32), torch.nn.ReLU(), torch.nn.Dropout(0.1), torch.nn.Linear(32, 1))
        prior = np.array([0.05, 0.2, 0.1, 0.15, 0.05, 0.3, 0.15])
        bank = torch.randn(12, 7, 16)
        baseline = c.BaseFusion(head, 'fixed', prior).eval()
        expected = baseline(bank)
        counts = {}
        for mode in c.NEW_MODES:
            model = c.ControlFusion(head, mode, prior).eval()
            value, w = model(bank, True)
            torch.testing.assert_close(value, expected, rtol=1e-05, atol=1e-06)
            torch.testing.assert_close(w, torch.tensor(prior, dtype=torch.float32)[None, :].expand(12, -1))
            counts[mode] = sum((p.numel() for p in model.parameters()))
        self.assertEqual(counts['global_sobol_init'], 584)
        self.assertLessEqual(abs(counts['dynamic_sobol_init'] - counts['capacity_sobol_fixed']), 9)

    def test_unique_permutations_preserve_concentration(self):
        orders = c.permutation_orders()
        self.assertEqual(len(orders), 20)
        self.assertEqual(len(set(map(tuple, orders))), 20)
        prior = np.array([0.05, 0.2, 0.1, 0.15, 0.05, 0.3, 0.15])
        for order in orders:
            self.assertNotEqual(order, list(range(7)))
            np.testing.assert_array_equal(np.sort(prior[order]), np.sort(prior))

    def test_global_weights_can_change_and_fixed_cannot(self):
        head = torch.nn.Sequential(torch.nn.Linear(16, 32), torch.nn.ReLU(), torch.nn.Dropout(0.1), torch.nn.Linear(32, 1))
        prior = np.ones(7) / 7
        model = c.ControlFusion(head, 'global_sobol_init', prior)
        loss = (model(torch.randn(32, 7, 16)) - 3).square().mean()
        loss.backward()
        self.assertGreater(float(model.logits.grad.abs().sum()), 0)
        fixed = c.ControlFusion(head, 'capacity_sobol_fixed', prior)
        self.assertFalse(fixed.prior.requires_grad)
if __name__ == '__main__':
    raise SystemExit('Use scripts/train_mainline.py for mainline fitting or the saved-result analysis scripts. This historical entry is retained for method provenance, not default execution.')
