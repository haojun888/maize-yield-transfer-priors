import sys as _sys
from pathlib import Path as _Path
_release_root = _Path(__file__).resolve().parents[2]
_sys.path.insert(0, str(_release_root))
from release_support import configured_path as _configured_path, prepare_transfer as _prepare_transfer
'County maize baseline data preparation. See README for retrospective scope.'
import argparse
import json
import zipfile
from pathlib import Path
import numpy as np
import pandas as pd
ROOT = Path(__file__).resolve().parents[2]
CACHE = ROOT / 'work/maize_baseline'
OUT = Path(__file__).resolve().parent
FEATURES = ['tmin', 'tmax', 'tavg', 'prec', 'cwb', 'rad', 'ndvi', 'ssm']
AGG = {'tmin': 'min', 'tmax': 'max', 'tavg': 'mean', 'prec': 'sum', 'cwb': 'sum', 'rad': 'mean', 'ndvi': 'mean', 'ssm': 'mean'}
STATIC = ['awc', 'bulk_density']

def aggregate_chunk(frame, windows, aggregations):
    """Only same-county/year dates inside inclusive windows can reach features."""
    frame = frame.copy()
    frame['observed_date'] = pd.to_datetime(frame.date.astype(str), format='%Y%m%d')
    frame['year'] = frame.observed_date.dt.year
    frame = frame.merge(windows[['adm_id', 'year', 'start', 'cutoff']], on=['adm_id', 'year'], how='inner', validate='many_to_one')
    frame = frame[(frame.observed_date >= frame.start) & (frame.observed_date <= frame.cutoff)].copy()
    frame['bin'] = ((frame.observed_date - frame.start).dt.days // 10).astype(int)
    spec = {'date': ['max']}
    for col, how in aggregations.items():
        frame[col] = frame[col].replace([np.inf, -np.inf], np.nan)
        spec[col] = ['sum', 'count'] if how in ['sum', 'mean'] else [how, 'count']
    got = frame.groupby(['adm_id', 'year', 'bin'], observed=True).agg(spec)
    got.columns = ['_'.join(c) for c in got.columns]
    return got.rename(columns={'date_max': 'latest'}).reset_index()

def prepare_arrays(x, static, lengths, fit_mask):
    """Fit medians/scales only on training valid steps; preserve observation masks."""
    valid = np.arange(x.shape[1])[None, :] < lengths[:, None]
    observed = np.isfinite(x) & valid[:, :, None]
    train = x[fit_mask].copy()
    train[~valid[fit_mask]] = np.nan
    median = np.nanmedian(train, axis=(0, 1))
    if not np.isfinite(median).all():
        raise ValueError('An input has no finite training observations')
    filled = np.where(observed, x, median)
    tr = filled[fit_mask][valid[fit_mask]]
    mean = tr.mean(axis=0)
    scale = tr.std(axis=0)
    scale = np.where(scale < 1e-06, 1.0, scale)
    normalized = (filled - mean) / scale
    normalized[~valid] = 0.0
    packed = np.concatenate([normalized, observed.astype(np.float32), valid[:, :, None].astype(np.float32)], axis=2).astype(np.float32)
    sm = np.nanmedian(static[fit_mask], axis=0)
    sf = np.where(np.isfinite(static), static, sm)
    smean = sf[fit_mask].mean(axis=0)
    sscale = sf[fit_mask].std(axis=0)
    sscale = np.where(sscale < 1e-06, 1.0, sscale)
    st = ((sf - smean) / sscale).astype(np.float32)
    params = {k: v.tolist() for k, v in {'median': median, 'mean': mean, 'scale': scale, 'static_median': sm, 'static_mean': smean, 'static_scale': sscale}.items()}
    return (packed, st, params)

def build_cache(archive):
    CACHE.mkdir(parents=True, exist_ok=True)
    labels = pd.read_csv(ROOT / 'outputs/maize_data_audit/candidate_labels_2004_2023.csv')
    labels = labels[labels.cornbelt_12].rename(columns={'harvest_year': 'year'}).sort_values(['adm_id', 'year']).reset_index(drop=True)
    labels = labels[['adm_id', 'year', 'yield', 'state_fips']]
    prefix = 'cybench-data/maize/US/'
    with zipfile.ZipFile(archive) as z:
        with z.open(prefix + 'crop_calendar_maize_US.csv') as f:
            cal = pd.read_csv(f)
        with z.open(prefix + 'soil_maize_US.csv') as f:
            soil = pd.read_csv(f)
        windows = labels.merge(cal[['adm_id', 'sos', 'eos']], on='adm_id', validate='many_to_one')
        if (windows.sos.astype(int) > windows.eos.astype(int)).any():
            raise ValueError('Cross-year calendar needs explicit support')
        windows['sos_date'] = pd.to_datetime(windows.year * 1000 + windows.sos.astype(int), format='%Y%j')
        windows['eos_date'] = pd.to_datetime(windows.year * 1000 + windows.eos.astype(int), format='%Y%j')
        windows['start'] = windows.sos_date - pd.Timedelta(days=90)
        windows['cutoff'] = windows.eos_date - pd.Timedelta(days=60)
        windows['length'] = ((windows.cutoff - windows.start).dt.days // 10 + 1).astype(int)
        combined = []
        provenance = []
        for source, cols in [('meteo', FEATURES[:6]), ('ndvi', ['ndvi']), ('soil_moisture', ['ssm'])]:
            name = prefix + source + '_maize_US.csv'
            info = z.getinfo(name)
            provenance.append({'name': name, 'bytes': info.file_size, 'crc32': f'{info.CRC:08x}'})
            pieces = []
            with z.open(name) as f:
                for frame in pd.read_csv(f, usecols=['adm_id', 'date'] + cols, chunksize=250000):
                    frame = frame[frame.adm_id.isin(set(labels.adm_id))]
                    if not frame.empty:
                        pieces.append(aggregate_chunk(frame, windows, {c: AGG[c] for c in cols}))
            stats = pd.concat(pieces, ignore_index=True)
            reducers = {'latest': 'max'}
            for c in cols:
                how = AGG[c]
                reducers[c + '_count'] = 'sum'
                reducers[c + '_' + ('sum' if how in ['mean', 'sum'] else how)] = 'sum' if how in ['mean', 'sum'] else how
            stats = stats.groupby(['adm_id', 'year', 'bin'], observed=True).agg(reducers)
            for c in cols:
                how = AGG[c]
                raw = stats[c + '_' + ('sum' if how in ['mean', 'sum'] else how)]
                stats[c] = raw / stats[c + '_count'] if how == 'mean' else raw
                stats.loc[stats[c + '_count'] == 0, c] = np.nan
            stats = stats[cols + ['latest']]
            check = stats.reset_index().merge(windows[['adm_id', 'year', 'cutoff']], on=['adm_id', 'year'])
            assert (pd.to_datetime(check.latest.astype(str), format='%Y%m%d') <= check.cutoff).all()
            combined.append(stats[cols])
            print(f'Prepared {source}: {len(stats)} county-year-dekad groups', flush=True)
        all_stats = pd.concat(combined, axis=1)
    T = int(windows.length.max())
    N = len(labels)
    full_index = pd.MultiIndex.from_product([[], [], []], names=['adm_id', 'year', 'bin'])
    tuples = [(row.adm_id, row.year, t) for row in labels.itertuples() for t in range(T)]
    full_index = pd.MultiIndex.from_tuples(tuples, names=['adm_id', 'year', 'bin'])
    x = all_stats.reindex(full_index)[FEATURES].to_numpy(dtype=np.float32).reshape(N, T, len(FEATURES))
    static = labels.merge(soil[['adm_id'] + STATIC], on='adm_id', validate='many_to_one')[STATIC].to_numpy(dtype=np.float32)
    lengths = windows.length.to_numpy()
    valid = np.arange(T)[None, :] < lengths[:, None]
    x[~valid] = np.nan
    assert np.isfinite(static).all()
    assert not labels.duplicated(['adm_id', 'year']).any()
    np.savez_compressed(CACHE / 'dataset.npz', x=x, static=static, lengths=lengths, y=labels['yield'].to_numpy(dtype=np.float32), years=labels.year.to_numpy(), counties=labels.adm_id.to_numpy(dtype=str))
    labels.to_csv(OUT / 'sample_manifest.csv', index=False)
    windows[['adm_id', 'year', 'sos_date', 'eos_date', 'start', 'cutoff', 'length']].to_csv(OUT / 'date_windows.csv', index=False)
    meta = {'archive': str(archive), 'files': provenance, 'samples': N, 'counties': labels.adm_id.nunique(), 'time_steps_max': T, 'dynamic_features': FEATURES, 'static_features': STATIC, 'lead_time_days': 60, 'spinup_days': 90, 'missing_fraction_valid_steps': {c: float(np.isnan(x[:, :, i][valid]).mean()) for i, c in enumerate(FEATURES)}, 'scope': 'Retrospective timestamp-truncated; availability of composite/reanalysis products not certified', 'excluded': ['FPAR', 'county ID as input', 'coordinates', 'year as input', 'harvest_area', 'production']}
    (OUT / 'data_config.json').write_text(json.dumps(meta, indent=2), encoding='utf-8')
    print(json.dumps(meta), flush=True)
if __name__ == '__main__':
    raise SystemExit('Use scripts/train_mainline.py for mainline fitting or the saved-result analysis scripts. This historical entry is retained for method provenance, not default execution.')
