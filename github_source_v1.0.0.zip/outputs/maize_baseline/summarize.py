import sys as _sys
from pathlib import Path as _Path
_release_root = _Path(__file__).resolve().parents[2]
_sys.path.insert(0, str(_release_root))
from release_support import configured_path as _configured_path, prepare_transfer as _prepare_transfer
'Build a human-readable report and verify saved temporal-holdout predictions.'
import json
import sys
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error
OUT = Path(__file__).resolve().parent
if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8')

def reference_skill(y, p, reference):
    denominator = float(np.sum((np.asarray(y) - reference) ** 2))
    return 1.0 - float(np.sum((np.asarray(y) - p) ** 2)) / denominator if denominator > 0 else float('nan')

def run():
    r = json.loads((OUT / 'results.json').read_text(encoding='utf-8'))
    pred = pd.read_csv(OUT / 'test_predictions.csv')
    table = pd.read_csv(OUT / 'metrics.csv')
    dates = pd.read_csv(OUT / 'date_windows.csv', parse_dates=['start', 'cutoff', 'sos_date', 'eos_date'])
    assert (dates.cutoff == dates.eos_date - pd.Timedelta(days=60)).all()
    assert (dates.start == dates.sos_date - pd.Timedelta(days=90)).all()
    assert set(pred.year) == {2020, 2021, 2022, 2023}
    assert not pred.duplicated(['model', 'seed', 'adm_id', 'year']).any()
    assert np.isfinite(pred[['observed_yield_t_ha', 'predicted_yield_t_ha']]).all().all()
    references = {name: pred[pred.model == name].set_index(['adm_id', 'year']).predicted_yield_t_ha for name in ['county_historical_mean', 'county_linear_trend']}
    skillrows = []
    for (name, seed), df in pred.groupby(['model', 'seed']):
        saved = table[(table.model == name) & (table.seed == seed) & (table.period == '2020-2023')].iloc[0]
        assert len(df) == 3396
        assert np.isclose(saved.r2, r2_score(df.observed_yield_t_ha, df.predicted_yield_t_ha))
        assert np.isclose(saved.rmse_t_ha, np.sqrt(mean_squared_error(df.observed_yield_t_ha, df.predicted_yield_t_ha)))
        assert np.isclose(saved.mae_t_ha, mean_absolute_error(df.observed_yield_t_ha, df.predicted_yield_t_ha))
        keys = pd.MultiIndex.from_frame(df[['adm_id', 'year']])
        skillrows.append({'model': name, 'seed': int(seed), **{ref + '_skill': reference_skill(df.observed_yield_t_ha.to_numpy(), df.predicted_yield_t_ha.to_numpy(), values.reindex(keys).to_numpy()) for ref, values in references.items()}})
    skilldf = pd.DataFrame(skillrows)
    skilldf.to_csv(OUT / 'historical_reference_skill.csv', index=False)
    rows = ['|模型|R²|RMSE（t/ha）|MAE（t/ha）|平均偏差（t/ha）|', '|---|---:|---:|---:|---:|']
    names = {'RF': '随机森林', 'LSTM': 'LSTM', 'county_historical_mean': '县历史均值', 'county_linear_trend': '县线性趋势'}
    for name in ['county_historical_mean', 'county_linear_trend', 'RF', 'LSTM']:
        m = r['models'][name]
        fmt = lambda key: f"{m[key]['mean']:.4f}" + (f" ± {m[key]['seed_sd']:.4f}" if name in ['RF', 'LSTM'] else '')
        rows.append('|' + names[name] + '|' + '|'.join((fmt(k) for k in ['r2', 'rmse_t_ha', 'mae_t_ha', 'bias_t_ha'])) + '|')
    annual = ['|年份|测试样本|县均值RMSE|县趋势RMSE|RF RMSE|LSTM RMSE|', '|---|---:|---:|---:|---:|---:|']
    for year in range(2020, 2024):
        sub = table[table.period == str(year)]
        values = {name: sub[sub.model == name].rmse_t_ha.mean() for name in names}
        annual.append(f"|{year}|{int(sub.iloc[0]['n'])}|" + '|'.join((f'{values[k]:.4f}' for k in ['county_historical_mean', 'county_linear_trend', 'RF', 'LSTM'])) + '|')
    residual = ['|模型|县均值中心化R²|县趋势残差R²|相对县均值技能分数|相对县趋势技能分数|', '|---|---:|---:|---:|---:|']
    for name in ['county_historical_mean', 'county_linear_trend', 'RF', 'LSTM']:
        m = r['models'][name]
        skill = skilldf[skilldf.model == name]
        residual.append(f"|{names[name]}|{m['county_mean_centered_r2']['mean']:.4f}|{m['county_trend_residual_r2']['mean']:.4f}|{skill.county_historical_mean_skill.mean():.4f}|{skill.county_linear_trend_skill.mean():.4f}|")
    epochrows = [v for v in r['selection'] if v['model'] == 'LSTM']
    epochtext = '；'.join((f"种子{v['seed']}：{v['best_epoch']}轮，验证RMSE={v['rmse_t_ha']:.4f}" for v in epochrows))
    model_rmse = min((r['models'][n]['rmse_t_ha']['mean'] for n in ['RF', 'LSTM']))
    trend_rmse = r['models']['county_linear_trend']['rmse_t_ha']['mean']
    conclusion = '最优季内模型仍未超过县线性趋势基线；现阶段不能将复杂模型或后续门控的高原始产量R²解释为更强的年度异常预测。' if model_rmse >= trend_rmse else '季内模型优于县线性趋势基线，但这仍是单次未来年份留出结果，尚需空间迁移和不确定性验证。'
    text = f"# 第一轮美国县级玉米无先验基线结果\n\n已完成RF和LSTM三个随机种子的训练与独立未来年份测试；未开展空间迁移、Sobol或先验门控。\n\n## 数据与隔离\n玉米带12州，1,015个县，17,303条县—年。训练2004—2016：11,653条；验证2017—2019：2,254条。配置锁定后重新拟合2004—2019：13,907条；测试2020—2023：3,396条。测试有4个训练侧未出现的县，但本轮总体仍是同一区域未来年份验证。\n\n固定作物历EOS前60天预测，SOS前90天开始输入；8个动态变量+2个土壤变量。RF展开旬特征，LSTM读取旬序列，最多23旬；两者含缺测标记。NDVI缺测约10.76%，以训练侧中位数填补。没有跨县插值、没有截止后原始观测进入特征、测试标签不参与模型选择。\n\n## 独立测试指标\n±为三个随机种子的样本标准差，不是统计置信区间；历史基线无随机种子。\n\n{chr(10).join(rows)}\n\n偏差为预测减观测，负值表示低估。\n\n## 年度结果\nRF/LSTM为三种子均值。\n\n{chr(10).join(annual)}\n\n## 产量异常诊断\n将预测与观测都减去同一训练侧县历史均值或外推县趋势后计算残差R²。其分母还中心化了测试残差，因此不能用其正负判断是否优于历史参考。另列技能分数1−模型平方误差和/历史参考平方误差和；技能分数大于0才表示优于相应参考，小于0表示更差。此处只是无需再训练的残差评价，不是训练了异常目标的新模型。\n\n{chr(10).join(residual)}\n\n{conclusion}\n\n## 选择与训练记录\nRF验证比较min_samples_leaf=5/20，选择验证RMSE较低者；300棵树，max_depth=20，max_features=0.75。最终模型n_jobs=4；最初单进程试跑被终止，重启后参数和验证结果一致，未使用试跑选择额外配置。\n\nLSTM：单层hidden32；土壤拼接后32维回归头，dropout0.1；Adam学习率0.001，weight_decay0.0001；最多60轮，验证8轮不改善早停。\n{epochtext}。\n每个种子选择轮数后从头重训2004—2019，不使用测试早停。\n\n设备：{r['gpu'] or r['device']}。最后一次成功运行耗时{r['runtime_seconds'] / 60:.1f}分钟；RF验证此前已完成并在本次恢复时复用，此外还有数据准备及环境排障耗时。交付代码已移除未经指纹校验的恢复缓存，重跑会重新完成RF验证选择。\n\n## 证据与局限\n- 保存了每个县—年、模型、种子的预测、指标、预处理参数、模型权重及时间窗口。\n- 复算预测文件中的R²、RMSE、MAE与metrics.csv一致，截止边界检查通过；代码的数据安全测试通过。\n- 产品时间戳截断并不等于实际发布时间截断。NDVI合成和再分析产品未通过实时可用性审计；FPAR已排除。结论限定为回溯季内预测。\n- 训练与测试位于同一12州，不能称为已验证的跨生态区泛化。\n- 本轮是有限配置的基线，不是全面调参或算法能力排名；测试结果不用于本轮模型再次调优。\n\n## 下一步\n先将训练侧趋势/县均值与年度异常分开建模，并设计独立的空间和联合时空留出。随后再评估敏感性先验是否改善迁移；必须与无先验和随机先验对照，不能把历史均值/趋势带来的优势归因于门控。\n\n代码与重现步骤见README.md；详细结果见results.json、metrics.csv、test_predictions.csv、training_history.csv。\n"
    (OUT / '结果报告.md').write_text(text, encoding='utf-8')
    print('Verified date cutoffs and all saved test metrics; report written.')
    print('\n'.join(rows))
if __name__ == '__main__':
    raise SystemExit('Use scripts/train_mainline.py for mainline fitting or the saved-result analysis scripts. This historical entry is retained for method provenance, not default execution.')
