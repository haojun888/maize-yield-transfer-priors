import sys as _sys
from pathlib import Path as _Path
_release_root = _Path(__file__).resolve().parents[2]
_sys.path.insert(0, str(_release_root))
from release_support import configured_path as _configured_path, prepare_transfer as _prepare_transfer
'Train source-only RF/LSTM baselines with validation selection and future-year test.'
import copy
import json
import os
import random
import time
import faulthandler
from pathlib import Path
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG', ':4096:8')
import joblib
import numpy as np
import pandas as pd
import torch
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error
from torch import nn
from torch.utils.data import DataLoader, TensorDataset
from pipeline import CACHE, OUT, prepare_arrays, FEATURES, STATIC
SEEDS = [42, 2026, 3407]
RF_JOBS = int(os.environ.get('MAIZE_RF_JOBS', '1'))
faulthandler.enable()
DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
torch.set_num_threads(4)
torch.backends.cudnn.benchmark = False
torch.backends.cudnn.deterministic = True

def metrics(y, p):
    return {'n': len(y), 'r2': float(r2_score(y, p)), 'rmse_t_ha': float(np.sqrt(mean_squared_error(y, p))), 'mae_t_ha': float(mean_absolute_error(y, p)), 'bias_t_ha': float(np.mean(p - y))}

def seed_all(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)

class LSTM(nn.Module):

    def __init__(self, dynamic, static):
        super().__init__()
        self.lstm = nn.LSTM(dynamic, 32, batch_first=True)
        self.head = nn.Sequential(nn.Linear(32 + static, 32), nn.ReLU(), nn.Dropout(0.1), nn.Linear(32, 1))

    def forward(self, x, static, lengths):
        packed = nn.utils.rnn.pack_padded_sequence(x, lengths.cpu(), batch_first=True, enforce_sorted=False)
        _, (h, _) = self.lstm(packed)
        return self.head(torch.cat([h[-1], static], dim=1)).squeeze(1)

def predict(model, seq, static, lengths, mask, mean, std):
    model.eval()
    pred = []
    with torch.no_grad():
        for ids in np.array_split(np.flatnonzero(mask), max(1, int(np.ceil(mask.sum() / 512)))):
            pred.append(model(torch.from_numpy(seq[ids]).to(DEVICE), torch.from_numpy(static[ids]).to(DEVICE), torch.from_numpy(lengths[ids])).cpu().numpy() * std + mean)
    return np.concatenate(pred)

def fit_lstm(seq, static, lengths, y, train_mask, val_mask, seed, epochs=60):
    seed_all(seed)
    model = LSTM(seq.shape[-1], static.shape[-1]).to(DEVICE)
    ym = float(y[train_mask].mean())
    ys = float(y[train_mask].std())
    if ys < 1e-06:
        raise ValueError('Constant training target')
    ds = TensorDataset(torch.from_numpy(seq[train_mask]), torch.from_numpy(static[train_mask]), torch.from_numpy(lengths[train_mask]), torch.from_numpy(((y[train_mask] - ym) / ys).astype(np.float32)))
    loader = DataLoader(ds, batch_size=256, shuffle=True, generator=torch.Generator().manual_seed(seed), num_workers=0)
    optimizer = torch.optim.Adam(model.parameters(), lr=0.001, weight_decay=0.0001)
    history = []
    best = float('inf')
    best_epoch = epochs
    state = None
    stale = 0
    for epoch in range(1, epochs + 1):
        model.train()
        total = 0.0
        for xb, sb, lb, yb in loader:
            xb = xb.to(DEVICE)
            sb = sb.to(DEVICE)
            yb = yb.to(DEVICE)
            optimizer.zero_grad(set_to_none=True)
            loss = nn.functional.mse_loss(model(xb, sb, lb), yb)
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()
            total += float(loss.detach().cpu()) * len(xb)
        row = {'seed': seed, 'epoch': epoch, 'train_mse_standardized': total / len(ds)}
        if val_mask is not None:
            pv = predict(model, seq, static, lengths, val_mask, ym, ys)
            score = metrics(y[val_mask], pv)['rmse_t_ha']
            row['val_rmse_t_ha'] = score
            if score < best - 1e-05:
                best = score
                best_epoch = epoch
                state = copy.deepcopy(model.state_dict())
                stale = 0
            else:
                stale += 1
        history.append(row)
        if epoch % 10 == 0 or epoch == 1:
            print(f'LSTM seed {seed} epoch {epoch}: {row}', flush=True)
        if val_mask is not None and stale >= 8:
            break
    if state is not None:
        model.load_state_dict(state)
    return (model, ym, ys, best_epoch, history)

def linear_coefficients(x, y):
    x = np.asarray(x, dtype=np.float64)
    y = np.asarray(y, dtype=np.float64)
    xm = x.mean()
    ym = y.mean()
    variance = np.sum((x - xm) ** 2)
    slope = float(np.sum((x - xm) * (y - ym)) / variance) if variance > 0 else 0.0
    return np.array([slope, float(ym - slope * xm)])

def historical_reference(y, years, counties, fit_mask, pred_mask):
    globalmean = float(y[fit_mask].mean())
    globalcoef = linear_coefficients(years[fit_mask] - 2000, y[fit_mask])
    lookup = {}
    for county in np.unique(counties[fit_mask]):
        ids = fit_mask & (counties == county)
        coef = linear_coefficients(years[ids] - 2000, y[ids]) if ids.sum() >= 3 else globalcoef
        lookup[county] = (float(y[ids].mean()), coef)
    means = []
    trends = []
    for county, year in zip(counties[pred_mask], years[pred_mask]):
        m, c = lookup.get(county, (globalmean, globalcoef))
        means.append(m)
        trends.append(float(np.polyval(c, year - 2000)))
    return (np.asarray(means), np.asarray(trends))

def run():
    start = time.time()
    data = np.load(CACHE / 'dataset.npz')
    x, static, lengths, y, years, counties = [data[k] for k in ['x', 'static', 'lengths', 'y', 'years', 'counties']]
    train_mask = years <= 2016
    val_mask = (years >= 2017) & (years <= 2019)
    test_mask = years >= 2020
    fit_mask = train_mask | val_mask
    assert not (train_mask & val_mask).any() and (not (fit_mask & test_mask).any())
    assert train_mask.sum() + val_mask.sum() + test_mask.sum() == len(y)
    seq, st, selection_params = prepare_arrays(x, static, lengths, train_mask)
    finalseq, finalst, final_params = prepare_arrays(x, static, lengths, fit_mask)
    table = np.concatenate([seq.reshape(len(y), -1), st], axis=1)
    finaltable = np.concatenate([finalseq.reshape(len(y), -1), finalst], axis=1)
    selection = []
    histories = []
    predictions = []
    for leaf in [5, 20]:
        model = RandomForestRegressor(n_estimators=300, min_samples_leaf=leaf, max_features=0.75, max_depth=20, n_jobs=RF_JOBS, random_state=42)
        model.fit(table[train_mask], y[train_mask])
        score = metrics(y[val_mask], model.predict(table[val_mask]))
        score.update({'model': 'RF', 'min_samples_leaf': leaf})
        selection.append(score)
        print('RF validation', score, flush=True)
        del model
    bestleaf = min(selection, key=lambda r: r['rmse_t_ha'])['min_samples_leaf']
    testbase = pd.DataFrame({'adm_id': counties[test_mask], 'year': years[test_mask], 'observed_yield_t_ha': y[test_mask]})
    summary = {'scope': 'Initial retrospective timestamp-truncated temporal holdout; no spatial transfer yet', 'splits': {'train': {'years': [2004, 2016], 'n': int(train_mask.sum())}, 'validation': {'years': [2017, 2019], 'n': int(val_mask.sum())}, 'final_fit': {'years': [2004, 2019], 'n': int(fit_mask.sum())}, 'test': {'years': [2020, 2023], 'n': int(test_mask.sum())}}, 'device': str(DEVICE), 'gpu': torch.cuda.get_device_name(0) if DEVICE.type == 'cuda' else None, 'seeds': SEEDS, 'dynamic_features': FEATURES, 'static_features': STATIC, 'models': {}, 'selection': selection}
    refs = historical_reference(y, years, counties, fit_mask, test_mask)
    meanref, trendref = refs
    for name, p in [('county_historical_mean', meanref), ('county_linear_trend', trendref)]:
        df = testbase.copy()
        df['model'] = name
        df['seed'] = -1
        df['predicted_yield_t_ha'] = p
        predictions.append(df)
    for seed in SEEDS:
        print(f'Starting final RF seed {seed}, n_jobs={RF_JOBS}', flush=True)
        rf = RandomForestRegressor(n_estimators=300, min_samples_leaf=bestleaf, max_features=0.75, max_depth=20, n_jobs=RF_JOBS, random_state=seed)
        rf.fit(finaltable[fit_mask], y[fit_mask])
        print(f'RF fitted seed {seed}; saving', flush=True)
        df = testbase.copy()
        df['model'] = 'RF'
        df['seed'] = seed
        df['predicted_yield_t_ha'] = rf.predict(finaltable[test_mask])
        predictions.append(df)
        joblib.dump(rf, OUT / f'rf_seed_{seed}.joblib', compress=3)
        print('RF test', seed, metrics(y[test_mask], df.predicted_yield_t_ha.to_numpy()), flush=True)
        pd.concat(predictions, ignore_index=True).to_csv(OUT / 'partial_predictions.csv', index=False)
        del rf
    for seed in SEEDS:
        model, ym, ys, bestepoch, history = fit_lstm(seq, st, lengths, y, train_mask, val_mask, seed)
        validation = metrics(y[val_mask], predict(model, seq, st, lengths, val_mask, ym, ys))
        summary['selection'].append({'model': 'LSTM', 'seed': seed, 'best_epoch': bestepoch, **validation})
        for row in history:
            row['stage'] = 'selection'
        histories.extend(history)
        del model
        model, ym, ys, _, history = fit_lstm(finalseq, finalst, lengths, y, fit_mask, None, seed, epochs=bestepoch)
        for row in history:
            row['stage'] = 'final_fit'
        histories.extend(history)
        p = predict(model, finalseq, finalst, lengths, test_mask, ym, ys)
        df = testbase.copy()
        df['model'] = 'LSTM'
        df['seed'] = seed
        df['predicted_yield_t_ha'] = p
        predictions.append(df)
        torch.save({'state_dict': model.cpu().state_dict(), 'dynamic_dim': finalseq.shape[-1], 'static_dim': finalst.shape[-1], 'hidden_dim': 32, 'target_mean': ym, 'target_std': ys, 'epochs': bestepoch, 'seed': seed}, OUT / f'lstm_seed_{seed}.pt')
        print('LSTM test', seed, metrics(y[test_mask], p), flush=True)
        pd.DataFrame(histories).to_csv(OUT / 'training_history.csv', index=False)
    pred = pd.concat(predictions, ignore_index=True)
    pred.to_csv(OUT / 'test_predictions.csv', index=False)
    rows = []
    for (name, seed), df in pred.groupby(['model', 'seed']):
        p = df.predicted_yield_t_ha.to_numpy()
        actual = df.observed_yield_t_ha.to_numpy()
        row = {'model': name, 'seed': int(seed), 'period': '2020-2023', **metrics(actual, p)}
        row['county_mean_centered_r2'] = float(r2_score(actual - meanref, p - meanref))
        row['county_trend_residual_r2'] = float(r2_score(actual - trendref, p - trendref))
        rows.append(row)
        for year, annual in df.groupby('year'):
            rows.append({'model': name, 'seed': int(seed), 'period': str(year), **metrics(annual.observed_yield_t_ha.to_numpy(), annual.predicted_yield_t_ha.to_numpy())})
    metricdf = pd.DataFrame(rows)
    metricdf.to_csv(OUT / 'metrics.csv', index=False)
    for name, df in metricdf[metricdf.period == '2020-2023'].groupby('model'):
        summary['models'][name] = {metric: {'mean': float(df[metric].mean()), 'seed_sd': float(df[metric].std(ddof=1)) if len(df) > 1 else 0.0} for metric in ['r2', 'rmse_t_ha', 'mae_t_ha', 'bias_t_ha', 'county_mean_centered_r2', 'county_trend_residual_r2']}
    summary['runtime_seconds'] = time.time() - start
    (OUT / 'preprocessing.json').write_text(json.dumps({'selection': selection_params, 'final_fit': final_params}, indent=2), encoding='utf-8')
    (OUT / 'results.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
    print(json.dumps(summary, indent=2), flush=True)
if __name__ == '__main__':
    raise SystemExit('Use scripts/train_mainline.py for mainline fitting or the saved-result analysis scripts. This historical entry is retained for method provenance, not default execution.')
