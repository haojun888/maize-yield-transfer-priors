import sys as _sys
from pathlib import Path as _Path
_release_root = _Path(__file__).resolve().parents[2]
_sys.path.insert(0, str(_release_root))
from release_support import configured_path as _configured_path, prepare_transfer as _prepare_transfer
import unittest
import numpy as np
import pandas as pd
import pipeline
import train
import summarize

class TemporalSafety(unittest.TestCase):

    def test_historical_skill_uses_uncentered_reference_error(self):
        self.assertTrue(hasattr(summarize, 'reference_skill'), 'reference_skill not implemented')
        self.assertAlmostEqual(summarize.reference_skill(np.array([3.0, 4.0]), np.array([1.0, 1.0]), np.array([0.0, 0.0])), 0.48)

    def test_linear_trend_closed_form(self):
        self.assertTrue(hasattr(train, 'linear_coefficients'), 'linear_coefficients not implemented')
        slope, intercept = train.linear_coefficients(np.array([1.0, 2.0, 3.0]), np.array([3.0, 5.0, 7.0]))
        self.assertAlmostEqual(slope, 2.0)
        self.assertAlmostEqual(intercept, 1.0)
        slope, intercept = train.linear_coefficients(np.array([2.0, 2.0]), np.array([3.0, 5.0]))
        self.assertEqual(slope, 0.0)
        self.assertEqual(intercept, 4.0)

    def test_cutoff_and_county_isolation(self):
        self.assertTrue(hasattr(pipeline, 'aggregate_chunk'), 'aggregate_chunk not implemented')
        windows = pd.DataFrame({'adm_id': ['A', 'B'], 'year': [2020, 2020], 'start': [pd.Timestamp('2020-06-01'), pd.Timestamp('2020-06-01')], 'cutoff': [pd.Timestamp('2020-06-10'), pd.Timestamp('2020-06-10')]})
        frame = pd.DataFrame({'adm_id': ['A', 'A', 'A', 'B'], 'date': [20200601, 20200610, 20200611, 20200605], 'prec': [2.0, 3.0, 999.0, 7.0], 'ndvi': [0.2, 0.4, 0.99, 0.8]})
        got = pipeline.aggregate_chunk(frame, windows, {'prec': 'sum', 'ndvi': 'mean'}).set_index(['adm_id', 'year', 'bin'])
        self.assertEqual(got.loc[('A', 2020, 0), 'prec_sum'], 5.0)
        self.assertEqual(got.loc[('A', 2020, 0), 'ndvi_count'], 2)
        self.assertAlmostEqual(got.loc[('B', 2020, 0), 'ndvi_sum'], 0.8)
        self.assertLessEqual(got.latest.max(), 20200610)

    def test_train_only_fill_and_padding(self):
        self.assertTrue(hasattr(pipeline, 'prepare_arrays'), 'prepare_arrays not implemented')
        x = np.array([[[1.0], [3.0]], [[np.nan], [999.0]], [[100.0], [100.0]]], dtype=np.float32)
        static = np.array([[2.0], [np.nan], [100.0]], dtype=np.float32)
        lengths = np.array([2, 1, 2])
        packed, st, params = pipeline.prepare_arrays(x, static, lengths, np.array([True, True, False]))
        self.assertEqual(params['median'][0], 2.0)
        self.assertEqual(params['static_median'][0], 2.0)
        np.testing.assert_array_equal(packed[1, 1], np.zeros(3))
        self.assertEqual(packed[1, 0, 1], 0.0)
        self.assertEqual(packed[0, 0, 1], 1.0)
        self.assertGreater(packed[2, 0, 0], 10.0)
        self.assertTrue(np.isfinite(packed).all())
if __name__ == '__main__':
    raise SystemExit('Use scripts/train_mainline.py for mainline fitting or the saved-result analysis scripts. This historical entry is retained for method provenance, not default execution.')
