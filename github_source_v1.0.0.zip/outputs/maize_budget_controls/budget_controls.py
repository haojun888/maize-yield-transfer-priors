import sys as _sys
from pathlib import Path as _Path
_release_root = _Path(__file__).resolve().parents[2]
_sys.path.insert(0, str(_release_root))
from release_support import configured_path as _configured_path, prepare_transfer as _prepare_transfer
'Complete within-block prior mappings and matched block-equal baseline.'
import hashlib
import itertools
import json
import sys
import time
from pathlib import Path
import numpy as np
import pandas as pd
import torch
OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
sys.path.insert(0, str(ROOT / 'outputs/maize_group_interventions'))
import interventions as i
s = i.s
t = i.t
SEEDS = [42, 2026, 3407]
OPT = [3, 5]
WEATHER = [0, 1, 2, 4]

def block_orders():
    result = []
    for optical in itertools.permutations(OPT):
        for weather in itertools.permutations(WEATHER):
            order = list(range(7))
            for slot, donor in zip(OPT, optical):
                order[slot] = donor
            for slot, donor in zip(WEATHER, weather):
                order[slot] = donor
            result.append(order)
    return result

def block_equal(prior):
    result = np.asarray(prior, dtype=float).copy()
    result[OPT] = result[OPT].sum() / 2
    result[WEATHER] = result[WEATHER].sum() / 4
    return result

def specs(prior):
    prior = np.asarray(prior, dtype=float)
    result = {}
    for j, order in enumerate(block_orders()[1:], 1):
        optical = any((order[k] != k for k in OPT))
        weather = any((order[k] != k for k in WEATHER))
        family = 'both' if optical and weather else 'optical_only' if optical else 'weather_only'
        result[f'within_{j:02d}'] = (prior[order], order, family)
    result['block_equal'] = (block_equal(prior), None, 'block_equal')
    return result

def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))

def prepare():
    path = OUT / 'manifest.json'
    if path.exists():
        manifest = read(path)
        for file, digest in manifest['sha256'].items():
            assert s.sha(file) == digest, file
        return manifest
    parent = read(i.OUT / 'verification.json')
    assert parent['verified']
    ancestor = i.prepare()
    dependencies = dict(ancestor['sha256'])
    for collection in [parent['model_sha256'], parent['output_sha256'], parent['cache_sha256']]:
        for file, digest in collection.items():
            assert s.sha(file) == digest, file
            dependencies[file] = digest
    assert s.sha(i.OUT / 'intervention_report.py') == parent['report_code_sha256']
    assert s.sha(i.OUT / 'test_report.py') == parent['report_test_sha256']
    for file in [Path(__file__), OUT / 'design.md', OUT / 'test_budget_controls.py', i.OUT / 'verification.json', i.OUT / 'intervention_report.py', i.OUT / 'test_report.py', ROOT / 'work/maize_environment_coverage/weather_calendar__fusion_2019__E_to_W__space.npz']:
        dependencies[str(file)] = s.sha(file)
    fp = hashlib.sha256(json.dumps(dependencies, sort_keys=True).encode()).hexdigest()
    manifest = {'fingerprint': fp, 'sha256': dependencies, 'seeds': SEEDS, 'protocol': 'E_to_W', 'orders_including_identity': block_orders(), 'new_methods': list(specs(np.ones(7) / 7)), 'selection_models': 144, 'final_models': 144, 'target_scenarios': 288, 'primary': 'original joint high-distance cohort', 'secondary': ['joint overall/low/middle', 'space original bins'], 'target_selection': False, 'estimate_new_prior': False}
    s.save(path, manifest)
    return manifest

def check_prior(prior, reference, family):
    np.testing.assert_allclose(prior[OPT].sum(), reference[OPT].sum(), atol=1e-12)
    np.testing.assert_allclose(prior[WEATHER].sum(), reference[WEATHER].sum(), atol=1e-12)
    np.testing.assert_allclose(prior[6], reference[6], atol=1e-12)
    if family != 'block_equal':
        np.testing.assert_array_equal(np.sort(prior), np.sort(reference))

def validate_checkpoint(path, meta, prior, fp):
    ck = torch.load(path, map_location='cpu', weights_only=True)
    assert ck['fingerprint'] == fp and ck['epoch'] == meta['epoch']
    assert ck['parameters'] == 577
    np.testing.assert_allclose(ck['prior'], prior, atol=1e-12)
    np.testing.assert_allclose(ck['state_dict']['prior'], prior, atol=1e-07)
    return ck

def run():
    start = time.time()
    manifest = prepare()
    fp = manifest['fingerprint']
    candidates = []
    prior_rows = []
    old_orders = read(i.GAIN / 'manifest.json')['orders']
    for seed in SEEDS:
        data, split, teacher, bank, bg, residual, reference = i.load_context(seed)
        folder = OUT / str(seed)
        folder.mkdir(exist_ok=True)
        assert len({tuple(v[0]) for v in specs(reference).values()}) == 48
        assert not any((order in old_orders for order in block_orders()[1:]))
        for method, (prior, order, family) in specs(reference).items():
            check_prior(prior, reference, family)
            path = folder / f'selection_{method}.pt'
            mp = folder / f'selection_{method}.json'
            if path.exists() != mp.exists():
                raise ValueError(f'Incomplete candidate pair: {path}')
            if not path.exists():
                model, ym, ys, epoch, history, score = s.train(teacher.head, 'fixed', prior, 0.0, bank, residual['selection'], split['train'], split['val'], seed)
                torch.save({'state_dict': model.cpu().state_dict(), 'prior': prior.tolist(), 'target_mean': ym, 'target_std': ys, 'epoch': epoch, 'fingerprint': fp, 'parameters': 577, 'method': method, 'family': family, 'order': order}, path)
                s.save(mp, {'seed': seed, 'method': method, 'family': family, 'epoch': epoch, 'val_rmse': score, 'fingerprint': fp})
                pd.DataFrame(history).to_csv(folder / f'selection_{method}_history.csv', index=False)
            meta = read(mp)
            assert meta['fingerprint'] == fp
            validate_checkpoint(path, meta, prior, fp)
            candidates.append(meta)
            prior_rows.append({'seed': seed, 'method': method, 'family': family, 'order': json.dumps(order), **dict(zip(['thermal', 'water', 'radiation', 'ndvi', 'gdd', 'evi', 'soil'], prior)), 'optical_total': prior[OPT].sum(), 'weather_total': prior[WEATHER].sum(), 'concentration_sum_squares': float((prior ** 2).sum())})
            if len(candidates) % 12 == 0:
                print('SOURCE', seed, len(candidates), round(time.time() - start, 1), flush=True)
    assert len(candidates) == 144
    pd.DataFrame(candidates).to_csv(OUT / 'validation_candidates.csv', index=False)
    pd.DataFrame(prior_rows).to_csv(OUT / 'priors.csv', index=False)
    s.save(OUT / 'selection_complete.json', {'fingerprint': fp, 'selection_models': 144, 'target_predictions_started': False, 'candidates_sha256': s.sha(OUT / 'validation_candidates.csv')})
    frames = []
    count = 0
    for seed in SEEDS:
        data, split, teacher, bank, bg, residual, reference = i.load_context(seed)
        folder = OUT / str(seed)
        for method, (prior, order, family) in specs(reference).items():
            meta = read(folder / f'selection_{method}.json')
            path = folder / f'final_{method}.pt'
            if not path.exists():
                model, ym, ys = t.fit_final(teacher.head, 'fixed', prior, 0.0, bank, residual['final_fit'], split['fit'], seed, meta['epoch'])
                torch.save({'state_dict': model.cpu().state_dict(), 'prior': prior.tolist(), 'target_mean': ym, 'target_std': ys, 'epoch': meta['epoch'], 'fingerprint': fp, 'parameters': 577, 'method': method, 'family': family, 'order': order}, path)
            ck = validate_checkpoint(path, meta, prior, fp)
            model = s.Fusion(teacher.head, 'fixed', prior).to(s.DEVICE)
            model.load_state_dict(ck['state_dict'])
            count += 1
            for scenario in ['space', 'joint']:
                mask = split[scenario]
                prediction, _ = s.predict(model, bank[mask], ck['target_mean'], ck['target_std'])
                frames.append(pd.DataFrame({'seed': seed, 'method': method, 'family': family, 'scenario': scenario, 'row': np.flatnonzero(mask), 'adm_id': data['counties'][mask], 'year': data['years'][mask], 'observed_yield_t_ha': data['y'][mask], 'predicted_yield_t_ha': prediction + bg['final_fit'][mask]}))
            if count % 12 == 0:
                print('FINAL', seed, count, round(time.time() - start, 1), flush=True)
    assert count == 144 and len(frames) == 288
    pd.concat(frames, ignore_index=True).to_csv(OUT / 'new_predictions.csv', index=False)
    s.save(OUT / 'run_complete.json', {'fingerprint': fp, 'selection_models': 144, 'final_models': count, 'target_scenarios': 288, 'runtime_seconds': time.time() - start})
    print('BUDGET CONTROLS TRAINED', round(time.time() - start, 1), flush=True)
if __name__ == '__main__':
    raise SystemExit('Use scripts/train_mainline.py for mainline fitting or the saved-result analysis scripts. This historical entry is retained for method provenance, not default execution.')
