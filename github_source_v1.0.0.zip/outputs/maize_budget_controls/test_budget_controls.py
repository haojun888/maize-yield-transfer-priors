import sys as _sys
from pathlib import Path as _Path
_release_root = _Path(__file__).resolve().parents[2]
_sys.path.insert(0, str(_release_root))
from release_support import configured_path as _configured_path, prepare_transfer as _prepare_transfer
'Protect complete restricted mappings and distinguish their budgets from values.'
import importlib.util
import unittest
import numpy as np

class BudgetContracts(unittest.TestCase):

    def test_full_mapping_set_and_preserved_budgets(self):
        self.assertIsNotNone(importlib.util.find_spec('budget_controls'), 'Budget control is not implemented')
        import budget_controls as b
        orders = b.block_orders()
        self.assertEqual(len(orders), 48)
        self.assertEqual(len({tuple(order) for order in orders}), 48)
        self.assertEqual(orders[0], list(range(7)))
        prior = np.array([0.03, 0.07, 0.04, 0.28, 0.16, 0.37, 0.05])
        for order in orders:
            self.assertEqual(sorted(order), list(range(7)))
            self.assertEqual({order[3], order[5]}, {3, 5})
            self.assertEqual({order[j] for j in [0, 1, 2, 4]}, {0, 1, 2, 4})
            self.assertEqual(order[6], 6)
            values = prior[order]
            np.testing.assert_allclose(values[[3, 5]].sum(), 0.65)
            np.testing.assert_allclose(values[[0, 1, 2, 4]].sum(), 0.3)
            np.testing.assert_array_equal(np.sort(values), np.sort(prior))
        simple = b.block_equal(prior)
        np.testing.assert_allclose(simple, [0.075, 0.075, 0.075, 0.325, 0.075, 0.325, 0.05])
        self.assertFalse(np.array_equal(np.sort(simple), np.sort(prior)))
        specs = b.specs(prior)
        self.assertEqual(len(specs), 48)
        self.assertIn('block_equal', specs)
        self.assertEqual(sum((v[2] == 'optical_only' for v in specs.values())), 1)
        self.assertEqual(sum((v[2] == 'weather_only' for v in specs.values())), 23)
        self.assertEqual(sum((v[2] == 'both' for v in specs.values())), 23)
if __name__ == '__main__':
    raise SystemExit('Use scripts/train_mainline.py for mainline fitting or the saved-result analysis scripts. This historical entry is retained for method provenance, not default execution.')
