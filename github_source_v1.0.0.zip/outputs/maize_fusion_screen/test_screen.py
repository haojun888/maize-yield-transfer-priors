import sys as _sys
from pathlib import Path as _Path
_release_root = _Path(__file__).resolve().parents[2]
_sys.path.insert(0, str(_release_root))
from release_support import configured_path as _configured_path, prepare_transfer as _prepare_transfer
import unittest
import numpy as np
import torch
import screen as s

class ScreenChecks(unittest.TestCase):

    def test_new_optical_group_uses_its_own_values_and_flags(self):
        torch.manual_seed(42)
        model = s.Teacher(10, s.GROUPS).eval()
        x = torch.randn(2, 4, 21)
        soil = torch.randn(2, 2)
        lengths = torch.tensor([4, 3])
        with torch.no_grad():
            original = model.encode(x, soil, lengths)
            changed = x.clone()
            changed[:, :, 9] += 2
            changed[:, :, 19] = 0
            updated = model.encode(changed, soil, lengths)
        torch.testing.assert_close(original[:, [0, 1, 2, 3, 4, 6]], updated[:, [0, 1, 2, 3, 4, 6]])
        self.assertGreater(float((original[:, 5] - updated[:, 5]).abs().sum()), 0)

    def test_partition_and_training_only_background(self):
        years = np.repeat(np.arange(2004, 2024), 100)
        split = s.make_split(years)
        self.assertTrue(np.all(sum((split[k].astype(int) for k in ['train', 'val', 'test'])) == 1))
        self.assertFalse(np.any(split['teacher_fit'] & split['prior']))
        self.assertTrue(np.all(~split['prior'] | split['train']))
        np.testing.assert_array_equal(split['test'], s.make_split(years)['test'])
        counties = np.tile(np.array(['a', 'b']), 1000)
        y = np.arange(2000, dtype=np.float32)
        bg = s.county_background(y, counties, split['train'])
        altered = y.copy()
        altered[~split['train']] += 100000
        np.testing.assert_array_equal(bg, s.county_background(altered, counties, split['train']))

    def test_gate_normalization_guidance_and_capacity(self):
        head = torch.nn.Sequential(torch.nn.Linear(16, 32), torch.nn.ReLU(), torch.nn.Dropout(0.1), torch.nn.Linear(32, 1))
        bank = torch.randn(12, 7, 16)
        prior = np.array([0.1, 0.1, 0.1, 0.1, 0.1, 0.2, 0.3])
        fixed = s.Fusion(head, 'fixed', prior).eval()
        _, w = fixed(bank, True)
        torch.testing.assert_close(w[0], torch.tensor(prior, dtype=torch.float32))
        learned = s.Fusion(head, 'learned', prior).eval()
        _, w = learned(bank, True)
        torch.testing.assert_close(w.sum(1), torch.ones(12))
        torch.testing.assert_close(w, torch.full_like(w, 1 / 7))
        loss = s.kl_prior(w, learned.prior)
        loss.backward()
        self.assertGreater(float(learned.gate[-1].bias.grad.abs().sum()), 0)
        capacity = s.Fusion(head, 'capacity', prior).eval()
        n = lambda model: sum((p.numel() for p in model.parameters()))
        self.assertLessEqual(abs(n(learned) - n(capacity)), 18)
        torch.testing.assert_close(capacity(bank), s.Fusion(head, 'uniform', prior).eval()(bank))
if __name__ == '__main__':
    raise SystemExit('Use scripts/train_mainline.py for mainline fitting or the saved-result analysis scripts. This historical entry is retained for method provenance, not default execution.')
