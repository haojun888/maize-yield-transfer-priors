import sys as _sys
from pathlib import Path as _Path
_release_root = _Path(__file__).resolve().parents[2]
_sys.path.insert(0, str(_release_root))
from release_support import configured_path as _configured_path, prepare_transfer as _prepare_transfer
'Random county-year fusion screen. See design.md for interpretation limits.'
import copy
import functools
import hashlib
import json
import sys
import time
from pathlib import Path
import numpy as np
import pandas as pd
import torch
from torch import nn
from torch.utils.data import DataLoader, TensorDataset
OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
CACHE = ROOT / 'work/maize_fusion_screen'
sys.path.insert(0, str(ROOT / 'outputs/maize_fixed_gates'))
import gates as g
e = g.e
DEVICE = g.DEVICE
SEEDS = [42, 2026, 3407]
INPUTS = ['gdd_evi']
STRENGTHS = [0.25, 0.5, 1.0]
GROUPS = [[0, 1, 2], [3, 4, 7], [5], [6], [8], [9]]
NAMES = ['thermal', 'water', 'radiation', 'ndvi', 'gdd', 'evi', 'soil']

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def save(path, value):
    e.save_json(Path(path), value)

def make_split(years):
    rng = np.random.default_rng(20261007)
    result = {k: np.zeros(len(years), dtype=bool) for k in ['train', 'val', 'test', 'teacher_fit', 'teacher_val', 'prior']}
    for year in np.unique(years):
        ids = rng.permutation(np.flatnonzero(years == year))
        a = int(0.7 * len(ids))
        b = a + int(0.15 * len(ids))
        result['train'][ids[:a]] = True
        result['val'][ids[a:b]] = True
        result['test'][ids[b:]] = True
        inner = rng.permutation(ids[:a])
        c = int(0.7 * a)
        d = c + int(0.15 * a)
        result['teacher_fit'][inner[:c]] = True
        result['teacher_val'][inner[c:d]] = True
        result['prior'][inner[d:]] = True
    return result

def county_background(y, counties, fit):
    means = {c: float(y[fit & (counties == c)].mean()) for c in np.unique(counties[fit])}
    fallback = float(y[fit].mean())
    return np.array([means.get(c, fallback) for c in counties], dtype=np.float32)

class Teacher(nn.Module):

    def __init__(self, width, groups):
        super().__init__()
        self.width = width
        self.groups = groups
        self.encoders = nn.ModuleList([nn.LSTM(2 * len(idx) + 1, 16, batch_first=True) for idx in groups])
        self.soil = nn.Sequential(nn.Linear(2, 16), nn.Tanh(), nn.Linear(16, 16))
        self.head = nn.Sequential(nn.Linear(16, 32), nn.ReLU(), nn.Dropout(0.1), nn.Linear(32, 1))

    def encode(self, x, soil, lengths):
        vectors = []
        for encoder, idx in zip(self.encoders, self.groups):
            features = torch.cat([x[:, :, idx], x[:, :, [i + self.width for i in idx]], x[:, :, 2 * self.width:2 * self.width + 1]], dim=2)
            packed = nn.utils.rnn.pack_padded_sequence(features, lengths.cpu(), batch_first=True, enforce_sorted=False)
            _, (hidden, _) = encoder(packed)
            vectors.append(nn.functional.normalize(hidden[-1], dim=1, eps=1e-06))
        vectors.append(nn.functional.normalize(self.soil(soil), dim=1, eps=1e-06))
        return torch.stack(vectors, dim=1)

    def forward(self, x, soil, lengths):
        return self.head(self.encode(x, soil, lengths).mean(1)).squeeze(1)

class Fusion(nn.Module):

    def __init__(self, template, mode, prior):
        super().__init__()
        self.mode = mode
        self.groups = len(prior)
        self.register_buffer('prior', torch.as_tensor(prior, dtype=torch.float32))
        self.head = copy.deepcopy(template)
        if mode == 'capacity':
            width = round((577 + (16 * self.groups + 1) * 32 + 33 * self.groups - 1) / 18)
            self.head = nn.Sequential(nn.Linear(16, width), nn.ReLU(), nn.Dropout(0.1), nn.Linear(width, 1))
            with torch.no_grad():
                self.head[0].weight[:32].copy_(template[0].weight)
                self.head[0].bias[:32].copy_(template[0].bias)
                self.head[3].weight.zero_()
                self.head[3].weight[:, :32].copy_(template[3].weight)
                self.head[3].bias.copy_(template[3].bias)
        if mode == 'learned':
            self.gate = nn.Sequential(nn.Linear(16 * self.groups, 32), nn.ReLU(), nn.Linear(32, self.groups))
            nn.init.zeros_(self.gate[-1].weight)
            nn.init.zeros_(self.gate[-1].bias)
        for p in self.parameters():
            p.requires_grad_(True)

    def forward(self, bank, return_weights=False):
        if self.mode == 'learned':
            weights = self.gate(bank.flatten(1)).softmax(1)
        elif self.mode == 'fixed':
            weights = self.prior[None, :].expand(len(bank), -1)
        else:
            weights = torch.full((len(bank), self.groups), 1 / self.groups, dtype=bank.dtype, device=bank.device)
        value = self.head((bank * weights[:, :, None]).sum(1)).squeeze(1)
        return (value, weights) if return_weights else value

def kl_prior(weights, prior):
    return (prior * (prior.log() - weights.clamp_min(torch.finfo(weights.dtype).tiny).log())).sum(1).mean()

def predict(model, bank, mean, std):
    model.eval()
    values = []
    weights = []
    with torch.no_grad():
        for chunk in np.array_split(bank, max(1, int(np.ceil(len(bank) / 512)))):
            pred, w = model(torch.from_numpy(chunk).to(DEVICE), True)
            values.append(pred.cpu().numpy() * std + mean)
            weights.append(w.cpu().numpy())
    return (np.concatenate(values), np.concatenate(weights))

def train(template, mode, prior, strength, bank, residual, fit, val, seed):
    g.seed_all(seed + 992)
    model = Fusion(template, mode, prior).to(DEVICE)
    g.seed_all(seed + 991)
    mean = float(residual[fit].mean())
    std = float(residual[fit].std())
    ds = TensorDataset(torch.from_numpy(bank[fit]), torch.from_numpy(((residual[fit] - mean) / std).astype(np.float32)))
    loader = DataLoader(ds, batch_size=512, shuffle=True, generator=torch.Generator().manual_seed(seed + 991), num_workers=0)
    optimizer = torch.optim.Adam(model.parameters(), lr=0.001, weight_decay=0.0001)
    best = float('inf')
    state = None
    stale = 0
    history = []
    bestepoch = 1
    for epoch in range(1, 61):
        model.train()
        total = np.zeros(3)
        for xb, yb in loader:
            optimizer.zero_grad(set_to_none=True)
            pred, w = model(xb.to(DEVICE), True)
            mse = nn.functional.mse_loss(pred, yb.to(DEVICE))
            kl = kl_prior(w, model.prior)
            loss = mse + strength * kl
            loss.backward()
            optimizer.step()
            total += np.array([float(loss.detach()), float(mse.detach()), float(kl.detach())]) * len(xb)
        p, _ = predict(model, bank[val], mean, std)
        score = e.metrics(residual[val], p)['rmse_t_ha']
        history.append({'epoch': epoch, 'train_loss': total[0] / len(ds), 'train_mse': total[1] / len(ds), 'train_kl': total[2] / len(ds), 'val_rmse': score})
        if score < best - 1e-05:
            best = score
            state = copy.deepcopy(model.state_dict())
            stale = 0
            bestepoch = epoch
        else:
            stale += 1
        if stale >= 8:
            break
    model.load_state_dict(state)
    return (model, mean, std, bestepoch, history, best)

def estimate_prior(teacher, bank, mask, seed, names):
    source = bank[mask]
    n = source.shape[1]
    u = torch.quasirandom.SobolEngine(2 * n, scramble=True, seed=seed + 51).draw_base2(12).numpy()
    a = np.minimum((u[:, :n] * len(source)).astype(int), len(source) - 1)
    b = np.minimum((u[:, n:] * len(source)).astype(int), len(source) - 1)

    def evaluate(indices):
        return g.bank_head_predict(teacher.head, source[indices, np.arange(n)[None, :]], np.ones(n) / n)
    fa = evaluate(a)
    fb = evaluate(b)
    mixed = []
    for j in range(n):
        ab = a.copy()
        ab[:, j] = b[:, j]
        mixed.append(evaluate(ab))
    fab = np.array(mixed)
    s1, st = g.sobol_indices(fa, fb, fab)
    _, small = g.sobol_indices(fa[:2048], fb[:2048], fab[:, :2048])
    prior = g.prior_weights(st)
    random, order = g.shuffle_weights(prior, seed + 700)
    return (prior, random, {'groups': names, 'prior_rows': int(mask.sum()), 's1': s1.tolist(), 'st_4096': st.tolist(), 'st_2048': small.tolist(), 'prior': prior.tolist(), 'shuffled': random.tolist(), 'shuffle_order': order.tolist(), 'scope': 'Independent empirical whole-group latent combinations; not causal/physical importance'})

def prepare():
    raise RuntimeError('This release starts from work/maize_fusion_screen/gdd_evi.npz. Raw preparation routines are supplied separately; legacy FPAR preparation is excluded.')

def groups_for(variant):
    assert variant == 'gdd_evi'
    return (copy.deepcopy(GROUPS), NAMES.copy())

def context(variant, seed, split, bg):
    folder = OUT / f'{variant}_{seed}'
    folder.mkdir(exist_ok=True)
    d = np.load(CACHE / f'{variant}.npz')
    groups, names = groups_for(variant)
    seq, soil, params = e.prepare_arrays(d['x'], d['static'], d['lengths'], split['teacher_fit'])
    residual = (d['y'] - bg).astype(np.float32)
    if not all(((folder / name).exists() for name in ['teacher.pt', 'bank.npy', 'preprocessing.json', 'priors.json', 'teacher_history.csv'])):
        g.Teacher = functools.partial(Teacher, d['x'].shape[2], groups)
        teacher, bank, ym, ys, epoch, history = g.train_teacher(seq, soil, d['lengths'], residual, split['teacher_fit'], split['teacher_val'], seed)
        torch.save({'state_dict': teacher.cpu().state_dict(), 'target_mean': ym, 'target_std': ys, 'epoch': epoch, 'width': d['x'].shape[2], 'groups': groups}, folder / 'teacher.pt')
        teacher = teacher.to(DEVICE)
        np.save(folder / 'bank.npy', bank)
        save(folder / 'preprocessing.json', params)
        pd.DataFrame(history).to_csv(folder / 'teacher_history.csv', index=False)
        _, _, details = estimate_prior(teacher, bank, split['prior'], seed, names)
        save(folder / 'priors.json', details)
    ck = torch.load(folder / 'teacher.pt', weights_only=True, map_location='cpu')
    teacher = Teacher(ck['width'], ck['groups']).to(DEVICE)
    teacher.load_state_dict(ck['state_dict'])
    teacher.eval()
    for p in teacher.parameters():
        p.requires_grad_(False)
    bank = np.load(folder / 'bank.npy')
    prior = json.loads((folder / 'priors.json').read_text())
    return (folder, d, teacher, bank, residual, prior, names)

def run():
    start = time.time()
    fp, split, bg = prepare()
    rows = []
    for variant in INPUTS:
        for seed in SEEDS:
            folder, d, teacher, bank, residual, priors, names = context(variant, seed, split, bg)
            weights = {'sobol': priors['prior'], 'random': priors['shuffled'], 'uniform': np.ones(len(names)) / len(names)}
            tasks = [('uniform', 'uniform', 'uniform', 0.0), ('sobol_fixed', 'fixed', 'sobol', 0.0), ('random_fixed', 'fixed', 'random', 0.0), ('learned', 'learned', 'uniform', 0.0), ('capacity', 'capacity', 'uniform', 0.0)]
            tasks += [(f'guided_{family}_{strength:g}', 'learned', family, strength) for family in weights for strength in STRENGTHS]
            for name, mode, family, strength in tasks:
                checkpoint = folder / f'{name}.pt'
                selection = folder / f'{name}.json'
                if not checkpoint.exists():
                    model, ym, ys, epoch, history, score = train(teacher.head, mode, weights[family], strength, bank, residual, split['train'], split['val'], seed)
                    torch.save({'state_dict': model.cpu().state_dict(), 'mode': mode, 'prior': [float(p) for p in weights[family]], 'strength': strength, 'target_mean': ym, 'target_std': ys, 'epoch': epoch, 'parameters': sum((p.numel() for p in model.parameters())), 'fingerprint': fp}, checkpoint)
                    save(selection, {'input': variant, 'seed': seed, 'candidate': name, 'family': family, 'strength': strength, 'val_rmse': score, 'epoch': epoch})
                    pd.DataFrame(history).to_csv(folder / f'{name}_history.csv', index=False)
                    print('CANDIDATE', variant, seed, name, score, flush=True)
                rows.append(json.loads(selection.read_text()))
    candidates = pd.DataFrame(rows)
    candidates.to_csv(OUT / 'validation_candidates.csv', index=False)
    choices = {}
    for variant in INPUTS:
        choices[variant] = {}
        for family in ['sobol', 'random', 'uniform']:
            frame = candidates[(candidates.input == variant) & (candidates.family == family) & (candidates.strength > 0)]
            choices[variant][family] = float(frame.groupby('strength').val_rmse.mean().sort_values().index[0])
    save(OUT / 'selection_complete.json', {'fingerprint': fp, 'choices': choices, 'candidate_models': len(rows), 'test_predictions_started': False})
    frames = []
    wframes = []
    for variant in INPUTS:
        for seed in SEEDS:
            folder, d, teacher, bank, residual, priors, names = context(variant, seed, split, bg)
            tasks = [(v, v) for v in ['uniform', 'sobol_fixed', 'random_fixed', 'learned', 'capacity']]
            tasks += [(f'guided_{f}', f'guided_{f}_{choices[variant][f]:g}') for f in ['sobol', 'random', 'uniform']]
            for name, candidate in tasks:
                ck = torch.load(folder / f'{candidate}.pt', weights_only=True, map_location='cpu')
                assert ck['fingerprint'] == fp
                model = Fusion(teacher.head, ck['mode'], ck['prior']).to(DEVICE)
                model.load_state_dict(ck['state_dict'])
                pred, w = predict(model, bank[split['test']], ck['target_mean'], ck['target_std'])
                info = {'input': variant, 'seed': seed, 'variant': name, 'candidate': candidate, 'adm_id': d['counties'][split['test']], 'year': d['years'][split['test']]}
                frames.append(pd.DataFrame({**info, 'observed_yield_t_ha': d['y'][split['test']], 'predicted_yield_t_ha': pred + bg[split['test']]}))
                wframes.append(pd.DataFrame({**info, **{n: w[:, j] for j, n in enumerate(names)}}))
    pd.concat(frames, ignore_index=True).to_csv(OUT / 'predictions.csv', index=False)
    pd.concat(wframes, ignore_index=True).to_csv(OUT / 'weights.csv', index=False)
    save(OUT / 'run_complete.json', {'fingerprint': fp, 'teachers': 6, 'candidate_models': len(rows), 'evaluated_models': len(frames), 'runtime_seconds': time.time() - start})
    print('SCREEN TRAINING COMPLETE', time.time() - start, flush=True)
if __name__ == '__main__':
    raise SystemExit('Use scripts/train_mainline.py for mainline fitting or the saved-result analysis scripts. This historical entry is retained for method provenance, not default execution.')
