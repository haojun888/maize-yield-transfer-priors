import sys as _sys
from pathlib import Path as _Path
_release_root = _Path(__file__).resolve().parents[2]
_sys.path.insert(0, str(_release_root))
from release_support import configured_path as _configured_path, prepare_transfer as _prepare_transfer
import unittest
import numpy as np
from pilot import window_allowed, weighted_vi, axis_window

class Tests(unittest.TestCase):

    def test_axis_window_coordinates(self):
        self.assertEqual(axis_window((10, 80, 20, 90), (1, 0, 0, 0, -1, 100), (100, 100)), (10, 10, 10, 10))
        with self.assertRaises(ValueError):
            axis_window((10, 80, 20, 90), (1, 1, 0, 0, -1, 100), (100, 100))

    def test_whole_window_cutoff(self):
        self.assertFalse(window_allowed('2004-07-27', '2004-08-11', '2004-08-01'))
        self.assertTrue(window_allowed('2004-07-27', '2004-08-11', '2004-08-11'))

    def test_quality_and_missing_not_zero(self):
        value, coverage = weighted_vi(np.array([2000, 6000, -3000]), np.array([0, 3, 0]), np.array([2.0, 1.0, 1.0]))
        self.assertAlmostEqual(value, 0.2)
        self.assertAlmostEqual(coverage, 0.5)
        value, coverage = weighted_vi(np.array([-3000]), np.array([0]), np.array([1.0]))
        self.assertTrue(np.isnan(value))
        self.assertEqual(coverage, 0.0)
if __name__ == '__main__':
    raise SystemExit('Use scripts/train_mainline.py for mainline fitting or the saved-result analysis scripts. This historical entry is retained for method provenance, not default execution.')
