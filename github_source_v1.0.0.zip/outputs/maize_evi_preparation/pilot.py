import sys as _sys
from pathlib import Path as _Path
_release_root = _Path(__file__).resolve().parents[2]
_sys.path.insert(0, str(_release_root))
from release_support import configured_path as _configured_path, prepare_transfer as _prepare_transfer
'Real county EVI/NDVI pilot using audited complete compositing windows.'
import json
import math
import sys
from datetime import date
from pathlib import Path
import numpy as np
OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]

def window_allowed(start, end, cutoff):
    start = date.fromisoformat(start[:10])
    end = date.fromisoformat(end[:10])
    cutoff = date.fromisoformat(cutoff[:10])
    return start <= end <= cutoff

def weighted_vi(raw, reliability, weights):
    raw = np.asarray(raw)
    weights = np.asarray(weights, dtype=float)
    active = np.isfinite(weights) & (weights > 0)
    total = weights[active].sum()
    good = active & (np.asarray(reliability) == 0) & np.isfinite(raw) & (raw >= -2000) & (raw <= 10000)
    observed = weights[good].sum()
    return (float(np.sum(raw[good] * weights[good]) / observed * 0.0001) if observed > 0 else float('nan'), float(observed / total) if total > 0 else 0.0)

def axis_window(bounds, coefficients, shape):
    a, b, c, d, e, f = coefficients
    if b != 0 or d != 0 or a <= 0 or (e >= 0):
        raise ValueError('Expected north-up axis-aligned grid')
    left, bottom, right, top = bounds
    col = math.floor((left - c) / a)
    row = math.floor((top - f) / e)
    lastcol = math.ceil((right - c) / a)
    lastrow = math.ceil((bottom - f) / e)
    if col < 0 or row < 0 or lastcol > shape[1] or (lastrow > shape[0]):
        raise ValueError('Pilot county crosses tile; needs mosaic')
    return (col, row, lastcol - col, lastrow - row)

def run():
    import faulthandler
    faulthandler.enable()
    print('Pilot bootstrap', flush=True)
    sys.path.insert(0, str(ROOT / 'work/evi_libs'))
    import rasterio
    import shapefile
    from rasterio.features import geometry_mask, bounds
    from rasterio.windows import Window
    from rasterio.warp import transform_geom
    from rasterio.vrt import WarpedVRT
    from rasterio.enums import Resampling
    import certifi
    print('Spatial imports ready', flush=True)
    items = json.loads((OUT / 'stac_pilot.json').read_text())['features']
    item = next((f for f in items if f['properties']['modis:horizontal-tile'] == 11 and f['properties']['platform'] == 'terra'))
    county = 'US-19-103'
    reader = shapefile.Reader(str(ROOT / 'work/evi_geometry/US.shp'))
    shape = next((f.shape.__geo_interface__ for f in reader.iterShapeRecords() if f.record['adm_id'] == county))
    props = item['properties']
    start = props['start_datetime'][:10]
    end = props['end_datetime'][:10]
    import pandas as pd
    windows = pd.read_csv(ROOT / 'outputs/maize_baseline/date_windows.csv')
    cutoff = windows[(windows.adm_id == county) & (windows.year == 2004)].cutoff.iloc[0]
    assert window_allowed(start, end, cutoff)
    token = json.loads((ROOT / 'work/pc_sas.json').read_text())['token']

    def url(key):
        return item['assets'][key]['href'] + '?' + token
    bands = ['250m_16_days_EVI', '250m_16_days_NDVI', '250m_16_days_pixel_reliability', '250m_16_days_composite_day_of_the_year']
    arrays = []
    print('County, dates and source ready', flush=True)
    try:
        with rasterio.Env(GDAL_DISABLE_READDIR_ON_OPEN='EMPTY_DIR', CPL_VSIL_CURL_ALLOWED_EXTENSIONS='.tif', GDAL_HTTP_TIMEOUT='20', CURL_CA_BUNDLE=certifi.where()):
            with rasterio.open(url(bands[0])) as ds:
                print('Cloud header opened', flush=True)
                geom = transform_geom('EPSG:4326', ds.crs, shape)
                window = Window(*axis_window(bounds(geom), tuple(ds.transform)[:6], ds.shape))
                transform = ds.window_transform(window)
                arrays.append(ds.read(1, window=window))
                crs = ds.crs
                print('EVI county window read', flush=True)
                inside = geometry_mask([geom], out_shape=arrays[0].shape, transform=transform, invert=True)
                assert ds.width == 4800 and ds.height == 4800
                with rasterio.open(ROOT / 'work/evi_geometry/crop_mask_maize_WC.tif') as mask:
                    with WarpedVRT(mask, crs=ds.crs, transform=ds.transform, width=ds.width, height=ds.height, resampling=Resampling.average) as vrt:
                        crop = vrt.read(1, window=window).astype(float)
            for key in bands[1:]:
                with rasterio.open(url(key)) as ds:
                    assert ds.crs == crs and ds.window_transform(window) == transform
                    arrays.append(ds.read(1, window=window))
    except Exception as exc:
        raise RuntimeError('Cloud raster read failed: ' + type(exc).__name__ + '; signed URL withheld') from None
    evi, ndvi, quality, doy = arrays
    weight = np.where(inside & np.isfinite(crop) & (crop > 0) & (crop <= 100), crop, 0.0)
    start_doy = date.fromisoformat(start).timetuple().tm_yday
    end_doy = date.fromisoformat(end).timetuple().tm_yday
    common = (evi >= -2000) & (evi <= 10000) & (ndvi >= -2000) & (ndvi <= 10000) & (doy >= start_doy) & (doy <= end_doy)
    quality = np.where(common, quality.astype(np.int16), -1)
    evi_mean, coverage = weighted_vi(evi, quality, weight)
    ndvi_mean, coverage2 = weighted_vi(ndvi, quality, weight)
    assert np.isfinite(evi_mean) and np.isfinite(ndvi_mean) and (coverage == coverage2) and (coverage > 0)
    valid = (quality == 0) & (weight > 0)
    row = {'adm_id': county, 'year': 2004, 'item_id': item['id'], 'collection': 'modis-13Q1-061', 'sensor': 'terra', 'period_start': start, 'period_end': end, 'prediction_cutoff': cutoff, 'whole_window_before_cutoff': True, 'pixel_observation_doy_min': int(doy[valid].min()), 'pixel_observation_doy_max': int(doy[valid].max()), 'evi': evi_mean, 'matched_ndvi': ndvi_mean, 'valid_crop_weight_fraction': coverage, 'valid_pixels': int(valid.sum()), 'crop_pixels': int((weight > 0).sum()), 'source_created': props['created'], 'actual_historical_release_certified': False, 'aggregation': 'native250m, county pixel centers, original static maize mask resampled by average, reliability0, common EVI/NDVI/DOY valid pixels', 'unsigned_assets': {k: item['assets'][k]['href'] for k in bands}}
    pd.DataFrame([{k: v for k, v in row.items() if k != 'unsigned_assets'}]).to_csv(OUT / 'pilot_county_features.csv', index=False)
    (OUT / 'pilot_verification.json').write_text(json.dumps({'verified': True, 'row': row, 'no_future_window_used': True, 'signed_urls_saved_in_outputs': False}, indent=2), encoding='utf-8')
    print(json.dumps({k: row[k] for k in ['adm_id', 'period_start', 'period_end', 'evi', 'matched_ndvi', 'valid_crop_weight_fraction', 'valid_pixels']}), flush=True)
if __name__ == '__main__':
    raise SystemExit('Use scripts/train_mainline.py for mainline fitting or the saved-result analysis scripts. This historical entry is retained for method provenance, not default execution.')
