import sys as _sys
from pathlib import Path as _Path
_release_root = _Path(__file__).resolve().parents[2]
_sys.path.insert(0, str(_release_root))
from release_support import configured_path as _configured_path, prepare_transfer as _prepare_transfer
'Independent checks of native optical aggregates and unchanged model samples.'
import hashlib
import json
import re
from datetime import date, timedelta
from pathlib import Path
import numpy as np
import pandas as pd
OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
WORK = ROOT / 'work/evi_full'

def run():
    complete = json.loads((OUT / 'full_complete.json').read_text())
    assert complete['complete']
    deps = json.loads((OUT / 'dependency_snapshot.json').read_text())
    for name, digest in deps['files'].items():
        assert hashlib.sha256(Path(name).read_bytes()).hexdigest() == digest
    manifest = json.loads((OUT / 'full_manifest.json').read_text())
    counties = manifest['county_ids']
    items = json.loads((OUT / 'selected_items.json').read_text())
    assert len(items) == complete['tile_period_tasks'] == 1674 and len(counties) == 1015
    n = len(counties) + 1
    gross = np.zeros(n)
    tilegross = {}
    for path in WORK.glob('geometry_*.npz'):
        g = np.load(path)
        value = np.bincount(g['labels'].ravel(), weights=g['weight'].ravel(), minlength=n)
        assert np.isfinite(g['weight']).all() and (g['weight'] >= 0).all() and (g['weight'] <= 100).all()
        key = tuple((int(v) for v in path.stem.split('_')[1:]))
        tilegross[key] = value
        gross += value
    assert (gross[1:] > 0).all()
    merged = {}
    hashes = {}
    provenance = []
    for item in items:
        p = item['properties']
        start = p['start_datetime'][:10]
        end = p['end_datetime'][:10]
        year, doy = map(int, re.search('\\.A(\\d{4})(\\d{3})\\.', item['id']).groups())
        assert start == str(date(year, 1, 1) + timedelta(days=doy - 1)) and end == str(date.fromisoformat(start) + timedelta(days=15))
        assert p['platform'] == 'terra'
        path = WORK / (item['id'] + '.npz')
        g = np.load(path)
        tile = tilegross[p['modis:horizontal-tile'], p['modis:vertical-tile']]
        for name in ['evi_sum', 'ndvi_sum', 'valid_weight', 'valid_pixels']:
            assert g[name].shape == (n,) and np.isfinite(g[name]).all()
        vw = g['valid_weight']
        assert (vw >= 0).all() and (g['valid_pixels'] >= 0).all()
        assert (vw <= tile + 0.001).all()
        for name in ['evi_sum', 'ndvi_sum']:
            assert (g[name] >= -0.2 * vw - 1e-05).all() and (g[name] <= vw + 1e-05).all()
        sums = merged.setdefault((start, end), [np.zeros(n) for _ in range(3)])
        for dest, name in zip(sums, ['evi_sum', 'ndvi_sum', 'valid_weight']):
            dest += g[name]
        hashes[item['id']] = hashlib.sha256(path.read_bytes()).hexdigest()
        provenance.append({'item_id': item['id'], 'period_start': start, 'period_end': end, 'sensor': 'terra', 'source_created': p['created'], 'tile_h': p['modis:horizontal-tile'], 'tile_v': p['modis:vertical-tile']})
    table = pd.read_csv(OUT / 'county_period_features.csv', parse_dates=['period_start', 'period_end', 'cutoff'])
    windows = pd.read_csv(ROOT / 'outputs/maize_baseline/date_windows.csv', parse_dates=['start', 'cutoff'])
    assert not table.duplicated(['adm_id', 'year', 'period_start']).any()
    combined = table.merge(windows[['adm_id', 'year', 'start', 'cutoff']], on=['adm_id', 'year'], validate='many_to_one', suffixes=('', '_reference'))
    assert len(combined) == 218608
    assert (combined.period_start >= combined.start).all() and (combined.period_end <= combined.cutoff_reference).all() and (combined.cutoff == combined.cutoff_reference).all()
    positions = {c: i + 1 for i, c in enumerate(counties)}
    for start, end in merged:
        sub = combined[(combined.period_start == start) & (combined.period_end == end)]
        ids = np.array([positions[c] for c in sub.adm_id])
        es, ns, vw = merged[start, end]
        coverage = vw[ids] / gross[ids]
        np.testing.assert_allclose(sub.valid_crop_weight_fraction, coverage, rtol=1e-07, atol=1e-08)
        observed = (coverage >= 0.2) & (vw[ids] > 0)
        assert np.array_equal(sub.observed.to_numpy(), observed)
        assert np.isfinite(sub.evi).to_numpy().tolist() == observed.tolist() and np.isfinite(sub.matched_ndvi).to_numpy().tolist() == observed.tolist()
        np.testing.assert_allclose(sub.evi.to_numpy()[observed], es[ids][observed] / vw[ids][observed], rtol=1e-07, atol=1e-08)
        np.testing.assert_allclose(sub.matched_ndvi.to_numpy()[observed], ns[ids][observed] / vw[ids][observed], rtol=1e-07, atol=1e-08)
    base = np.load(ROOT / 'work/maize_baseline/dataset.npz')
    cache = ROOT / 'work/maize_evi_datasets'
    baseextra = np.load(cache / 'base_plus_evi.npz')['x'][:, :, 8]
    table['bin'] = ((table.period_end - pd.to_datetime(table.merge(windows[['adm_id', 'year', 'start']], on=['adm_id', 'year'], validate='many_to_one').start)).dt.days // 10).astype(int)
    stats = table.groupby(['adm_id', 'year', 'bin'])[['evi', 'matched_ndvi']].mean()
    expected = np.full((*base['x'].shape[:2], 2), np.nan, dtype=np.float32)
    lookup = {(c, int(y)): i for i, (c, y) in enumerate(zip(base['counties'], base['years']))}
    for (c, y, b), row in stats.iterrows():
        expected[lookup[c, y], b] = row.to_numpy(dtype=np.float32)
    dataset_hashes = {}
    for name, column in [('base_plus_evi', 0), ('base_plus_matched_ndvi', 1), ('gdd_plus_evi', 0)]:
        path = cache / f'{name}.npz'
        g = np.load(path)
        np.testing.assert_array_equal(g['x'][:, :, :8], base['x'])
        for k in ['y', 'years', 'counties', 'static', 'lengths']:
            np.testing.assert_array_equal(g[k], base[k])
        np.testing.assert_array_equal(g['x'][:, :, -1], expected[:, :, column])
        if name == 'gdd_plus_evi':
            np.testing.assert_array_equal(g['x'][:, :, 8], np.load(ROOT / 'work/maize_weather_ablation/gdd_only.npz')['x'][:, :, 8])
        dataset_hashes[name] = hashlib.sha256(path.read_bytes()).hexdigest()
    gdd = np.load(ROOT / 'work/maize_weather_ablation/gdd_only.npz')
    path = cache / 'gdd_plus_matched_ndvi.npz'
    np.savez_compressed(path, **{**{k: base[k] for k in base.files}, 'x': np.concatenate([gdd['x'], expected[:, :, 1:]], axis=2)})
    dataset_hashes['gdd_plus_matched_ndvi'] = hashlib.sha256(path.read_bytes()).hexdigest()
    pd.DataFrame(provenance).to_csv(OUT / 'source_item_provenance.csv', index=False)
    monthly = table.groupby(['year', table.period_end.dt.month]).agg(rows=('adm_id', 'size'), observed=('observed', 'sum'), mean_coverage=('valid_crop_weight_fraction', 'mean')).reset_index()
    monthly.to_csv(OUT / 'quality_by_year_month.csv', index=False)
    bysample = table.groupby(['adm_id', 'year']).agg(periods=('observed', 'size'), valid_periods=('observed', 'sum'), mean_coverage=('valid_crop_weight_fraction', 'mean')).reset_index()
    bysample.to_csv(OUT / 'quality_by_county_year.csv', index=False)
    expected_starts = {str(date(2023, 1, 1) + timedelta(days=k * 16)) for k in range(23)}
    selected_starts = {s for s, e in merged if s.startswith('2023')}
    year2023 = pd.read_csv(OUT / 'inventory_items.csv')
    present = set(year2023[year2023.year == 2023].period_start)
    gaps = sorted(expected_starts - present)
    result = {'verified': True, 'native250m': True, 'samples': 17303, 'counties': 1015, 'county_period_rows': len(table), 'tile_tasks': len(items), 'matched_valid_pixels': True, 'full_window_cutoff_checked': True, 'original_base_arrays_unchanged': True, 'dataset_sha256': dataset_hashes, 'tile_cache_sha256': hashes, 'source_gap_2023_period_start': gaps, 'actual_historical_release_certified': False, 'verify_code_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    (OUT / 'full_verification.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
    print('All native county features and model caches verified.', flush=True)
if __name__ == '__main__':
    raise SystemExit('Use scripts/train_mainline.py for mainline fitting or the saved-result analysis scripts. This historical entry is retained for method provenance, not default execution.')
