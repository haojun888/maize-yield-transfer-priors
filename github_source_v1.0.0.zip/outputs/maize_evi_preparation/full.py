import sys as _sys
from pathlib import Path as _Path
_release_root = _Path(__file__).resolve().parents[2]
_sys.path.insert(0, str(_release_root))
from release_support import configured_path as _configured_path, prepare_transfer as _prepare_transfer
'Native MODIS county aggregation with resumable tile-period tasks.'
import concurrent.futures
import hashlib
import json
import sys
import subprocess
from datetime import datetime, timezone
from pathlib import Path
import numpy as np
import pandas as pd
from pilot import window_allowed, weighted_vi
OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
WORK = ROOT / 'work/evi_full'
WORK.mkdir(exist_ok=True)
sys.path.insert(0, str(ROOT / 'work/evi_libs'))
import rasterio
import shapefile
from rasterio.features import rasterize, bounds
from rasterio.warp import transform_geom
from rasterio.vrt import WarpedVRT
from rasterio.enums import Resampling
from rasterio.windows import Window
from affine import Affine
import certifi
BANDS = ['250m_16_days_EVI', '250m_16_days_NDVI', '250m_16_days_pixel_reliability', '250m_16_days_composite_day_of_the_year']
ENV = {'GDAL_DISABLE_READDIR_ON_OPEN': 'EMPTY_DIR', 'CPL_VSIL_CURL_ALLOWED_EXTENSIONS': '.tif', 'GDAL_HTTP_TIMEOUT': '30', 'CURL_CA_BUNDLE': certifi.where(), 'CPL_LOG': 'NUL', 'GDAL_CACHEMAX': 64 * 1024 * 1024}

def token():
    import os
    value = os.environ.get('MAIZE_DATA_ACCESS_TOKEN')
    if not value:
        raise RuntimeError('Set MAIZE_DATA_ACCESS_TOKEN for authenticated downloads; no credentials are distributed.')
    return value

def inventory():
    items = []
    for path in sorted(OUT.glob('inventory_page_*.json')):
        items.extend(json.loads(path.read_text())['features'])
    unique = {}
    duplicates = []
    for item in items:
        p = item['properties']
        year = int(p['start_datetime'][:4])
        if not 2004 <= year <= 2023:
            continue
        key = (p['modis:horizontal-tile'], p['modis:vertical-tile'], p['start_datetime'])
        if key in unique:
            old = unique[key]
            duplicates.append({'key': str(key), 'first': old['id'], 'second': item['id']})
            if (p['created'], item['id']) > (old['properties']['created'], old['id']):
                unique[key] = item
        else:
            unique[key] = item
    (OUT / 'duplicate_versions.json').write_text(json.dumps(duplicates, indent=2), encoding='utf-8')
    return sorted(unique.values(), key=lambda f: (f['properties']['start_datetime'], f['id']))

def geometry(items, countyids):
    reader = shapefile.Reader(str(ROOT / 'work/evi_geometry/US.shp'))
    lookup = {c: i + 1 for i, c in enumerate(countyids)}
    geoms = [(r.shape.__geo_interface__, lookup[r.record['adm_id']]) for r in reader.iterShapeRecords() if r.record['adm_id'] in lookup]
    assert len(geoms) == len(countyids)
    representatives = {}
    for item in items:
        p = item['properties']
        representatives.setdefault((p['modis:horizontal-tile'], p['modis:vertical-tile']), item)
    tiles = {}
    for key, item in representatives.items():
        path = WORK / f'geometry_{key[0]}_{key[1]}.npz'
        if path.exists():
            tiles[key] = path
            continue
        with rasterio.Env(**ENV):
            with rasterio.open(item['assets'][BANDS[0]]['href'] + '?' + token()) as ds:
                local = []
                for geom, index in geoms:
                    g = transform_geom('EPSG:4326', ds.crs, geom)
                    left, bottom, right, top = bounds(g)
                    if right > ds.bounds.left and left < ds.bounds.right and (top > ds.bounds.bottom) and (bottom < ds.bounds.top):
                        local.append((g, index))
                if not local:
                    continue
                labels = rasterize(local, out_shape=ds.shape, transform=ds.transform, dtype='uint16')
                active = labels > 0
                if not active.any():
                    continue
                rows, cols = np.where(active)
                r0, r1 = (int(rows.min()), int(rows.max() + 1))
                c0, c1 = (int(cols.min()), int(cols.max() + 1))
                window = Window(c0, r0, c1 - c0, r1 - r0)
                labels = labels[r0:r1, c0:c1]
                with rasterio.open(ROOT / 'work/evi_geometry/crop_mask_maize_WC.tif') as mask:
                    with WarpedVRT(mask, crs=ds.crs, transform=ds.transform, width=ds.width, height=ds.height, resampling=Resampling.average, dtype='float32') as vrt:
                        weight = vrt.read(1, window=window)
                weight = np.where((labels > 0) & np.isfinite(weight) & (weight > 0) & (weight <= 100), weight, 0).astype(np.float32)
                if not (weight > 0).any():
                    continue
                np.savez_compressed(path, labels=labels, weight=weight, window=np.array([c0, r0, c1 - c0, r1 - r0]), transform=np.array(tuple(ds.transform)[:6]), crs=np.array(ds.crs.to_wkt()))
                tiles[key] = path
                print('Geometry ready', key, int((weight > 0).sum()), flush=True)
    return tiles

def extract(item, path, sas, ncounties):
    output = WORK / (item['id'] + '.npz')
    if output.exists():
        return (item['id'], 'cached')
    geometry = np.load(path)
    labels = geometry['labels']
    weight = geometry['weight']
    win = Window(*[int(v) for v in geometry['window']])
    arrays = []
    try:
        with rasterio.Env(**ENV):
            for name in BANDS:
                with rasterio.open(item['assets'][name]['href'] + '?' + sas) as ds:
                    np.testing.assert_allclose(tuple(ds.transform)[:6], geometry['transform'], rtol=0, atol=1e-06)
                    assert ds.crs == rasterio.crs.CRS.from_wkt(str(geometry['crs']))
                    arrays.append(ds.read(1, window=win))
        evi, ndvi, quality, doy = arrays
        p = item['properties']
        start = pd.Timestamp(p['start_datetime'])
        end = pd.Timestamp(p['end_datetime'])
        good = (weight > 0) & (quality == 0) & (evi >= -2000) & (evi <= 10000) & (ndvi >= -2000) & (ndvi <= 10000) & (doy >= start.dayofyear) & (doy <= end.dayofyear)
        ids = labels[good]
        w = weight[good].astype(float)
        n = ncounties + 1
        ew = np.bincount(ids, weights=w * evi[good] * 0.0001, minlength=n)
        nw = np.bincount(ids, weights=w * ndvi[good] * 0.0001, minlength=n)
        valid = np.bincount(ids, weights=w, minlength=n)
        count = np.bincount(ids, minlength=n)
        np.savez_compressed(output, evi_sum=ew, ndvi_sum=nw, valid_weight=valid, valid_pixels=count)
        return (item['id'], 'done')
    except Exception as exc:
        return (item['id'], 'error:' + type(exc).__name__)

def run():
    windows = pd.read_csv(ROOT / 'outputs/maize_baseline/date_windows.csv', parse_dates=['start', 'cutoff'])
    countyids = sorted(windows.adm_id.unique())
    items = inventory()
    fingerprint = hashlib.sha256((hashlib.sha256(Path(__file__).read_bytes()).hexdigest() + hashlib.sha256((ROOT / 'work/evi_geometry/crop_mask_maize_WC.tif').read_bytes()).hexdigest() + hashlib.sha256((ROOT / 'outputs/maize_baseline/date_windows.csv').read_bytes()).hexdigest() + ''.join((f['id'] for f in items))).encode()).hexdigest()
    manifest = OUT / 'full_manifest.json'
    if manifest.exists():
        assert json.loads(manifest.read_text())['fingerprint'] == fingerprint
    else:
        manifest.write_text(json.dumps({'fingerprint': fingerprint, 'county_ids': countyids, 'native250m': True, 'workers': 4}, indent=2), encoding='utf-8')
    tiles = geometry(items, countyids)
    gross = np.zeros(len(countyids) + 1)
    for path in tiles.values():
        g = np.load(path)
        gross += np.bincount(g['labels'].ravel(), weights=g['weight'].ravel(), minlength=len(gross))
    period_years = {y: w for y, w in windows.groupby('year')}
    tasks = []
    for item in items:
        p = item['properties']
        key = (p['modis:horizontal-tile'], p['modis:vertical-tile'])
        year = int(p['start_datetime'][:4])
        start = pd.Timestamp(p['start_datetime']).tz_localize(None).normalize()
        end = pd.Timestamp(p['end_datetime']).tz_localize(None).normalize()
        w = period_years[year]
        if key in tiles and ((w.start <= start) & (w.cutoff >= end)).any():
            tasks.append((item, tiles[key]))
    (OUT / 'selected_items.json').write_text(json.dumps([item for item, _ in tasks]), encoding='utf-8')
    print('Selected tile-period tasks', len(tasks), 'counties', len(countyids), flush=True)
    errors = []
    completed = 0
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        for first in range(0, len(tasks), 16):
            sas = token()
            futures = [pool.submit(extract, item, path, sas, len(countyids)) for item, path in tasks[first:first + 16]]
            for future in concurrent.futures.as_completed(futures):
                itemid, status = future.result()
                completed += 1
                if status.startswith('error'):
                    errors.append({'id': itemid, 'status': status})
                if completed % 16 == 0:
                    print('Tile-periods processed', completed, '/', len(tasks), 'errors', len(errors), flush=True)
            (OUT / 'full_progress.json').write_text(json.dumps({'processed': completed, 'total': len(tasks), 'errors': errors, 'complete': False}), encoding='utf-8')
    if errors:
        raise RuntimeError('Some cloud tasks failed; cached successes preserved, see full_progress.json')
    grouped = {}
    for item, _ in tasks:
        p = item['properties']
        key = (p['start_datetime'][:10], p['end_datetime'][:10])
        g = np.load(WORK / (item['id'] + '.npz'))
        sums = grouped.setdefault(key, [np.zeros(len(gross)) for _ in range(4)])
        for total, name in zip(sums, ['evi_sum', 'ndvi_sum', 'valid_weight', 'valid_pixels']):
            total += g[name]
    records = []
    for (start, end), (es, ns, valid, count) in sorted(grouped.items()):
        year = int(start[:4])
        w = period_years[year].set_index('adm_id')
        for index, county in enumerate(countyids, 1):
            if county not in w.index or not window_allowed(start, end, str(w.loc[county, 'cutoff'].date())) or pd.Timestamp(start) < w.loc[county, 'start']:
                continue
            coverage = valid[index] / gross[index] if gross[index] > 0 else 0.0
            observed = coverage >= 0.2 and valid[index] > 0
            records.append({'adm_id': county, 'year': year, 'period_start': start, 'period_end': end, 'cutoff': str(w.loc[county, 'cutoff'].date()), 'evi': es[index] / valid[index] if observed else np.nan, 'matched_ndvi': ns[index] / valid[index] if observed else np.nan, 'valid_crop_weight_fraction': coverage, 'valid_pixels': int(count[index]), 'observed': observed})
    table = pd.DataFrame(records)
    table.to_csv(OUT / 'county_period_features.csv', index=False)
    base = np.load(ROOT / 'work/maize_baseline/dataset.npz')
    extra = np.full((*base['x'].shape[:2], 2), np.nan, dtype=np.float32)
    table = table.merge(windows[['adm_id', 'year', 'start']], on=['adm_id', 'year'], validate='many_to_one')
    table['bin'] = ((pd.to_datetime(table.period_end) - table.start).dt.days // 10).astype(int)
    stats = table.groupby(['adm_id', 'year', 'bin'])[['evi', 'matched_ndvi']].mean()
    lookup = {(c, int(y)): i for i, (c, y) in enumerate(zip(base['counties'], base['years']))}
    for (county, year, b), row in stats.iterrows():
        i = lookup[county, year]
        assert b < base['lengths'][i]
        extra[i, b] = row.to_numpy(dtype=np.float32)
    cache = ROOT / 'work/maize_evi_datasets'
    cache.mkdir(exist_ok=True)
    old = {k: base[k] for k in base.files}
    for name, added in [('base_plus_evi', extra[:, :, :1]), ('base_plus_matched_ndvi', extra[:, :, 1:])]:
        np.savez_compressed(cache / f'{name}.npz', **{**old, 'x': np.concatenate([base['x'], added], axis=2)})
    gdd = np.load(ROOT / 'work/maize_weather_ablation/gdd_only.npz')
    np.testing.assert_array_equal(gdd['x'][:, :, :8], base['x'])
    np.savez_compressed(cache / 'gdd_plus_evi.npz', **{**old, 'x': np.concatenate([gdd['x'], extra[:, :, :1]], axis=2)})
    validsteps = np.arange(extra.shape[1])[None, :] < base['lengths'][:, None]
    result = {'complete': True, 'fingerprint': fingerprint, 'tile_period_tasks': len(tasks), 'county_period_rows': len(table), 'samples': len(base['y']), 'counties': len(countyids), 'missing_evi_valid_steps': float(np.isnan(extra[:, :, 0][validsteps]).mean()), 'quality_min_weight_coverage': 0.2, 'whole_composite_window_cutoff': True, 'actual_historical_release_certified': False, 'native250m': True, 'dataset_cache': str(cache)}
    (OUT / 'full_complete.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
    print(json.dumps(result), flush=True)
if __name__ == '__main__':
    raise SystemExit('Use scripts/train_mainline.py for mainline fitting or the saved-result analysis scripts. This historical entry is retained for method provenance, not default execution.')
