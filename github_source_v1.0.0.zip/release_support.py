"""Path configuration and mainline-only provenance for the local release candidate."""
from pathlib import Path
import hashlib, json, os

ROOT=Path(__file__).resolve().parent

def configured_path(key):
    file=Path(os.environ.get('MAIZE_EXTERNAL_PATHS',ROOT/'config/external_paths.json'))
    values=json.loads(file.read_text(encoding='utf-8')) if file.exists() else {}
    value=values.get(key)
    if isinstance(value,dict):value=value.get('value')
    if not value:raise RuntimeError(f'Configure {key} in config/external_paths.json; see the example file.')
    return str(value)

def prepare_transfer(module):
    """Generate fresh provenance from the distributed mainline processed input."""
    import numpy as np
    import pandas as pd
    out=module.OUT;s=module.s;out.mkdir(parents=True,exist_ok=True)
    source=s.CACHE/'gdd_evi.npz'
    if not source.exists():raise FileNotFoundError(source)
    paths=[source,Path(module.__file__),Path(s.__file__),Path(s.g.__file__),Path(s.e.__file__),s.e.BASE/'train.py',s.e.BASE/'pipeline.py',Path(__file__)]
    hashes={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
    fingerprint=hashlib.sha256(json.dumps(hashes,sort_keys=True).encode()).hexdigest()
    marker=out/'manifest.json'
    if marker.exists():
        old=json.loads(marker.read_text(encoding='utf-8'))
        if old['fingerprint']!=fingerprint:raise RuntimeError('Existing release run has different inputs/code; choose a new run directory.')
        return fingerprint
    with np.load(source,allow_pickle=False) as data:
        counts={}
        for protocol in module.PROTOCOLS:
            split=module.make_split(data['years'],data['counties'],protocol)
            np.savez_compressed(out/f'split_{protocol}.npz',**split)
            pd.DataFrame({'row':np.arange(len(data['y'])),'adm_id':data['counties'],'year':data['years'],**split}).to_csv(out/f'split_{protocol}.csv',index=False)
            s.save(out/f'background_{protocol}.json',module.backgrounds(data['y'],data['years'],data['counties'],split,protocol))
            counts[protocol]={k:int(v.sum()) for k,v in split.items()}
    s.save(marker,{'fingerprint':fingerprint,'relative_input_sha256':hashes,'split_rows':counts,'inputs':['gdd_evi'],'protocols':module.PROTOCOLS,'seeds':s.SEEDS,'release_provenance':True})
    return fingerprint
